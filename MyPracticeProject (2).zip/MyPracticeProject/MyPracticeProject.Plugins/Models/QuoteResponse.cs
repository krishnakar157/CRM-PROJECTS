﻿namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Initialize accept quote response
    /// </summary>
    public class QuoteResponse
    {
        public Quote quote { get; set; }

        public string SalesChannel { get; set; }
        public string DistributionChannel { get; set; }
    }
}
