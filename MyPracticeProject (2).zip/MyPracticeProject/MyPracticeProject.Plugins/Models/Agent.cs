﻿using Newtonsoft.Json;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Agent information
    /// </summary>
    public class Agent
    {
        [JsonProperty(PropertyName = "AgentReference")]
        public string bupa_agentreference { get; set; }

        [JsonProperty(PropertyName = "AgentForename")]
        public string firstname { get; set; }

        [JsonProperty(PropertyName = "AgentSurname")]
        public string lastname { get; set; }

        [JsonProperty(PropertyName = "AgentTelephoneNo")]
        public string telephone1 { get; set; }

        [JsonProperty(PropertyName = "AgentEmailAddress")]
        public string emailaddress1 { get; set; }

        [JsonProperty(PropertyName = "AgentCompanyNameandDepartment")]
        public string department { get; set; }
    }
}
