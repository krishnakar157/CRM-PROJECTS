﻿using Newtonsoft.Json;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Marketing preference of consumer
    /// </summary>
    public class MarketingPreferences
    {
        [JsonProperty(PropertyName = "Type")]
        public string bupa_permissiontext { get; set; }

        [JsonProperty(PropertyName = "Response")]
        public string Response { get; set; }


    }
}
