﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Member information
    /// </summary>
    public class QuoteLife
    {
        [JsonProperty(PropertyName = "AgentLifeID")]
        public string bupa_agent_life_id { get; set; }

        [JsonProperty(PropertyName = "BupaLifeID")]
        public string bupa_bupalifeid { get; set; }

        [JsonProperty(PropertyName = "TitleCode")]
        //public string bupa_title { get; set; } // String
        public string bupa_titleoptions { get; set; } // Optionset        

        [JsonProperty(PropertyName = "Forename")]
        public string bupa_firstname { get; set; }

        [JsonProperty(PropertyName = "MiddleInitials")]
        public string bupa_middleinitial { get; set; }

        [JsonProperty(PropertyName = "Surname")]
        public string bupa_lastname { get; set; }      

        public List<CoverCondition> CoverCondition { get; set; }

        public Guid GUID { get; set; }

        public Address Address { get; set; }

        [JsonProperty(PropertyName = "BirthSex")]
        public string bupa_life_gender { get; set; }
    }
}
