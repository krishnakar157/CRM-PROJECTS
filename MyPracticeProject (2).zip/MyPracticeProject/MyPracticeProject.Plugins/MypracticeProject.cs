﻿using Bupa.Crm.Framework.Common.Logger;
using Microsoft.Xrm.Sdk;
using System;
using System.Linq;
using System.ServiceModel;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Accept Quote action plugin
    /// </summary>
    public class AcceptQuotePlugin : IPlugin
    {
        #region Member Variables
        IPluginService _pluginService;
        public ILogger logService;
        public string inputJsonString;
        #endregion

        #region Public Methods
        /// <summary>
        /// Plugin Context Execute Function
        /// </summary>
        /// <param name="serviceProvider">IServiceProvider</param>

        public void Execute(IServiceProvider serviceProvider)
        {
            //Validate that there is a service provider, otherwise no point.
            if (serviceProvider == null)
                throw new ArgumentNullException(string.Format(Constants.ServiceProviderNullMessage, Constants.AcceptQuoteLogPrefix));
            try
            {
                _pluginService = new PluginService(serviceProvider);
                // Start tracing
                _pluginService.TracingService.Trace(string.Format(Constants.StartTracingMessage, Constants.AcceptQuoteLogPrefix));

                //Instantiate Logger Object
                logService = new Logger(_pluginService.Service);

                // Check the plugin execution context is valid (i.e. the entity)
                if (!IsValidPlugInExecutionContext()) return;

                // Start tracing
                _pluginService.TracingService.Trace(string.Format(Constants.StartTracingMessage, Constants.LogPrefix) + DateTime.Now + ": " + DateTime.Now.Millisecond);

                //Required for Exception Handling
                inputJsonString = _pluginService.Context.InputParameters.Contains(Constants.Attributes) ? (string)_pluginService.Context.InputParameters[Constants.Attributes] : string.Empty;

              

                using (IBusinessLogic BL = new BusinessLogic(_pluginService))
                {
                    _pluginService.TracingService.Trace(Constants.StartingBusinessLogic);
                    BL.PerformAcceptQuoteOperation();
                }
            }
            catch (InvalidPluginExecutionException ex)
            {                
                if (ex.Message.StartsWith(Constants.AcceptResponseCode))
                {
                    string errorMessage = string.Format(Constants.GeneralExceptionMessage, Constants.AcceptQuoteLogPrefix, ex.Message, ex.InnerException, ex.StackTrace);
                    Guid logId = logService.WriteLog(Constants.AcceptQuoteLogPrefix, inputJsonString, Constants.LogPrefix, LogLevel.Error, errorMessage);
                    // Throw explicit Accept quote response
                    throw new InvalidPluginExecutionException(ex.Message);
                }
                else if (ex.Message.StartsWith(Constants.HandledException))
                {
                    string errorMessage = string.Format(Constants.GeneralExceptionMessage, Constants.AcceptQuoteLogPrefix, ex.Message, ex.InnerException, ex.StackTrace);
                    Guid logId = logService.WriteLog(Constants.AcceptQuoteLogPrefix, inputJsonString, Constants.LogPrefix, LogLevel.Error, errorMessage);
                    //Remove "HandledException" word from exception message
                    throw new InvalidPluginExecutionException(ex.Message.Replace(Constants.HandledException, string.Empty));
                }
                else
                {
                    
                    string errorMessage = string.Format(Constants.InvalidPluginExceptionMessage, Constants.AcceptQuoteLogPrefix, ex.Message, ex.StackTrace);                    
                    ProjectCommonFunctions.ThrowGenericException(_pluginService.TracingService, logService, Constants.AcceptQuoteLogPrefix, Constants.LogPrefix, inputJsonString, errorMessage);
                }
              
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
              
                string errorMessage = string.Format(Constants.OrganisationServiceFaultExceptionMessage, Constants.AcceptQuoteLogPrefix, ex.Message, ex.StackTrace);                
                ProjectCommonFunctions.ThrowGenericException(_pluginService.TracingService, logService, Constants.AcceptQuoteLogPrefix, Constants.LogPrefix, inputJsonString, errorMessage);
            }
            catch (Exception ex)
            {
                
                string errorMessage = string.Format(Constants.GeneralExceptionMessage, Constants.AcceptQuoteLogPrefix, ex.Message, ex.InnerException, ex.StackTrace);                
                ProjectCommonFunctions.ThrowGenericException(_pluginService.TracingService, logService, Constants.AcceptQuoteLogPrefix, Constants.LogPrefix, inputJsonString, errorMessage);
            }
        }

        #endregion

        #region Internal - Base Plugin Helper Methods

        /// <summary>
        /// Validate the PlugInExecutionContext
        /// We do this to ensure that the execution details are as expected, as we should
        /// be certain of this so we are aware how and when this runs
        /// </summary>
        /// <returns>Boolean of true if it's valid or not</returns>
        internal bool IsValidPlugInExecutionContext()
        {
            bool isValid = true;
            // Check the plugin execution context is valid.
            if (!_pluginService.Context.InputParameters.Contains(Constants.Attributes)
            || !(_pluginService.Context.InputParameters[Constants.Attributes] is String))
            {
                string invalidPluginContextMessage = string.Format(Constants.PluginExecutionContextInvalidMessage, Constants.HandledException, Constants.AcceptQuoteLogPrefix);
                _pluginService.TracingService.Trace(invalidPluginContextMessage);
                throw new InvalidPluginExecutionException(invalidPluginContextMessage);
            }

            if (string.IsNullOrEmpty(_pluginService.Context.InputParameters[Constants.Attributes].ToString()))
            {
                string invalidPluginContextMessage = string.Format(Constants.ParameterMissing_Attributes, Constants.HandledException);
                _pluginService.TracingService.Trace(invalidPluginContextMessage);
                throw new InvalidPluginExecutionException(invalidPluginContextMessage);
            }

            // Check the plugin depth is as expected.
            if (_pluginService.Context.Depth <= Constants.MaximumPlugInDepthSize) { return isValid; }
            else { isValid = false; }

            // If the plugin depth is not what's expected, log the depth
            string incorrectDepthMessage = string.Format(Constants.PluginExecutionContextDepthMessage, Constants.AcceptQuoteLogPrefix, Constants.MaximumPlugInDepthSize, _pluginService.Context.Depth);
            _pluginService.TracingService.Trace(incorrectDepthMessage);

            return isValid;   
        }
        #endregion

    }
}
