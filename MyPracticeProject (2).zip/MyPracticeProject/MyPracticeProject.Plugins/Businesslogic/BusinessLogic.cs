﻿using Bupa.Crm.Plugins.Sales.AcceptQuote.Model;
using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Business Logic to accept quote to create order
    /// </summary>
    public class BusinessLogic: IBusinessLogic
    {
        #region Member Variables
        IPluginService _pluginService;      
        #endregion

        #region Constructor
        /// <summary>
        /// BusinessLogic Constructor
        /// </summary>
        /// <param name="organisationService">IOrganizationService</param>
        /// <param name="tracingService">ITracingService</param>
        /// <param name="pluginContext">IPluginExecutionContext</param>>
        public BusinessLogic(IPluginService pluginService)
        {
            _pluginService = pluginService;
        }

        #endregion

        /// <summary>
        /// Accept quote and create order for quote
        /// </summary>
        public void PerformAcceptQuoteOperation()
        {
            List<string> uploadedDocs=new List<string>();
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));
            
            //Get Input Parameters
            string jsonString = (string)_pluginService.Context.InputParameters[Constants.Attributes];
            string intermediaryRef = (string)_pluginService.Context.InputParameters[Constants.IntermediaryReference];
            string source = _pluginService.Context.InputParameters.Contains(Constants.SalesChannel) && !string.IsNullOrEmpty((string)_pluginService.Context.InputParameters[Constants.SalesChannel]) ? (string)_pluginService.Context.InputParameters[Constants.SalesChannel] : string.Empty;
            string distributionChannel = _pluginService.Context.InputParameters.Contains(Constants.DistributionChannel) && !string.IsNullOrEmpty((string)_pluginService.Context.InputParameters[Constants.DistributionChannel]) ? (string)_pluginService.Context.InputParameters[Constants.DistributionChannel] : string.Empty;

            AcceptQuoteHelper acceptQuoteHelper = new AcceptQuoteHelper(_pluginService);

            Quote quote = acceptQuoteHelper.ValidateMinimumDataStandard(jsonString);            

            //Validate quote data before creating order
            Entity quoteEntity = acceptQuoteHelper.ValidateQuote(quote, intermediaryRef, source, distributionChannel);

            //Create Order for Valid Quote
            Entity order = acceptQuoteHelper.ProcessQuote(quote, quoteEntity, source, ref  uploadedDocs);
         
            //Generate Accept Quote Response    
            string json = acceptQuoteHelper.GenerateAcceptQuoteResponse(quote, order, uploadedDocs, source, distributionChannel);

            //Set Output parameter
            _pluginService.Context.OutputParameters[Constants.ResponseParameter] = json;
                     
        }        

        #region Dispose Methods

        private bool _disposed;

        /// <summary>
        /// Manage the items to dispose.
        /// </summary>
        /// <param name="disposing"></param>
        private void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                    // Dispose any managed objects
                }
                _disposed = true;
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        
        #endregion
    }
}
