﻿using Microsoft.Xrm.Sdk;
using System;

namespace Bupa.Crm.Framework.Common.Logger
{
    /// <summary>
    /// Provides an interface for logging messages to the bupa_log entity in CRM.
    /// </summary>
    /// 
      public interface ILogger
    {
        /// <summary>
        /// Writes a log to bupa_log entity in CRM.
        /// </summary>
        /// <param name="titleName">Title of the log.</param>
        /// <param name="detail">Message you wish to log in the log detail.</param>
        /// <param name="groupName">Name of the group in which log will be placed.</param>
        /// <param name="level">Level of the message, e.g. error or warning.</param>
        Guid WriteLog(string titleName, string detail, string groupName, LogLevel level, string extraInfo = "");        
    }
}
