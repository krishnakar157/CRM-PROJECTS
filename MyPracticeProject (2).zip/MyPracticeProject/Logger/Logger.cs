﻿using Microsoft.Xrm.Sdk;
using System;

namespace Bupa.Crm.Framework.Common.Logger
{
    /// <summary>
    /// Logs messages to bupa_log entity in CRM with varying log levels.
    /// </summary>
       [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public class Logger : ILogger
    {
        #region Constants.
        private const string LogEntityLogicalName = "bupa_log";
        private const string GroupSchemaName = "bupa_group";
        private const string TitleSchemaName = "bupa_name";
        private const string DetailSchemaName = "bupa_detail";
        private const string LogLevelSchemaName = "bupa_logtype";
        private const string ExtraInfoSchemaName = "bupa_extrainfo";
        
        #endregion

        #region Member variables.
        private IOrganizationService _orgService;
        #endregion

        #region Constructor.      

        /// <summary>
        /// Constructor takes in an IOrganizationService for communicating with CRM.
        /// </summary>
        /// <param name="orgService"></param>
        public Logger(IOrganizationService orgService)
        {
            _orgService = orgService;
        }
        #endregion

        #region Public methods.
        /// <summary>
        /// Writes a log to bupa_log entity in CRM.
        /// </summary>
        /// <param name="titleName">Title of the log.</param>
        /// <param name="detail">Message you wish to log in the log detail.</param>
        /// <param name="groupName">Name of the group in which log will be placed.</param>
        /// <param name="level">Level of the message, e.g. error or warning.</param>
        public Guid WriteLog(string titleName, string detail, string groupName, LogLevel level, string extraInfo = "")
        {
            Entity logRecord = new Entity(LogEntityLogicalName);
            logRecord.Attributes.Add(TitleSchemaName, titleName);
            logRecord.Attributes.Add(DetailSchemaName, CommonLogger.Truncate(detail, (int)FieldLength.DetailField));
            logRecord.Attributes.Add(GroupSchemaName, groupName);
            logRecord.Attributes.Add(LogLevelSchemaName, new OptionSetValue((int)level));
            logRecord.Attributes.Add(ExtraInfoSchemaName, CommonLogger.Truncate(extraInfo, (int)FieldLength.ExtraInfoField));            
            Guid logId = _orgService.Create(logRecord);

            return logId;
        }

        #endregion

       
    }
}
