﻿
namespace Bupa.Crm.Framework.Common.Logger
{
    /// <summary>
    /// Defines the level of a logging message.
    /// </summary>
    public enum LogLevel
    {
        Trace = 100000002,
        Information = 100000001,
        Warning = 100000003,
        Error = 100000000
    }

    /// <summary>
    /// 
    /// </summary>
    public enum FieldLength
    {
        DetailField = 1048576,
        ExtraInfoField = 5000
    }

    /// <summary>
    /// 
    /// </summary>
    [System.Diagnostics.CodeAnalysis.ExcludeFromCodeCoverage]
    public static class CommonLogger
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="maxLength"></param>
        /// <returns></returns>
        public static string Truncate(string value, int maxLength)
        {
            if (string.IsNullOrEmpty(value)) return value;
            return value.Length <= maxLength ? value : value.Substring(0, maxLength);
        }
    }
    
   
}
