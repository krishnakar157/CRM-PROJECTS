﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Bupa.Crm.Plugins.Sales.AcceptQuote;
using Microsoft.Xrm.Sdk;
using System.Collections.Generic;
using Rhino.Mocks;
using System.ServiceModel;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using System.Diagnostics.CodeAnalysis;
using Bupa.Crm.Plugins.Sales.AcceptQuote.Model;

namespace AcceptQuoteTest
{
    [ExcludeFromCodeCoverage]
    [TestClass]
    public class AcceptQuotePluginTest
    {
        #region Member Variables
        private IServiceProvider _serviceProvider;
        private IBusinessLogic _businessLogic;
        private IPluginService _pluginService;
        private AcceptQuotePlugin AcceptQuote;
        private IOrganizationServiceFactory _serviceFactory;
        private IOrganizationService _orgService;
        private ITracingService _tracingService;
        private IPluginExecutionContext _context;
        #endregion

        #region Member Constants

        //const string CreatedQuoteGuid = "B1A4B85C-EDF9-E611-80EA-3863BB34DE50";
        //const string CreatedQuoteLifeGuid = "B1A4B85C-EDF9-E611-80EA-3863BB34DE55";
        //const string CoverContinuationLifeGuid = "B1A4B85C-EDF9-E611-80EA-3863BB34DE66";


        #endregion

        #region positive test cases

        [TestMethod]
        public void AcceptQuote_Execute_Success()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }


        [TestMethod]
        public void AcceptQuoteCreateApplicant_Success()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"no\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }


        [TestMethod]
        public void AcceptQuote_Execute_CreateApplicant_TriggerSaveAction()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_UpdateAgent_IfAgentRefChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent refxx\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateAgent_IfAgentForenameChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forenamexxx\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateAgent_IfAgentSurnameChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surnamexxx\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateAgent_IfAgentTelehoneChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"012345757xx\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateAgent_IfAgentEmailChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"012345757\",\"AgentEmailAddress\":\"zzzzzzzz@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateAgent_IfAgentDepartmentChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"012345757\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa ITxxx\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateLife()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent refxx\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mrs\",\"Forename\":\"Partnerxxx\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Son\",\"MiddleInitials\":\"Lxxx\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID004\",\"TitleCode\":\"Mr\",\"Forename\":\"Son2\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTestxxx\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_UpdateLife_NullCheck()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent refxx\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mrs\",\"Forename\":\"\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Son\",\"MiddleInitials\":\"\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID004\",\"TitleCode\":\"Mr\",\"Forename\":\"Son2\",\"MiddleInitials\":\"L\",\"Surname\":\"\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_CreateApplicantFromQuoteData()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"Agent Cust Ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001444P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"\",\"TitleCode\":\"\",\"Forename\":\"\",\"MiddleInitials\":\"\",\"Surname\":\"\",\"Email\":\"\",\"Phone\":\"\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"\",\"Line2\":\"\",\"County\":\"\",\"Town\":\"\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_BillingAddress_BillPayer_MainMember()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"main member\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_BillingAddress_BillPayer_Partner()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"partner\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_BillingAddress_BillPayer_Applicant()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Applicant\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_BillingAddress_BillPayer_ContractHolder()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"ContractHolder\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_BillingAddress_BillPayer_Life()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_UpdateLife_FullName()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main Changed\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest Changed\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Partner Changed\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Son\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest Changed\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID004\",\"TitleCode\":\"Mr\",\"Forename\":\"Son2\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_UpdateLife_NoFullNameChanged()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main Changed\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest Changed\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Partner Changed\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Son\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest Changed\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID004\",\"TitleCode\":\"Mr\",\"Forename\":\"\",\"MiddleInitials\":\"Lxxx\",\"Surname\":\"\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void ResubmitAcceptQuote_UseExistingPayment_Yes()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"UseExistingPaymentDetails\":\"yes\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void ResubmitAcceptQuote_UseExistingPayment_No()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"UseExistingPaymentDetails\":\"NO\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void ResubmitAcceptQuote_UseExistingPayment_WithNoBankDetailsInRequest()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"UseExistingPaymentDetails\":\"Yes\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":null,\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void ResubmitAcceptQuote_NotUsingExistingPayment_WithNoBankDetailsInRequest()
        {
            string msg = string.Empty;
            try
            {
                SetUpContextVariables();
                ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
                var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"UseExistingPaymentDetails\":\"No\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":null,\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
                ExpectPluginContextVariable(RequestQuote);
                SetupCreateExpectations();
                SetupRetrieveMultiple(1, false, true, DateTime.Now);

                SetupExecuteExpectation();
                AcceptQuote.Execute(_serviceProvider);
            }
            catch(Exception ex)
            {
                msg = ex.Message;
            }

            Assert.AreEqual("AC005: Bank details for the DDM is incomplete. Please update and re-submit Acceptance", msg);
        }

        #endregion

        #region negative test cases

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_InvalidOptionValue()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Companyxxx\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        
        public void AcceptQuote_AccountType_Empty()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_IntermediaryShared_InvalidOption()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yesxxx\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_BillPayerId_InvalidValue()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"otherxxxxx\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Execute_RequestParameterNotFound()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);

            ParameterCollection inputParam = new ParameterCollection();
            _pluginService.Context.Stub(x => x.InputParameters).Return(inputParam);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Execute_RequestParameterNotAString()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);

            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Request", 0);
            inputParam.Add(target);

            _pluginService.Context.Stub(x => x.InputParameters).Return(inputParam);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_Execute_ExceededDepth()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);

            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Attributes", "Quote: null");
            inputParam.Add(target);

            _pluginService.Context.Stub(x => x.InputParameters).Return(inputParam);
            _pluginService.Context.Stub(x => x.Depth).Return(9);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AcceptQuote_Execute_ServiceProviderNull()
        {
            SetUpContextVariables();
            AcceptQuote.Execute(null);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void AcceptQuote_Execute_ThrowFaultException()
        {
            SetUpContextVariables();

            _serviceProvider.Expect(s => s.GetService(typeof(ITracingService))).Return(_tracingService);
            _serviceProvider.Expect(s => s.GetService(typeof(IPluginExecutionContext))).Return(_context);
            _serviceProvider.Expect(s => s.GetService(typeof(IOrganizationServiceFactory))).Return(_serviceFactory);
            _serviceFactory.Stub(x => x.CreateOrganizationService(Guid.Empty)).Throw(new FaultException<OrganizationServiceFault>(new OrganizationServiceFault(), "Fault exception thrown"));

            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Attributes", "");
            inputParam.Add(target);

            _context.Stub(x => x.InputParameters).Return(inputParam);
            _context.Stub(x => x.Depth).Return(1);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void AcceptQuote_Execute_ThrowInvalidPluginExecutionException()
        {
            SetUpContextVariables();

            _serviceProvider.Expect(s => s.GetService(typeof(ITracingService))).Return(_tracingService);
            _serviceProvider.Expect(s => s.GetService(typeof(IPluginExecutionContext))).Return(_context);
            _serviceProvider.Expect(s => s.GetService(typeof(IOrganizationServiceFactory))).Return(_serviceFactory);
            _serviceFactory.Stub(x => x.CreateOrganizationService(Guid.Empty)).Throw(new InvalidPluginExecutionException("Fault exception thrown"));

            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Attributes", "");
            inputParam.Add(target);

            _context.Stub(x => x.InputParameters).Return(inputParam);
            _context.Stub(x => x.Depth).Return(1);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(NullReferenceException))]
        public void AcceptQuote_Execute_ThrowException()
        {
            SetUpContextVariables();

            _serviceProvider.Expect(s => s.GetService(typeof(ITracingService))).Return(_tracingService);
            _serviceProvider.Expect(s => s.GetService(typeof(IPluginExecutionContext))).Return(_context);
            _serviceProvider.Expect(s => s.GetService(typeof(IOrganizationServiceFactory))).Return(_serviceFactory);
            _serviceFactory.Stub(x => x.CreateOrganizationService(Guid.Empty)).Throw(new Exception());

            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Attributes", "");
            inputParam.Add(target);

            _context.Stub(x => x.InputParameters).Return(inputParam);
            _context.Stub(x => x.Depth).Return(1);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void RequestParameterNotPassed()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            ExpectPluginContextVariable("");
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, true, true, DateTime.Now);

            SetupExecuteExpectation();

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void NullRequestParameterNotPassed()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            ExpectPluginContextVariable(null);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, true, true, DateTime.Now);

            SetupExecuteExpectation();

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_Success_InvalidSortCodePaymentDetail()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "True");

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Success_NoLivesData()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "True");

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_Success_InvalidAccNoPaymentDetail()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "false", "True");

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_Success_ValidatePayment_ApiExceptionError()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "", "");

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_AddCoverConditions_WithQuoteLife()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_AddCoverConditions_WithCoverContinuationLife()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_AddCoverConditions_WithDeclinitionReason()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", false);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }
        [TestMethod]

        public void AcceptQuote_Validate_ResubmitReference()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", false);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        public void AcceptQuote_Validate_ResubmitReferenceDeclined()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", false,10000001,false,false,true);

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }  
 

   

    [TestMethod]
        public void CheckMaximumPluginDepth()
        {
            SetUpContextVariables();

            _serviceProvider.Expect(s => s.GetService(typeof(ITracingService))).Return(_tracingService);
            _serviceProvider.Expect(s => s.GetService(typeof(IPluginExecutionContext))).Return(_context);
            _serviceProvider.Expect(s => s.GetService(typeof(IOrganizationServiceFactory))).Return(_serviceFactory);
            _serviceFactory.Stub(x => x.CreateOrganizationService(Guid.Empty)).Return(_orgService);

            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Attributes", "Quote");
            inputParam.Add(target);

            _context.Stub(x => x.InputParameters).Return(inputParam);
            _context.Stub(x => x.Depth).Return(9);

            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void GetOptionSetValue_ThrowException()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\": {\"DateTimeGenerated\": \"2018-01-01\",\"AgentCustomerReference\": \"agent cust ref\",\"AgentQuoteReference\":\"BBY10090860P\",\"BupaQuotationRef\": \"BBY10090880P\",\"BupaPolicyNumber\": \"484848\",\"QuoteType\": \"New Business\",\"ProductName\": \"BBY\",\"IPTExempt\": \"Yes\",\"BupaReferralReference\": \"bupa referral reference\",\"PaymentFrequency\": \"Monthly\",\"PaymentType\": \"payment type\",\"Agent\": {\"AgentReference\": \"agent ref\",\"AgentForename\": \"agent forename\",\"AgentSurname\": \"agent surname\",\"AgentTelephoneNo\": \"01234575755\",\"AgentEmailAddress\": \"abcd@xyz.com\",\"AgentCompanyNameandDepartment\": \"Bupa IT\"},\"PolicyPremiumQuoteBreakdown\" : {\"AcceptanceFrequency\" : \"Monthly\",\"AcceptancePremiumNett\" : \"2838.3\",\"AcceptanceIPT\" : \"38.3\",\"AcceptanceVAT\" : \"494\",\"AcceptancePremiumPayable\" : \"3000\"},\"CommissionID\": \"4433\",\"Applicant\": {\"BupaMemberID\": \"848\",\"TitleCode\": \"Mr\",\"Forename\": \"Test\",\"MiddleInitials\": \"T\",\"Surname\": \"Tester\",\"Relationship\":\"Main Member\",\"Email\": \"t@test.com\",\"Phone\": \"12883838\",\"MarketingPreferences\": {\"Type\": \"Email\",\"Response\": \"Yes\"},\"Address\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Milton Keynes\",\"County\": \"Bucks\"}},\"QuoteLife\": [{\"AgentLifeID\": \"12345\",\"BupaLifeID\": \"54132\",\"TitleCode\": \"Mr\",\"Forename\": \"Test\",\"MiddleInitials\": \"L\",\"Surname\": \"LifeTest\",\"Relationship\":\"Main Member\",\"Address\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",}}],\"CoverFunder\": {\"CoverFunder\" : \"Contract Holder\",\"AccountType\" : \"Company\",\"PaymentType\" : \"InvalidPaymentType\",\"BankDetails\" : {\"BankAccountName\" : \"Mr Jones\",\"BankName\" : \"Santander Plc.\",\"SortCode\" : \"11 22 33\",\"AccountNumber\" : \"123456\" },\"CardDetails\" : {\"CardHolderName\" : \"Mr Jones\",\"CardNumber\" : \"1234 5678 9012 3456\",\"StartDate\" : \"09/16\",\"EndDate\" : \"09/19\",\"CSV\" : \"123\"},\"BankingAddress\" : {\"Line1\" : \"22 High Street\",\"Line2\" : \"Wolverton\",\"Town\" : \"Staines\",\"County\" : \"Herts\",\"Postcode\" : \"MK18 4DD\"}}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "True");

            SetupExecuteExpectation();
            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_LivesNotFound()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", false, 10000001, true);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]

        public void AcceptQuote_InternediaryNotFound()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", false, 10000001,false,false,false, true);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

          

        #endregion

        #region Validation Test Cases        

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_QuoteWonStatus()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001438P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(2, false, true, DateTime.Now);

            SetupExecuteExpectation();

            _businessLogic.PerformAcceptQuoteOperation();
        }

       

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_QuoteClosedStatus()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001438P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(3, false, true, DateTime.Now);

            SetupExecuteExpectation();

            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC001_InvalidIntermediary()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001438P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, true, true, DateTime.Now);

            SetupExecuteExpectation();

            _businessLogic.PerformAcceptQuoteOperation();
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC002_QuoteOlderThan14Days()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001438P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, new DateTime(2019, 08, 14));

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC003_QuoteNotFound()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001438P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", true);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_IncompleteApplicantDetails()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"IntermediarySharedData\":\"yes\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\",\"PaymentType\":\"DDM\",\"AccountType\":\"Company\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"BankName\":\"Santander Plc\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"}}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC004_ApplicantPostCode()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQxxxxxx\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"BankAccountName\":\"Mr Jones\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC004_LifePostCode()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"CommissionID\":\"4433\",\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EBxxxxxx \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeIdD03\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID004\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC008_BupaLifeIdNotMatched()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"CommissionID\":\"4433\",\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001xxxxx\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId004\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC009_BupaLifeIdNotFound()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"TEst\",\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"123654789\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EBQ\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"BankAccountName\":\"Mr Jones\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC005_BankDetails_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":null,\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Contract Holder\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC005_BankDetails()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"\",\"BankName\":\"\",\"SortCode\":\"\",\"AccountNumber\":\"\",\"TitleCode\":\"\",\"Forename\":\"\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Contract Holder\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC006_BankAddress()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"\",\"Line2\":\"Wolverton\",\"Town\":\"\",\"County\":\"Herts\",\"Postcode\":\"\"},\"BillPayerId\":\"Contract Holder\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Validate_AC010_BusinessAccount()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Mr\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"\",\"Line2\":\"Wolverton\",\"Town\":\"\",\"County\":\"Herts\",\"Postcode\":\"\"},\"BillPayerId\":\"Contract Holder\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, "False", "False", false, 100000000);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

      

       

        #region Minimum Data Standards

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_QuoteString_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "\"\"";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_QuoteString_NullString()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "null";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

       

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_QuoteString_EmptyBraces()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "\"{}\"";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Quote_IsEmptyString()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\": \"\"";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Quote_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\": null";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Quote_IsEmptyBracesAsString()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\": \"{}\"";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_DatetimeGenerated_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":null,\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"BBY10090860P\",\"BupaQuotationRef\":\"BBY10090880P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\"},\"Relationship\":\"Main Member\"},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"54132\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\"},\"Relationship\":\"Main Member\"}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"Direct Debit\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc.\",\"SortCode\":\"11 22 33\",\"AccountNumber\":\"123456\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"CoverFunder\":\"Contract Holder\",\"CardDetails\":{\"CardHolderName\":\"Mr Jones\",\"CardNumber\":\"1234 5678 9012 3456\",\"StartDate\":\"09/16\",\"EndDate\":\"09/19\",\"CSV\":\"123\"}},\"QuoteType\":\"New Business\",\"ProductName\":\"BBY\",\"IPTExempt\":\"Yes\",\"BupaReferralReference\":\"bupa referral reference\",\"PaymentFrequency\":\"Monthly\",\"PaymentType\":\"payment type\",\"PolicyPremiumQuoteBreakdown\":{\"AcceptanceFrequency\":\"Monthly\",\"AcceptancePremiumNett\":\"2838.3\",\"AcceptanceIPT\":\"38.3\",\"AcceptanceVAT\":\"494\",\"AcceptancePremiumPayable\":\"3000\"},\"ProductConfig\":[{\"CoverName\":\"Lpc1\"}]}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentCustomerReference_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"null\",\"AgentQuoteReference\":\"BBY10090860P\",\"BupaQuotationRef\":\"BBY10090880P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\"},\"Relationship\":\"Main Member\"},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"54132\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\"},\"Relationship\":\"Main Member\"}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"Direct Debit\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc.\",\"SortCode\":\"11 22 33\",\"AccountNumber\":\"123456\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"CoverFunder\":\"Contract Holder\",\"CardDetails\":{\"CardHolderName\":\"Mr Jones\",\"CardNumber\":\"1234 5678 9012 3456\",\"StartDate\":\"09/16\",\"EndDate\":\"09/19\",\"CSV\":\"123\"}},\"QuoteType\":\"New Business\",\"ProductName\":\"BBY\",\"IPTExempt\":\"Yes\",\"BupaReferralReference\":\"bupa referral reference\",\"PaymentFrequency\":\"Monthly\",\"PaymentType\":\"payment type\",\"PolicyPremiumQuoteBreakdown\":{\"AcceptanceFrequency\":\"Monthly\",\"AcceptancePremiumNett\":\"2838.3\",\"AcceptanceIPT\":\"38.3\",\"AcceptanceVAT\":\"494\",\"AcceptancePremiumPayable\":\"3000\"},\"ProductConfig\":[{\"CoverName\":\"Lpc1\"}]}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_BupaQuotationRef_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent quote ref\",\"AgentQuoteReference\":\"BBY10090860P\",\"BupaQuotationRef\":\"\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\"},\"Relationship\":\"Main Member\"},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"54132\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\"},\"Relationship\":\"Main Member\"}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"Direct Debit\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc.\",\"SortCode\":\"11 22 33\",\"AccountNumber\":\"123456\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"CoverFunder\":\"Contract Holder\",\"CardDetails\":{\"CardHolderName\":\"Mr Jones\",\"CardNumber\":\"1234 5678 9012 3456\",\"StartDate\":\"09/16\",\"EndDate\":\"09/19\",\"CSV\":\"123\"}},\"QuoteType\":\"New Business\",\"ProductName\":\"BBY\",\"IPTExempt\":\"Yes\",\"BupaReferralReference\":\"bupa referral reference\",\"PaymentFrequency\":\"Monthly\",\"PaymentType\":\"payment type\",\"PolicyPremiumQuoteBreakdown\":{\"AcceptanceFrequency\":\"Monthly\",\"AcceptancePremiumNett\":\"2838.3\",\"AcceptanceIPT\":\"38.3\",\"AcceptanceVAT\":\"494\",\"AcceptancePremiumPayable\":\"3000\"},\"ProductConfig\":[{\"CoverName\":\"Lpc1\"}]}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CommissionId_IsNull()
        { 
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent quote ref\",\"AgentQuoteReference\":\"BBY10090860P\",\"BupaQuotationRef\":\"BBY10090860P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\"},\"Relationship\":\"Main Member\"},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"54132\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\"},\"Relationship\":\"Main Member\"}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"Direct Debit\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc.\",\"SortCode\":\"11 22 33\",\"AccountNumber\":\"123456\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"CoverFunder\":\"Contract Holder\",\"CardDetails\":{\"CardHolderName\":\"Mr Jones\",\"CardNumber\":\"1234 5678 9012 3456\",\"StartDate\":\"09/16\",\"EndDate\":\"09/19\",\"CSV\":\"123\"}},\"QuoteType\":\"New Business\",\"ProductName\":\"BBY\",\"IPTExempt\":\"Yes\",\"BupaReferralReference\":\"bupa referral reference\",\"PaymentFrequency\":\"Monthly\",\"PaymentType\":\"payment type\",\"PolicyPremiumQuoteBreakdown\":{\"AcceptanceFrequency\":\"Monthly\",\"AcceptancePremiumNett\":\"2838.3\",\"AcceptanceIPT\":\"38.3\",\"AcceptanceVAT\":\"494\",\"AcceptancePremiumPayable\":\"3000\"},\"ProductConfig\":[{\"CoverName\":\"Lpc1\"}]}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_IntermediarySharedData_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"MK3 7RQ\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Agent_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);        
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"Yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentReference_IsNull()
        {

            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentForename_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }
        
        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentSurname_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentTelephone_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentEmail_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_AgentDepartment_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_Applicant_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":null,\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_ApplicantAddress_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":null,\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_ApplicantPostcode_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"\"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_QuoteLife_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"BupaPolicyNumber\":\"484848\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"CommissionID\":\"4433\",\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"TEst\",\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"123654789\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},\"QuoteLife\":null,\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_QuoteLifeAddress_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_QuoteLifePostcode_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"MiddleInitials\":\"M\",\"Surname\":\"Tester\",\"Forename\":\"TEst\",\"TitleCode\":\"Mr\",\"BupaMemberID\":\"848\",\"Phone\":\"123654789\",\"Email\":\"t@test.com\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"},\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankAccountName\":\"Mr Jones\",\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"},\"IntermediarySharedData\":\"yes\"}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CoverFunder_IsNull()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":null}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_OtherAsBillPayer_PayerRelationshipOther()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"GL1 1EA\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"EC1R 5BL\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"EC1R 5BL\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"EC1R 5BL\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_ApplicantAsBillPayer_PayerRelationshipOther()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"GL1 1EA\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"EC1R 5BL\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"EC1R 5BL\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"EC1R 5BL\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Applicant\",\"PayerRelationshipOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]        
        public void AcceptQuote_MainMemberAsBillPayer_PayerRelationshipOther()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }
        #endregion
        #endregion

        #region CIP Source Test Cases
        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_Validate_AC004_ApplicantPostCode()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001357P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQxxxxxx\"}},\"QuoteLife\":[{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId001\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeId002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}},{\"AgentLifeID\":\"12345\",\"BupaLifeID\":\"LifeId003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\" W10 4EB \"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"BankAccountName\":\"Mr Jones\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"Life\",\"RelationshipIfOther\":\"\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_CIP_Execute_Success()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"LifeID001\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_ValidateDistributionChannel()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\": {\"DateTimeGenerated\": \"2018-01-01\",\"BupaQuotationRef\": \"BBY00005700P\",\"AgentCustomerReference\": \"agent cust ref\",\"BupaPolicyNumber\": \"484848\",\"UseExistingPaymentDetails\" : \"\",\"ResubmitReference\": \"\",\"Agent\": {\"AgentReference\": \"MN27\",\"AgentForename\": \"Broker\",\"AgentSurname\": \"Contact 2\",\"AgentTelephoneNo\": \"01234575755\",\"AgentEmailAddress\": \"abcd@xyz.com\",\"AgentCompanyNameandDepartment\": \"Bupa IT\"},\"CommissionID\": \"1001\",\"Applicant\": {\"BupaMemberID\": \"848\",\"TitleCode\": \"Mr\",\"Forename\": \"Test\",\"MiddleInitials\": \"T\",\"Surname\": \"Tester\",\"RelationshipToCoverLifeMainMember\": \"Main Member\",\"Declaration18OrOver\": \"Yes\",\"Email\": \"t@test.com\",\"Phone\": \"12883838\",\"MarketingPreferences\": {\"Type\": \"Email\",\"Response\": \"Yes\"},\"Address\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Milton Keynes\",\"County\": \"Bucks\",\"Postcode\": \"GL1 1EA\"}},\"QuoteLife\": [{\"AgentLifeID\": \"12345\",\"BupaLifeID\": \"54312\",\"TitleCode\": \"Mr\",\"Forename\": \"Main\",\"MiddleInitials\": \"L\",\"Surname\": \"LifeTest\",\"BirthSex\": \"Female\",\"Address\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Milton Keynes\",\"County\": \"Bucks\",\"Postcode\": \"GL1 1EA\"}}],\"AgentQuoteReference\": \"\",\"IntermediarySharedData\": \"yes\",\"CoverFunder\": {\"AccountType\": \"Company\",\"PaymentType\": \"DDM\",\"BankDetails\": {\"BankName\": \"Santander Plc\",\"SortCode\": \"134000\",\"AccountNumber\": \"00000000\",\"TitleCode\": \"Miss\",\"Forename\": \"Vedika\",\"MiddleInitials\": \"V\",\"Surname\": \"Ghadshi\"},\"BankingAddress\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Staines\",\"County\": \"Herts\",\"Postcode\": \"MK18 4DD\",\"CompanyName\": \"\"},\"BillPayerId\": \"other\",\"PayerRelationshipOther\": \"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Brker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_InvalidBirthSexOption()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\": {\"DateTimeGenerated\": \"2018-01-01\",\"BupaQuotationRef\": \"BBY00005700P\",\"AgentCustomerReference\": \"agent cust ref\",\"BupaPolicyNumber\": \"484848\",\"UseExistingPaymentDetails\" : \"\",\"ResubmitReference\": \"\",\"Agent\": {\"AgentReference\": \"MN27\",\"AgentForename\": \"Broker\",\"AgentSurname\": \"Contact 2\",\"AgentTelephoneNo\": \"01234575755\",\"AgentEmailAddress\": \"abcd@xyz.com\",\"AgentCompanyNameandDepartment\": \"Bupa IT\"},\"CommissionID\": \"1001\",\"Applicant\": {\"BupaMemberID\": \"848\",\"TitleCode\": \"Mr\",\"Forename\": \"Test\",\"MiddleInitials\": \"T\",\"Surname\": \"Tester\",\"RelationshipToCoverLifeMainMember\": \"Main Member\",\"Declaration18OrOver\": \"Yes\",\"Email\": \"t@test.com\",\"Phone\": \"12883838\",\"MarketingPreferences\": {\"Type\": \"Email\",\"Response\": \"Yes\"},\"Address\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Milton Keynes\",\"County\": \"Bucks\",\"Postcode\": \"MK3 7RQ\"}},\"QuoteLife\": [{\"AgentLifeID\": \"12345\",\"BupaLifeID\": \"LifeID001\",\"TitleCode\": \"Mr\",\"Forename\": \"Main\",\"MiddleInitials\": \"L\",\"Surname\": \"LifeTest\",\"BirthSex\": \"Fmale\",\"Address\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Milton Keynes\",\"County\": \"Bucks\",\"Postcode\": \"W10 4EB\"}}],\"AgentQuoteReference\": \"\",\"IntermediarySharedData\": \"yes\",\"CoverFunder\": {\"AccountType\": \"Company\",\"PaymentType\": \"DDM\",\"BankDetails\": {\"BankName\": \"Santander Plc\",\"SortCode\": \"134000\",\"AccountNumber\": \"00000000\",\"TitleCode\": \"Miss\",\"Forename\": \"Vedika\",\"MiddleInitials\": \"V\",\"Surname\": \"Ghadshi\"},\"BankingAddress\": {\"Line1\": \"22 High Street\",\"Line2\": \"Wolverton\",\"Town\": \"Staines\",\"County\": \"Herts\",\"Postcode\": \"MK18 4DD\",\"CompanyName\": \"\"},\"BillPayerId\": \"other\",\"PayerRelationshipOther\": \"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_NullDistributionChannel()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"LifeID001\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = string.Empty;
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_CIP_NullMarketingPreferences()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":\"\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"LifeID001\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        public void AcceptQuote_CIP_NoMarketingPreferences()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"LifeID001\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_NullAgentLifeId()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_PostCodesAmended()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"LifeID001\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EBxxx\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidPluginExecutionException))]
        public void AcceptQuote_CIP_RejectIndicativeQuote()
        {
            SetUpContextVariables();
            ExpectMockedServiceProvider(_serviceProvider, AcceptQuote);
            var RequestQuote = "{\"Quote\":{\"DateTimeGenerated\":\"2018-01-01\",\"AgentCustomerReference\":\"agent cust ref\",\"AgentQuoteReference\":\"\",\"BupaQuotationRef\":\"BBY00001433P\",\"BupaPolicyNumber\":\"484848\",\"CommissionID\":\"4433\",\"IntermediarySharedData\":\"yes\",\"Agent\":{\"AgentReference\":\"agent ref\",\"AgentForename\":\"agent forename\",\"AgentSurname\":\"agent surname\",\"AgentTelephoneNo\":\"01234575755\",\"AgentEmailAddress\":\"abcd@xyz.com\",\"AgentCompanyNameandDepartment\":\"Bupa IT\"},\"Applicant\":{\"BupaMemberID\":\"848\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"T\",\"Surname\":\"Tester\",\"Email\":\"t@test.com\",\"Phone\":\"12883838\",\"MarketingPreferences\":{\"Type\":\"Email\",\"Response\":\"Yes\"},\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"County\":\"Bucks\",\"Town\":\"Milton Keynes\",\"Postcode\":\"MK3 7RQ\"}},\"QuoteLife\":[{\"AgentLifeID\":\"LifeID001\",\"BupaLifeID\":\"LifeID001\",\"TitleCode\":\"Mr\",\"Forename\":\"Main\",\"MiddleInitials\":\"L\",\"Surname\":\"LifeTest\",\"BirthSex\": \"Female\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID002\",\"BupaLifeID\":\"LifeID002\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Partner\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}},{\"AgentLifeID\":\"LifeID003\",\"BupaLifeID\":\"LifeID003\",\"TitleCode\":\"Mr\",\"Forename\":\"Test\",\"MiddleInitials\":\"L\",\"Surname\":\"Son\",\"Address\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Milton Keynes\",\"County\":\"Bucks\",\"Postcode\":\"W10 4EB\"}}],\"CoverFunder\":{\"AccountType\":\"Company\",\"PaymentType\":\"DDM\",\"BankDetails\":{\"BankName\":\"Santander Plc\",\"SortCode\":\"134000\",\"AccountNumber\":\"00000000\",\"TitleCode\":\"Miss\",\"Forename\":\"Vedika\",\"MiddleInitials\":\"V\",\"Surname\":\"Ghadshi\"},\"BankingAddress\":{\"Line1\":\"22 High Street\",\"Line2\":\"Wolverton\",\"Town\":\"Staines\",\"County\":\"Herts\",\"Postcode\":\"MK18 4DD\"},\"BillPayerId\":\"other\",\"PayerRelationshipOther\":\"Power of Attorney\"}}}";
            ExpectPluginContextVariable(RequestQuote);
            _context.InputParameters["SalesChannel"] = "CIP";
            _context.InputParameters["DistributionChannel"] = "Broker";
            SetupCreateExpectations();
            SetupRetrieveMultiple(1, false, true, DateTime.Now, setIndicativeQuote: true);

            SetupExecuteExpectation();
            AcceptQuote.Execute(_serviceProvider);
        }

        #endregion

        #region Test Setup

        /// <summary>
        /// 
        /// </summary>
        private void SetupExecuteExpectation()
        {
            _orgService.Stub(x => x.Execute(null)).IgnoreArguments().Do((Func<OrganizationRequest, OrganizationResponse>)delegate (OrganizationRequest request)
            {
                if (typeof(ConvertQuoteToSalesOrderRequest) == request.GetType())
                {
                    Entity order = new Entity()
                    {
                        LogicalName = "salesorder",
                        Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                        Attributes = new AttributeCollection
                        {
                            new KeyValuePair<string, object>("bupa_name", "Intermediary API")
                        }
                    };
                    return new ConvertQuoteToSalesOrderResponse()
                    {
                        Results = { new KeyValuePair<string, object>("Entity", order) }
                    };
                }
                if (typeof(WinQuoteRequest) == request.GetType())
                {

                    return new WinQuoteResponse();
                }

                return new OrganizationResponse();
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="quoteStatus"></param>
        /// <param name="invalidIntermediary"></param>
        /// <param name="hasApplicantData"></param>
        /// <param name="invalidSortCode"></param>
        /// <param name="invalidAccountNo"></param>
        private void SetupRetrieveMultiple(int quoteStatus, bool invalidIntermediary, bool hasApplicantData, DateTime createdOn, string invalidSortCode = "False", string invalidAccountNo = "False", bool invalidQuote = false, int continuationType = 10000001, bool noLife = false, bool inValidOrder = false, bool declination = false, bool noIntermediary = false, bool setIndicativeQuote = false)
        {
            _orgService.Stub(x => x.RetrieveMultiple(null)).IgnoreArguments().Do((Func<QueryBase, EntityCollection>)delegate (QueryBase qe)
            {
                if (qe.GetType() == typeof(QueryExpression))
                {

                    QueryExpression query = (QueryExpression)qe;
                    if (query.EntityName == "account")
                    {
                        if (noIntermediary) return new EntityCollection();
                        Entity account = new Entity()
                        {
                            LogicalName = "account",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                       {
                                new KeyValuePair<string, object>("bupa_name", "Bupa1"),
                                new KeyValuePair<string, object>("bupa_companystatus", new OptionSetValue(10000000)),
                                 new KeyValuePair<string, object>("postcode", "MK3 7RQ"),
                                new KeyValuePair<string, object>( "bupa_commission_level.bupa_name","4433"),
                                new KeyValuePair<string, object>( "bupa_commission_level.bupa_producttype", new AliasedValue("bupa_commission_level", "bupa_producttype", new OptionSetValue(100000003))),


                       }
                        };
                        return GetEntityCollection(account);
                    }
                    else if (query.EntityName == "task")
                    {
                        EntityCollection taskList = new EntityCollection();

                        Entity quoteTask = new Entity()
                        {
                            LogicalName = "task",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("subject", "ER049"),
                                new KeyValuePair<string, object>("annotation.subject", new AliasedValue("annotation", "subject", "ER049")),
                                new KeyValuePair<string, object>("annotation.documentbody", new AliasedValue("annotation", "documentbody", "filename")),
                                new KeyValuePair<string, object>( "annotation.mimetype",new AliasedValue("annotation", "mimetype", "filename")),
                                new KeyValuePair<string, object>( "annotation.notetext",new AliasedValue("annotation", "notetext", "filename")),
                                new KeyValuePair<string, object>( "annotation.filename", new AliasedValue("annotation", "filename", "filename")),
                            }
                        };

                        Entity lifeTask = new Entity()
                        {
                            LogicalName = "task",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("subject", "ER049"),
                                new KeyValuePair<string, object>("bupa_bupalifeid", "LifeID001"),
                                new KeyValuePair<string, object>("annotation.subject", new AliasedValue("annotation", "subject", "ER049")),
                                new KeyValuePair<string, object>("annotation.documentbody", new AliasedValue("annotation", "documentbody", "filename")),
                                new KeyValuePair<string, object>( "annotation.mimetype",new AliasedValue("annotation", "mimetype", "filename")),
                                new KeyValuePair<string, object>( "annotation.notetext",new AliasedValue("annotation", "notetext", "filename")),
                                new KeyValuePair<string, object>( "annotation.filename", new AliasedValue("annotation", "filename", "filename")),
                            }
                        };
                        taskList.Entities.AddRange(quoteTask,lifeTask);
                        return taskList;
                    }
                    else if (query.EntityName == "quote")
                    {
                        if (invalidQuote) { return new EntityCollection(); }

                        Entity quote = new Entity()
                        {
                            LogicalName = "quote",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("statecode", new OptionSetValue(quoteStatus)),
                                new KeyValuePair<string, object>("customerid", new EntityReference("account",invalidIntermediary?Guid.Empty: new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"))),
                                new KeyValuePair<string, object>("createdon", createdOn),
                                new KeyValuePair<string, object>("bupa_applicant_address_postcode", "MK3 7RQ"),
                                new KeyValuePair<string, object>("bupa_productoptionid", new EntityReference { Name = "BBY" }),
                                new KeyValuePair<string, object>("bupa_continuationtype", new OptionSetValue(continuationType)),
                                                             
                                //Agent detail
                                new KeyValuePair<string, object>("contact.bupa_agentreference", new AliasedValue("contact", "bupa_agentreference", "agent ref")),
                                new KeyValuePair<string, object>("contact.firstname", new AliasedValue("contact", "firstname", "agent forename")),
                                new KeyValuePair<string, object>("contact.lastname", new AliasedValue("contact", "lastname", "agent surname")),
                                new KeyValuePair<string, object>("contact.telephone1", new AliasedValue("contact", "telephone1", "01234575755")),
                                new KeyValuePair<string, object>("contact.emailaddress1", new AliasedValue("contact", "emailaddress1", "abcd@xyz.com")),
                                new KeyValuePair<string, object>("contact.department", new AliasedValue("contact", "department", "Bupa IT")),
                                new KeyValuePair<string, object>("contact.contactid", new AliasedValue("contact", "contactid", Guid.NewGuid())),
                                new KeyValuePair<string, object>("salesorder.salesorderid",new AliasedValue("salesorder","salesorderid", new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"))),
                                new KeyValuePair<string, object>("salesorder.name",new AliasedValue("salesorder","name", "BBYQoute")),

                                //Applicant data
                                new KeyValuePair<string, object>("bupa_applicant_forename", "Applicant forename"),
                                new KeyValuePair<string, object>("bupa_applicant_middleinitials", "Applicant middle initial"),
                                new KeyValuePair<string, object>("bupa_applicant_surname", "Applicant surname"),
                                new KeyValuePair<string, object>("bupa_applicant_phone", "123654789"),
                                new KeyValuePair<string, object>("bupa_applicant_email", "Applicant@gmail.com"),
                                new KeyValuePair<string, object>("bupa_applicant_bupamemberid", "1236"),
                                new KeyValuePair<string, object>("bupa_applicant_address_line1", "Line1"),
                                new KeyValuePair<string, object>("bupa_applicant_address_line2", "Line2"),
                                new KeyValuePair<string, object>("bupa_applicant_address_town", "Town aa"),
                                new KeyValuePair<string, object>("bupa_applicant_address_county", "county"),

                                //PaymentDetails
                                new KeyValuePair<string, object>("bupa_paymentdetail.bupa_paymenttype",new AliasedValue("bupa_paymentdetail","bupa_paymenttype", new OptionSetValue(100000001))),
                                new KeyValuePair<string, object>("bupa_paymentdetail.bupa_paymentmethod",new AliasedValue("bupa_paymentdetail","bupa_paymentmethod", "DDM")),
                                new KeyValuePair<string, object>("bupa_paymentdetail.bupa_accountname",new AliasedValue("bupa_paymentdetail","bupa_accountname", "Test Account Name")),
                                new KeyValuePair<string, object>("bupa_paymentdetail.bupa_accountnumber",new AliasedValue("bupa_paymentdetail","bupa_accountnumber", "00000000")),
                                new KeyValuePair<string, object>("bupa_paymentdetail.bupa_sortcode",new AliasedValue("bupa_paymentdetail","bupa_sortcode", "134000")),
                                new KeyValuePair<string, object>("bupa_paymentdetail.bupa_bankname",new AliasedValue("bupa_paymentdetail","bupa_bankname", "Santander")),
                                //new KeyValuePair<string, object>("bupa_paymentdetail.bupa_accounttype",new AliasedValue("bupa_paymentdetail","bupa_accounttype", new OptionSetValue(100000000)))

                            }
                        };
                        quote.FormattedValues.Add("bupa_continuationtype", "XGS");

                        if (setIndicativeQuote)
                        {
                            //Indicative Flag
                            quote.Attributes.Add(new KeyValuePair<string, object>("bupa_indicative", true));
                        }
                        return GetEntityCollection(quote);
                    }
                    else if (query.EntityName == "bupa_quoteresponse")
                    {
                        Entity quoteResponse = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Quote cover condition"),
                                new KeyValuePair<string, object>("bupa_orderid",new EntityReference("quote", new Guid(CreatedQuoteGuid))),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "ER049"),
                            }

                        };
                        Entity quoteResponseQuote = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Quote cover condition"),
                                new KeyValuePair<string, object>("bupa_orderid",new EntityReference("quote", new Guid(CreatedQuoteGuid))),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "ER049"),
                            }

                        };
                        Entity quoteResponse1 = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Life cover condition"),
                                new KeyValuePair<string, object>("bupa_quotelifeid",new EntityReference("bupa_customercover", new Guid(CreatedQuoteLifeGuid))),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "ER049"),
                            }
                        };
                        Entity quoteResponse2 = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Life cover condition"),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "ER049"),
                                new KeyValuePair<string, object>("bupa_continuationcoverid", new EntityReference(string.Empty, new Guid(CoverContinuationLifeGuid))),

                            }
                        };
                        Entity quoteResponse3 = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Life cover condition"),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "ER049"),
                                new KeyValuePair<string, object>("bupa_lifeproductionconfigurationid", new EntityReference {
                                    Id = new Guid(CoverContinuationLifeGuid),
                                    Name = "Lpc1"
                                })

                            }
                        };

                        Entity quoteResponse4 = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Life cover condition"),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "A001"),
                                new KeyValuePair<string, object>("bupa_lifeproductionconfigurationid", new EntityReference {
                                    Id = new Guid(CoverContinuationLifeGuid),
                                    Name = "Lpc1"
                                }),
                                new  KeyValuePair<string, object>("bupa_orderid", new EntityReference("salesorder", Guid.NewGuid()))
                            }
                        };
                        
                        Entity declinitionReason1 = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Quote cover condition"),
                                new KeyValuePair<string, object>("bupa_quoteid",new EntityReference("quote", new Guid(CreatedQuoteGuid))),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "QR056"),
                            }

                        };
                        Entity declinitionReason2 = new Entity()
                        {
                            LogicalName = "bupa_quoteresponse",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Quote cover condition"),
                                new KeyValuePair<string, object>("bupa_quoteid",new EntityReference("quote", new Guid(CreatedQuoteGuid))),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_responsecode", "QR056"),
                            }
                        };
                        declinitionReason2.FormattedValues.Add("bupa_responsetype", "Declination Reason");
                        EntityCollection coll = new EntityCollection();
                        if (declination)
                        {
                            Entity declinitionReason = new Entity()
                            {
                                LogicalName = "bupa_quoteresponse",
                                Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE50"),
                                Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_responsemessage", "Quote cover condition"),
                                new KeyValuePair<string, object>("bupa_quoteid",new EntityReference("quote", new Guid(CreatedQuoteGuid))),
                                new KeyValuePair<string, object>("bupa_responsetype",new OptionSetValue(100000001)),
                                new KeyValuePair<string, object>("bupa_responsecode", "QR056"),
                            }
                            };
                            coll.Entities.Add(declinitionReason);
                        }
                        coll.Entities.AddRange(quoteResponse, quoteResponse1, quoteResponse2, quoteResponse3, quoteResponse4, declinitionReason2, quoteResponseQuote);
                        return coll;
                    }
                    else if (query.EntityName == "bupa_customercover")
                    {
                        if (noLife)
                            return new EntityCollection();

                        Entity life1 = new Entity()
                        {
                            LogicalName = "bupa_customercover",
                            Id = new Guid(CreatedQuoteLifeGuid),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_postcode", "W10 4EB"),
                                new KeyValuePair<string, object>("bupa_bupalifeid", "LifeID001"),
                                new KeyValuePair<string, object>("bupa_customercoverid", Guid.NewGuid()),
                                new KeyValuePair<string, object>("bupa_title", "Mr"),
                                new KeyValuePair<string, object>("bupa_firstname", "Main"),
                                new KeyValuePair<string, object>("bupa_lastname", "LifeTest"),
                                new KeyValuePair<string, object>("bupa_middleinitial", "L"),
                                new KeyValuePair<string, object>("bupa_titleoptions", new OptionSetValue(10000000)),
                                new KeyValuePair<string, object>("bupa_relationshipcode", new OptionSetValue(100000000)),
                                new KeyValuePair<string, object>("bupa_life_gender", new OptionSetValue(1)),
                                new KeyValuePair<string, object>("bupa_agent_life_id", "LifeID001")
                            }
                        };
                        life1.FormattedValues.Add("bupa_titleoptions", "Mr");
                        life1.FormattedValues.Add("bupa_life_gender", "Male");

                        Entity life2 = new Entity()
                        {
                            LogicalName = "bupa_customercover",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE60"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_postcode", "W10 4EB"),
                                new KeyValuePair<string, object>("bupa_bupalifeid", "LifeID002"),
                                new KeyValuePair<string, object>("bupa_customercoverid", Guid.NewGuid()),
                                new KeyValuePair<string, object>("bupa_title", "Mrs"),
                                new KeyValuePair<string, object>("bupa_firstname", "Partner"),
                                new KeyValuePair<string, object>("bupa_lastname", "LifeTest"),
                                new KeyValuePair<string, object>("bupa_middleinitial", "L"),
                                new KeyValuePair<string, object>("bupa_titleoptions", new OptionSetValue(10000000)),
                                new KeyValuePair<string, object>("bupa_life_gender", null),
                                new KeyValuePair<string, object>("bupa_agent_life_id", "LifeID002")
                            }
                        };
                        life2.FormattedValues.Add("bupa_titleoptions", "Mrs");
                        life2.FormattedValues.Add("bupa_life_gender", "");


                        Entity life3 = new Entity()
                        {
                            LogicalName = "bupa_customercover",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE60"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_postcode", "W10 4EB"),
                                new KeyValuePair<string, object>("bupa_bupalifeid", "LifeID003"),
                                new KeyValuePair<string, object>("bupa_customercoverid", Guid.NewGuid()),
                                new KeyValuePair<string, object>("bupa_title", "Mr"),
                                new KeyValuePair<string, object>("bupa_firstname", "Son"),
                                new KeyValuePair<string, object>("bupa_lastname", "LifeTest"),
                                new KeyValuePair<string, object>("bupa_middleinitial", "L"),
                                new KeyValuePair<string, object>("bupa_titleoptions", new OptionSetValue(10000000)),
                                new KeyValuePair<string, object>("bupa_agent_life_id", "LifeID003")

                            }
                        };
                        life3.FormattedValues.Add("bupa_titleoptions", "Miss");

                        Entity life4 = new Entity()
                        {
                            LogicalName = "bupa_customercover",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE60"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_postcode", "W10 4EB"),
                                new KeyValuePair<string, object>("bupa_bupalifeid", "LifeID004"),
                                new KeyValuePair<string, object>("bupa_customercoverid", Guid.NewGuid()),
                                new KeyValuePair<string, object>("bupa_title", "Mr"),
                                new KeyValuePair<string, object>("bupa_firstname", "Son2"),
                                new KeyValuePair<string, object>("bupa_lastname", "LifeTest"),
                                new KeyValuePair<string, object>("bupa_middleinitial", "L"),
                                new KeyValuePair<string, object>("bupa_titleoptions", new OptionSetValue(10000000)),
                                new KeyValuePair<string, object>("bupa_agent_life_id", "LifeID004")
                            }
                        };
                        life4.FormattedValues.Add("bupa_titleoptions", "Mr");

                        EntityCollection coll = new EntityCollection();
                        coll.Entities.AddRange(life1, life2, life3, life4);
                        return coll;
                    }

                    else
                    {
                        if (inValidOrder) { return new EntityCollection(); }
                        Entity contact = new Entity()
                        {
                            LogicalName = query.EntityName,
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE55"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_name", "test"),
                                new KeyValuePair<string, object>("bupa_membershipnumber","54132")
                            }
                        };
                        return GetEntityCollection(contact);
                    }
                }

                if (qe.GetType() == typeof(FetchExpression))
                {
                    FetchExpression fe = (FetchExpression)qe;

                    if (fe.Query.Contains("bupa_interactionpermissionconfiguration"))
                    {
                        Entity interaction = new Entity()
                        {
                            LogicalName = "bupa_interactionpermissionconfiguration",
                            Id = new Guid("B1A4B85C-EDF9-E611-80EA-3863BB34DE56"),
                            Attributes = new AttributeCollection
                            {
                                new KeyValuePair<string, object>("bupa_name", "test")
                            }
                        };

                        EntityCollection coll = new EntityCollection();
                        coll.Entities.Add(interaction);
                        return coll;
                    }
                }

                return new EntityCollection();
            });

            _orgService.Stub(x => x.Retrieve(string.Empty, Guid.NewGuid(), new ColumnSet())).IgnoreArguments().Return(new Entity
            {
                LogicalName = "bupa_paymentdetail",
                Attributes = new AttributeCollection {
                    new KeyValuePair<string, object>("bupa_invalidaccountno", invalidAccountNo),
                    new KeyValuePair<string, object>("bupa_invalidsortcode", invalidSortCode),
                    new KeyValuePair<string, object>("bupa_bankname", "SSBI"),
                    new KeyValuePair<string, object>("bupa_bankwizarderrorresponse", "bankwizard lookup message")
                }

            });
        }

        /// <summary>
        /// 
        /// </summary>
        private void SetupCreateExpectations()
        {
            _orgService.Stub(x => x.Create(null)).IgnoreArguments().Do((Func<Entity, Guid>)delegate (Entity entity)
            {
                return Guid.NewGuid();
            });

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="setOrgProxy"></param>
        private void SetUpContextVariables()
        {
            AcceptQuote = MockRepository.GenerateMock<AcceptQuotePlugin>();
            _serviceProvider = MockRepository.GenerateStub<IServiceProvider>();
            _orgService = MockRepository.GenerateStub<IOrganizationService>();
            _serviceFactory = MockRepository.GenerateStub<IOrganizationServiceFactory>();
            _tracingService = MockRepository.GenerateStub<ITracingService>(); ;
            _context = MockRepository.GenerateStub<IPluginExecutionContext>();
        }

        /// <summary>
        /// Set Up Mock Service Objects
        /// </summary>
        /// <param name="serviceProvider"></param>
        /// <param name="crudOperationPlugin"></param>
        private void ExpectMockedServiceProvider(IServiceProvider serviceProvider, AcceptQuotePlugin CreateQuote)
        {
            serviceProvider.Expect(s => s.GetService(typeof(ITracingService))).Return(_tracingService);
            serviceProvider.Expect(s => s.GetService(typeof(IPluginExecutionContext))).Return(_context);
            serviceProvider.Expect(s => s.GetService(typeof(IOrganizationServiceFactory))).Return(_serviceFactory);
            _serviceFactory.Expect(x => x.CreateOrganizationService(Guid.Empty)).Return(_orgService);

            _pluginService = MockRepository.GenerateStub<PluginService>(_serviceProvider);
            _businessLogic = MockRepository.GenerateMock<BusinessLogic>(_pluginService);
        }

        /// <summary>
        /// Set up Plugin Context Stub
        /// </summary>
        /// <param name="attributes"></param>
        private void ExpectPluginContextVariable(string attributes)
        {
            //Input Parameter Collection
            ParameterCollection inputParam = new ParameterCollection();
            KeyValuePair<string, object> target = new KeyValuePair<string, object>("Attributes", attributes);
            KeyValuePair<string, object> IntermediaryReference = new KeyValuePair<string, object>("IntermediaryReference", "123456");
            KeyValuePair<string, object> QuoteSource = new KeyValuePair<string, object>("SalesChannel", "test");
            inputParam.Add(target);
            inputParam.Add(IntermediaryReference);
            inputParam.Add(QuoteSource);

            _context.Stub(x => x.InputParameters).Return(inputParam);
            _context.Stub(x => x.MessageName).Return("bupa_AgreegatorsAcceptQuote");
            _context.Stub(x => x.Depth).Return(1);
            _context.Stub(x => x.OutputParameters).Return(new ParameterCollection());
        }

        /// <summary>
        /// Get Entity Collection
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        private EntityCollection GetEntityCollection(Entity entity)
        {
            EntityCollection coll = new EntityCollection();
            coll.Entities.Add(entity);
            return coll;
        }

        #endregion


    }
}
