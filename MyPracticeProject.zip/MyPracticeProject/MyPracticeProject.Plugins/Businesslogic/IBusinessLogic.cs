﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Enables to abtract business logic
    /// </summary>
    public interface IBusinessLogic : IDisposable
    {
        /// <summary>
        /// Business Logic to process Accept quote request
        /// </summary>
        void PerformAcceptQuoteOperation();
    }
}
