﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Quote information
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Quote
    {
        [JsonProperty(PropertyName = "DateTimeGenerated"), JsonConverter(typeof(IsoDateTimeConverter))]
        public DateTime? bupa_date_time_generated { get; set; }

        [JsonProperty(PropertyName = "AgentCustomerReference")]
        public string bupa_agent_customer_reference { get; set; }

        [JsonProperty(PropertyName = "AgentQuoteReference")]
        public string bupa_agentquotereference { get; set; }

        [JsonProperty(PropertyName = "BupaQuotationRef")]
        public string name { get; set; }

        [JsonProperty(PropertyName = "BupaPolicyNumber")]
        public string bupa_policy_no { get; set; } = null;


        [JsonProperty(PropertyName = "ResubmitReference")]
        public string bupa_resubmitreference { get; set; } = null;

        [JsonProperty(PropertyName = "CommissionID")]
        public string bupa_commissionid_text { get; set; }

        [JsonProperty(PropertyName = "IntermediarySharedData")]
        public string bupa_intermediaryshareddata { get; set; }

        [JsonProperty(PropertyName = "UseExistingPaymentDetails")]
        public string UseExistingPaymentDetails { get; set; }        

        public Agent Agent { get; set; }

        public Applicant Applicant { get; set; }

        public List<QuoteLife> QuoteLife { get; set; }

        public List<CoverCondition> CoverCondition { get; set; }
             
        public CoverFunderClass CoverFunder { get; set; }

        #region # Ignored Json Variables #

        [JsonIgnore]
        public Guid GUID { get; set; }

        [JsonIgnore]
        public string EntityName { get { return Constants.QuoteEntityName; } }

        [JsonIgnore]
        public string bupa_relationshiptocoverlifemainmember { get; set; }  

        [JsonIgnore]
        public bool IsValid { get; set; }

        [JsonIgnore]
        public Guid bupa_resubmitreferenceid { get; set; }

        #endregion

    }
    public class QuoteRequest
    {
        public Quote Quote { get; set; }
    }

}
