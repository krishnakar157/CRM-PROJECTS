﻿using System.Diagnostics.CodeAnalysis;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Bank Details for Direct Debit payment
    /// </summary>
    public class BankDetails
    {       
        public string BankName { get; set; }
        public string SortCode { get; set; }
        public string AccountNumber { get; set; }
        public string TitleCode { get; set; }
        public string Forename { get; set; }
        public string Surname { get; set; }
        public string CompanyName { get; set; }
    }
}
