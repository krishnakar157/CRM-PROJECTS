﻿using Newtonsoft.Json;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Member & applicant Address informations
    /// </summary>
    public class Address
    {
        [JsonProperty(PropertyName = "Line1")]
        public string address1_line1 { get; set; }

        [JsonProperty(PropertyName = "Line2")]
        public string address1_line2 { get; set; }

        [JsonProperty(PropertyName = "Town")]
        public string address1_city { get; set; }

        [JsonProperty(PropertyName = "County")]
        public string address1_county { get; set; }

        [JsonProperty(PropertyName = "Postcode")]
        public string address1_postalcode { get; set; }
    }

    
}
