﻿using Newtonsoft.Json;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Display Inrule messages for Order
    /// </summary>
    public class CoverCondition
    {
        [JsonProperty(PropertyName = "Code")]
        public string bupa_responsecode { get; set; }

        [JsonProperty(PropertyName = "Type")]
        public string bupa_responsetype { get; set; }

        [JsonProperty(PropertyName = "Message")]
        public string bupa_responsemessage { get; set; }

        [JsonProperty(PropertyName = "Title")]
        public string bupa_title { get; set; }

        [JsonProperty(PropertyName = "ShortMessage")]
        public string bupa_shortmessage { get; set; }
    }
}
