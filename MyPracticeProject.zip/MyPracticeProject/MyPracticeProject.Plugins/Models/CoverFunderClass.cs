﻿namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Constains BankDetails, Bill Payer details
    /// </summary>
    public class CoverFunderClass
    {
        public string BillPayerId { get; set; }
        public string PayerRelationshipOther { get; set; } 
        public string AccountType { get; set; }
        public string PaymentType { get; set; }
        public BankDetails BankDetails { get; set; }  
        public Address BankingAddress { get; set; }

        #region Json Ignored
        public string AccountHolderName { get; set; }
        #endregion
    }
}
