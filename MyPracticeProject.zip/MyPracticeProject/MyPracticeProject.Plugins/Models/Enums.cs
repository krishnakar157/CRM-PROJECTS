﻿namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Constains all option set values for fields
    /// </summary>
    public static class Enums
    {
        internal enum Account_Type
        {
            COMPANY = 100000000,
            INDIVIDUAL = 100000001
        };
        public enum Payment_Type
        {            
            DDM = 100000001, // Same value with different name           
            CARD = 100000000,
            CHEQUE = 100000002            
        };
        internal enum ProductType
        {
            BFHINEW = 100000000,
            BFHIXGS = 100000001,
            BFHISWITCH = 100000002,
            BBYXGS = 100000003,
            BBYNEW = 100000004,
            BBYSWITCH = 100000006
        };

        internal enum Relationship_To_Cover_Life_Main_Member
        {
            MAINMEMBER = 100000000,
            PARENTORGUARDIAN = 100000001,
            GROUPSECRETARY = 100000002,
            POWEROFATTORNEYFORAPPLICANTMEMBER = 100000002,
        };
        internal enum Channel
        {
            EMAIL = 100000000,
            SMS = 100000001,
            LETTER = 100000002,
        } 
        internal enum BillPayer
        {
            MAINMEMBER = 100000001,
            APPLICANT = 100000002,
            PARTNER = 100000003,
            OTHER = 100000000,
            CONTRACTHOLDER = 000,
            LIFE = 111
        }

        internal enum BillingAddress
        {
            MAINMEMBER = 100000001,
            APPLICANT = 100000002,
            PARTNER = 100000003,
            OTHER = 100000000           
        }

        internal enum RelationshipToMainMember
        {
            MAINMEMBER = 100000000,
            PARENT = 100000001,
            GROUPSECRETARY = 100000002,
            POWEROFATTORNEY = 100000003,
            LEGALGUARDIAN = 100000004,
            PARTNER = 100000005
        }

        internal enum Quote_ResponseType
        {
            VALIDATIONISSUE = 100000000,
            DECLINATIONREASON = 100000001,
            INFORMATION = 100000002,
            MANDATORYUPDATE = 100000003,
            DISCOUNT = 100000004,
            UNHANDLEDEXCEPTION = 100000005
        }  
        internal enum PaymentDetailStatusReason
        {
            VALIDATED = 100000001,
            VALIDATIONFAILED = 100000002
        } 
        internal enum TitleCode
        {
            AMBASSADOR = 100000000,
            ARCHDEACON = 100000001,
            BARONESS = 100000003,
            BARON = 100000002,
            BRIGADIER = 100000004,
            CANON = 100000005,
            CAPTAIN = 100000006,
            COLONEL = 100000007,
            COUNT = 100000009,
            COUNTESS = 100000010,
            COMMANDER = 100000008,
            DUKE= 100000014,
            DAME = 100000011,
            DUCHESS = 100000013,
            DR = 108550002,
            DEAN = 100000012,
            ENGINEER = 100000016,
            EXECUTORSOF = 100000017,
            EARL = 100000015,
            FATHER = 100000018,
            HONOURABLE = 100000019,
            HRH = 100000020,
            HRHPRINCE = 100000021,
            JUDGE = 100000022,
            LORD= 100000025,
            LADY = 100000023,
            LIEUTENANTCOMMANDER = 100000024,
            MADAM = 100000026,
            MARCHIONESS= 100000028,
            MEMBEROFPARLIAMENT = 100000031,
            MISS = 108550001,
            MRS= 108550006,
            MS= 108550007,
            MAJOR = 100000027,
            MARQUESS = 100000029,
            MASTER = 100000030,
            MR = 108550000,
            OTHER = 108550005,
            PRINCESS = 100000033,
            PROFESSOR = 108550003,
            PRINCE = 100000032,
            REVEREND = 108550004,
            RABBI = 100000034,
            REVERENDCANON = 100000035,
            SIR = 100000036,
            SIRMADAM = 100000037,
            SISTER = 100000038,
            VISCOUNT = 100000039,
            VISCOUNTESS = 100000040
        }

        internal enum MemberType
        {
            MainMember = 100000000,
            Partner = 108550002,
            Child = 100000002
        }

        internal enum BirthSex
        {
            MALE = 1,
            FEMALE = 2,
            UNKNOWN = 100000000
        }
    }
}
