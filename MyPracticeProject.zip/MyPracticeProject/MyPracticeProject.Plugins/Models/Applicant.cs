﻿using Newtonsoft.Json;
using System.Diagnostics.CodeAnalysis;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote.Model
{
    /// <summary>
    /// Applicant information i.e Main member in case of intermediary
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Applicant
    {
        [JsonProperty(PropertyName = "BupaMemberID")]
        public string bupa_applicant_bupamemberid { get; set; }

        [JsonProperty(PropertyName = "TitleCode")]
        public string bupa_applicant_title { get; set; }

        [JsonProperty(PropertyName = "Forename")]
        public string bupa_applicant_forename { get; set; }

        [JsonProperty(PropertyName = "MiddleInitials")]
        public string bupa_applicant_middleinitials { get; set; }

        [JsonProperty(PropertyName = "Surname")]
        public string bupa_applicant_surname { get; set; }

        [JsonProperty(PropertyName = "RelationshipToCoverLifeMainMember")]
        public string bupa_relationshiptocoverlifemainmember { get; set; } //Picklist

        [JsonProperty(PropertyName = "Email")]
        public string bupa_applicant_email { get; set; }

        [JsonProperty(PropertyName = "Phone")]
        public string bupa_applicant_phone { get; set; }

        public MarketingPreferences MarketingPreferences { get; set; }

        public Address Address { get; set; }

        #region # Ignored Json variables #

        [JsonIgnore]
        public string EntityName { get { return "contact"; } }

        [JsonIgnore]
        public string salutation { get; set; }

        [JsonIgnore]
        public string bupa_membership_no { get; set; }

        [JsonIgnore]
        public string firstname { get; set; }

        [JsonIgnore]
        public string middlename { get; set; }

        [JsonIgnore]
        public string lastname { get; set; }

        [JsonIgnore]
        public string emailaddress1 { get; set; }

        [JsonIgnore]
        public string telephone1 { get; set; }
        #endregion

    }
}
