﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Initilaize Plugin execution context
    /// </summary>
    public interface IPluginService
    {
        /// <summary>
        /// Set TracingService object
        /// </summary>
        ITracingService TracingService { get; }

        /// <summary>
        /// Set OrganizationService object
        /// </summary>
        IOrganizationService Service { get; }

        /// <summary>
        /// Set Plugin Context object
        /// </summary>
        IPluginExecutionContext Context { get; }
    }
}
