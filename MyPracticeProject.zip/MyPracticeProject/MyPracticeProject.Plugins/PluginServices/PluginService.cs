﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Initilaize Plugin execution context
    /// </summary>
    public class PluginService: IPluginService
    {
        #region Member Variables
        IPluginExecutionContext _context;
        IOrganizationServiceFactory _serviceFactory;
        IOrganizationService _service;
        ITracingService _tracingService;
        #endregion

        #region Public Properties
        /// <summary>
        /// Tracing service
        /// </summary>
        public ITracingService TracingService { get { return _tracingService; } }

        /// <summary>
        /// Plugin context
        /// </summary>
        public IPluginExecutionContext Context { get { return _context; } }

        /// <summary>
        /// Plugin organization service
        /// </summary>
        public IOrganizationService Service { get { return _service; } }

        #endregion

        #region Public Constructor

        /// <summary>
        /// Instatiate plugin service objects
        /// </summary>
        /// <param name="serviceProvider"></param>
        public PluginService(IServiceProvider serviceProvider)
        {
            _tracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            _context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            _serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            _service = _serviceFactory.CreateOrganizationService(_context.UserId);
        }


        #endregion
    }
}
