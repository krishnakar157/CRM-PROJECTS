﻿using Bupa.Crm.Framework.Common.Logger;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;

using System.Text;
using Microsoft.Crm.Sdk.Messages;
using Bupa.Crm.Plugins.Sales.AcceptQuote.Model;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Contains all constants
    /// </summary>
    public class Constants
    {
        // Trace and Error Messages
   
        internal const string AcceptQuoteLogPrefix = "Bupa.Crm.Plugins.Sales.AcceptQuote";

        internal const string ServiceProviderNullMessage = "{0} : Service provider not set.";
        internal const string StartTracingMessage = "Starting {0}...";
        internal const string StartingBusinessLogic = "Start Business Logic";
        internal const string StopTracingMessage = "Completed {0}.";
        internal const string InvalidPluginExceptionMessage = "{0} : An exception occurred in the plugin.\n Error: {1}.\nStackTrace: {2}";
        internal const string OrganisationServiceFaultExceptionMessage = "{0}: A Service fault occurred in the plug-in.\nError: {1}.\nStackTrace: {2}";
        internal const string GeneralExceptionMessage = "{0} : An exception occurred in the plugin.\nError: {1} - InnerException: {2}.\nStackTrace: {3}";
        internal const string PluginExecutionContextInvalidMessage = "{0}{1} : Plugin execution context is not valid, so not using it.";
        internal const string PluginExecutionContextDepthMessage = "{0} : Plugin depth is greater than expected. Expected {1} but currently {2}. Please contact your System Administrator.";
        internal const string WonQuoteMessage = "{0}Quote is already accepted.";
        internal const string ClosedQuoteMessage = "{0}Quote cannot be accepted as it is in closed state.";
        internal const string DeclinedQuoteMessage = "Due to an error we have unfortunately been unable to complete the Premium calculation for this risk. Please re-submit the risk. If this error persists please contact us for assistance";
        internal const string EnteringMethod = "\n Entering method {0}";
        internal const string ParameterMissing_Attributes = "{0}Attributes is required as a parameter";
        internal const string ValidOptionsetMessage = "{0}Requested value = '{1}' is not valid for optionset {2}";
        internal const string IntemediaryNotFoundMessage = "{0}Intermediary not found with Reference: {1} and Commission ID: {2}";
        internal const string AC001_InvalidIntemediaryMessage = "AC001: The quotation can only be accepted using the same agency number as used for the quotation";
        internal const string AC002_QuoteExpireMessage = "AC002: The quote has expired.Please re-quote and accept against the new quotation";
        internal const string AC003_QuoteNotFoundMessage = "AC003: The quote number can not be matched";
        internal const string AC004_PostCodeMatchMessage = "AC004: Post Codes have been amended. Please re-quote on with the new postcodes and Accept against the revised quotation";
        internal const string AC005_BankDetailInvalidMessage = "AC005: Bank details for the DDM is incomplete. Please update and re-submit Acceptance";
        internal const string AC006_BillingAddressInvalidMessage = "AC006: The address of the DDM Payer is incomplete. Please update and re-submit Acceptance";
        internal const string AC008_BupaLifeIdNotFoundMessage = "AC008: The Bupa Life ID {0} do not match. We are unable to process this acceptance. Please check your data and re-submit";
        internal const string AC009_BupaLifeIdNullMessage = "AC009: The Bupa Life ID(s) have not been included in the message.We are unable to process this acceptance.Please check your data and re-submit";
        internal const string AC010_XgsBusinessPayment = "AC010: We are unable to accept XGS business paid from a company bank account";
        internal const string LifeNotFoundMessage = "{0}Lives not found on quote: {1}";
        internal const string BooleanValueErrorMessage = "{0}Invalid value passed in field: {1}. Only Yes/No are valid";
        internal const string MinimumDataStandardErrorMessage = "{0}V001: The message does not meet our minimum data standards.The following data item has failed validation: {1}-{2}";
        internal const string UploadedDocMessage = "We have already received this evidence, we will re-validate.";
        internal const string GenericExceptionMessage = "The Accept Quote Service is temporarily unavailable, Please retry if unsuccessful contact Service Desk Support Team - Code: {0}";
        internal const string LogPrefix = "Aggregators Plugin ";
        

        internal const string IntermediaryReference = "IntermediaryReference";
        internal const string InvalidIntermediary = "Invalid Intermediary";
        internal const string HandledException = "HandledException";
        internal const string AcceptResponseCode = "AC";        
        internal const string DeclinationReason = "Declination Reason";
        internal const string BbyQuoteType = "BBY";
        internal const string BfhiQuoteType = "BFHI";
        internal const string DentalQuoteType = "Bupa Dental Cover";
        internal const string Source = "Source";
        internal const string ResponseParameter = "Response";    
        internal const int ContinuationTypeXgs = 100000000;    
        internal const string BankAccountNameString = "{0} {1} {2}";
        internal const string QuotesObject = "Quotes";
        internal const string QuoteObject = "Quote";
        internal const string DateTimeGeneratedObject = "DateTimeGenerated";
        internal const string QuotesPathObject = "Quote";
        internal const string AgentPathObject = "Quote/Agent";
        internal const string ApplicantPathObject = "Quote/Applicant";
        internal const string ApplicantAddressPathObject = "Quote/Applicant/Address";
        internal const string QuoteLifePathObject = "Quote/QuoteLife";
        internal const string QuoteLifeAddressPathObject = "Quote/QuoteLife/Address";
        internal const string CoverFunderPathObject = "Quote/CoverFunder";
        internal const string FullNameString = "{0} {1}";
        internal const string AgentCustomerReferenceObject = "AgentCustomerReference";
        internal const string BupaQuotationRefObject = "BupaQuotationRef";
        internal const string CommissionIDObject = "CommissionID";
        internal const string IntermediarySharedDataObject = "IntermediarySharedData";
        internal const string AgentObject = "Agent";
        internal const string AgentReferenceObject = "AgentReference";
        internal const string AgentForenameObject = "AgentForename";
        internal const string Concat = ".";
        internal const string EmptyBraces = "{}";
        internal const string NullString = "null";
        internal const char SlashChar = '/';
        internal const string Space = " ";
        internal const string Hyphen = "-";
        internal const string Amp = "&";
        internal const string Slash = "/";
        internal const string QuestionMark = "?";
        internal const string NotesEntityLogicalName = "annotation";
        internal const string BupaLifeIdTaskField = "bupa_bupalifeid";
        internal const string SubjectNoteField = "subject";
        internal const string TitleNoteField = "subject";
        internal const string DocumentBodyNoteField = "documentbody";
        internal const string MimeTypeNoteField = "mimetype";
        internal const string FileNameNoteField = "filename";
        internal const string ObjectIdNoteField = "objectid";
        internal const string NoteTextNoteField = "notetext";
        internal const string IsDocumentNoteField = "isdocument";
        internal const string ActivityIdField = "activityid";
        internal const string RegardingField = "regardingobjectid";
        internal const string NotesIdField = "annotationid";

        internal const string AgentSurnameObject = "AgentSurname";
        internal const string AgentTelephoneNoObject = "AgentTelephoneNo";
        internal const string AgentEmailAddressObject = "AgentEmailAddress";
        internal const string AgentCompanyNameandDepartmentObject = "AgentCompanyNameandDepartment";
        internal const string ApplicantObject = "Applicant";
        internal const string AddressObject = "Address";
        internal const string PostcodeObject = "Postcode";
        internal const string QuoteLifeObject = "QuoteLife";
        internal const string BillPayerIdObject = "BillPayerId";
        internal const string PayerRelationshipOtherObject = "PayerRelationshipOther";
        internal const string CoverFunderObject = "CoverFunder";        

        internal const string JArray = "JArray";
        internal const string JObject = "JObject";
        internal const string JValue = "JValue";
        internal const string String = "String";

        internal const string Target = "Target";
        internal const string ValidateOrderAction = "bupa_ValidateOrder";
        internal const string PopulateOrderStatusAction = "bupa_SalesPopulateOrderStatus";
        internal const string SetOrderOwnershipAction = "bupa_SalesSetOrderOwnership";

        //Input Params
        internal const string Attributes = "Attributes";
        internal const int MaximumPlugInDepthSize = 8;

        internal const string QuoteEntityName = "quote";
        internal const string LifeEntityName = "bupa_customercover";
        internal const string SalesOrderLogicalName = "salesorder";
        internal const string QuoteResponseEntityName = "bupa_quoteresponse";
        internal const string QuoteProductEntityName = "quotedetail";
        internal const string QuoteCloseEntityName = "quoteclose";
        internal const string ContactLogicalName = "contact";
        internal const string AccountLogicalName = "account";
        internal const string TaskLogicalName = "task";


        internal const string ValidationStatusField = "bupa_validationstatus";
        internal const string Life_QuoteId = "bupa_quotelives";
        internal const string Life_OrderId = "bupa_orderlifeid";
        internal const string ResponseType = "bupa_responsetype";
        internal const string ResponseMessageField = "bupa_responsemessage";
        internal const string OrderField = "bupa_orderid";
        internal const string QuoteLifeField = "bupa_quotelifeid";
        internal const string QuoteGuidField = "quoteid";
        internal const string ResponseCodeField = "bupa_responsecode";
        internal const string ResponseTypeField = "bupa_responsetype";
        internal const string DeclinedResponseCode = "QR056";
        internal const string ContinuationCoverField = "bupa_continuationcoverid";
        internal const string LifeProductConfigField = "bupa_lifeproductionconfigurationid";
        internal const string MonthlyPremiumIncIptField = "bupa_totalmonthlypremium";
        internal const string AnnualPremiumField = "bupa_totalannualpremium";
        internal const string Product_LifeIdField = "quotedetail.bupa_lifeid";
        internal const string Product_MonthlyPremiumWithoutField = "quotedetail.bupa_periodicpremiumexiptvat";
        internal const string Product_MonthlyPremiumIncIptField = "quotedetail.priceperunit";
        internal const string Product_AnnualIPTField = "quotedetail.bupa_annualipt";
        internal const string Product_AnnualPremiumWithoutField = "quotedetail.bupa_annualpremiumexiptvat";
        internal const string Product_AnnualPremiumIncIptField = "quotedetail.bupa_annualpremiuminciptvat";
        internal const string Product_MonthlyIPTField = "quotedetail.bupa_periodicipt";
        internal const string Product_DescriptionField = "quotedetail.productdescription";
        internal const string Product_CoverFunderField = "quotedetail.bupa_coverfunder";
        internal const string QuoteRequestString = "quote";
        internal const string CoverFunderString = "CoverFunder";
        internal const string GUIDString = "GUID";
        internal const string BupaMemberIDString = "BupaMemberID";
        internal const string PafXgsTriageString = "PafXgsTriage";
        internal const string FamilyStatusString = "FamilyStatus";
        internal const string ContinuationIDString = "ContinuationID";
        internal const string MonthlyIPTField = "bupa_monthlyipt";
        internal const string MonthlyPremiumWithoutField = "bupa_monthlypremiumexclipt";
        internal const string AnnualIPTField = "bupa_annualipt";
        internal const string AnnualPremiumWithoutField = "bupa_contractwithoutipt";
        internal const string AnnualPremiumIncIptField = "bupa_contractwithipt";
        internal const string TotalDiscountField = "bupa_totaldiscount";
        internal const string TotalAmountField = "totalamount";
        internal const string CodeField = "bupa_code";
        internal const string QuoteCustomerId = "customerid";
        internal const string FalseText = "false";
        internal const string TrueText = "true";
        internal const string YesText = "yes";
        internal const string NoText = "no";
        internal const string SaveInteractionAction = "bupa_SaveInteractionPermissions";
        internal const string ContactIdParameter = "BGID";
        internal const string InteractionPermissionConfigParameter = "interactionPermissions";
        internal const string SourceSystem = "SourceSystem";
        internal const string SourceSystemDetail = "SourceSystemDetail";
        internal const string InteractionPermissionConfigParameterValue = "[{{'configurationId':'{0}','preference':{1}}}]";
        internal const string IntermediaryReferenceField = "bupa_intermediaryreference";
        internal const string AccountId = "accountid";
        internal const string CrmSwiftBrokerEntityName = "bupa_commission_level";  
        internal const string SwiftBrokerId = "bupa_swiftbroker";
        internal const string CustomEntity_PrimaryFieldName = "bupa_name";
        internal const string BrokerProductType = "bupa_producttype";
        internal const string Discount = "Discount";
        internal const string AggregatorsSourceSystem = "Aggregators";
        internal const string MainMemberString = "MAIN MEMBER";
        internal const string ContinuationTypeNA = "N/A";
        internal const string ContinuationTypeNew = "New";
        internal const string MMYYDateFormat = "MM/yy";
        internal const string QuoteMonthlyPremiumIncIptField = "bupa_totalmonthlypremium";
        internal const string QuoteCreatedOn = "createdon";
        internal const string LifePostCode = "bupa_postcode";
        internal const string LifeId = "bupa_customercoverid";
        internal const string LifeBupaLifeId = "bupa_bupalifeid";
        internal const string LifeFirstName = "bupa_firstname";
        internal const string LifeLastName = "bupa_lastname";
        internal const string LifeTitleCode = "bupa_titleoptions";
        internal const string LifeTitle = "bupa_title";
        internal const string LifeMiddleInitial = "bupa_middleinitial";
        internal const string LifeRelationshipCode = "bupa_relationshipcode";
        internal const string OrderPaymentFrequency = "bupa_payment_freq";
        internal const string QuotePaymentFrequency = "bupa_payment_freq";
        internal const string ApplicantPostCode = "bupa_applicant_address_postcode";
        internal const string ApplicantAddressLine1 = "bupa_applicant_address_line1";
        internal const string ApplicantAddressLine2 = "bupa_applicant_address_line2";
        internal const string ApplicantCity = "bupa_applicant_address_town";
        internal const string ApplicantCounty = "bupa_applicant_address_county";
        internal const string ApplicantForename = "bupa_applicant_forename";
        internal const string ApplicantMiddleInitials = "bupa_applicant_middleinitials";
        internal const string ApplicantSurname = "bupa_applicant_surname";
        internal const string ApplicantPhone = "bupa_applicant_phone";
        internal const string ApplicantEmail = "bupa_applicant_email";
        internal const string ApplicantBupaMemberId = "bupa_applicant_bupamemberid";
        internal const string ApplicantRelationshipToMainMember = "bupa_relationshiptocoverlifemainmember";
        internal const string ApplicantDeclaration18Over = "bupa_declaration_18_or_xover";
        internal const string ApplicantTitle = "bupa_applicant_title";
        internal const string QuoteContinuationType = "bupa_continuationtype";
        internal const string QuoteCoreProduct = "bupa_productoptionid";
        internal const string QuoteAgentId = "bupa_agentid";
        internal const string ContactId = "contactid";
        internal const string ContactFirstName = "firstname";
        internal const string ContactLastName = "lastname";
        internal const string ContactEmailAddress = "emailaddress1";
        internal const string ContactTelephone = "telephone1";
        internal const string ContactAgentReference = "bupa_agentreference";
        internal const string ContactDepartment = "department";
        internal const string LEContactAgentReference = "contact.bupa_agentreference";
        internal const string LEContactFirstName = "contact.firstname";
        internal const string LEContactLastName = "contact.lastname";
        internal const string LEContactTelephone = "contact.telephone1";
        internal const string LEContactEmailAddress = "contact.emailaddress1";
        internal const string LEContactDepartment = "contact.department";
        internal const string LEContactId = "contact.contactid";
        internal const string LEIntemediaryProductType = "bupa_commission_level.bupa_producttype";
        internal const string LEIntemediaryCommissionId = "bupa_commission_level.bupa_name";

        internal const string CIPSourceSystem = "CIP";
        internal const string SalesChannel = "SalesChannel";
        internal const string QuoteIndicativeFlag = "bupa_indicative";
        internal const string QuoteResponseTitle = "bupa_title";
        internal const string QuoteResponseShortMessage = "bupa_shortmessage";
        internal const string LifeBirthSex = "bupa_life_gender";
        internal const string LifeAgentLifeId = "bupa_agent_life_id";
        internal const string JSONBirthSexProperty = "BirthSex";
        internal const string JSONTitleProperty = "Title";
        internal const string JSONShortMessageProperty = "ShortMessage";
        internal const string JSONSalesChannelProperty = "SalesChannel";
        internal const string JSONDistributionChannelProperty = "DistributionChannel";
        internal const string CannotAcceptIndicativeQuoteMesssage = "{0}Indicative Quote cannot be accepted.";
        internal const string QuoteDeclinationReasonTitle = "Error in submission";
        internal const string QuoteDeclinationReasonShortMessage = "An error has occurred, please resubmit the risk.";
        internal const string BrokerChannel = "Broker";
        internal const string DistributionChannel = "DistributionChannel";
        internal const string InvalidDistributionChannel = "{0}Distribution Channel has '{1}' as invalid value";
        internal const string NullDistributionChannel = "{0}Distribution Channel must be supplied";
        internal const string AgentLifeIdNullMessage = "{0}AgentLifeID must be supplied";
        internal const string AgentLifeIdNotFoundMessage = "{0}AgentLifeID has '{1}' as invalid value";

        //Payment Details Fields
        internal const string PaymentDetailsLogicalName = "bupa_paymentdetail";
        internal const string AccountType = "bupa_accounttype";
        internal const string PaymentMethod = "bupa_paymentmethod";
        internal const string PaymentType = "bupa_paymenttype";
        internal const string PaymentNameAttribute = "bupa_name";
        internal const string AccountName = "bupa_accountname";
        internal const string AccountNumber = "bupa_accountnumber";
        internal const string SortCode = "bupa_sortcode";
        internal const string BankName = "bupa_bankname";
        internal const string PaymentDetailsOrderLookupAttribute = "bupa_orderpaymentdetail";
        internal const string CardHolderName = "bupa_cardholdersname";
        internal const string CardNumber = "bupa_cardnumber";
        internal const string StartDate = "bupa_effectivefromdate";
        internal const string EndDate = "bupa_effectivetodate";
        internal const string CCV = "bupa_ccv";
        internal const string Line1 = "bupa_addressline1";
        internal const string Line2 = "bupa_addressline2";
        internal const string Town = "bupa_addresstown";
        internal const string County = "bupa_addresscountry";
        internal const string Postcode = "bupa_addresspostalcode";
        internal const string Amount = "bupa_amount";
        internal const string InvalidAccountNumber = "bupa_invalidaccountno";
        internal const string InvalidSortCode = "bupa_invalidsortcode";
        internal const string BankErrorResponse = "bupa_bankwizarderrorresponse";
        internal const string PaymentDetailStatusCode = "statuscode";
        internal const string LastFourDigit = "bupa_lastfourdigits";

        //Order Fields
        internal const string PaymentTypeOrderField = "bupa_paymenttype";
        internal const string MembershipNumber = "bupa_membershipnumber";
        internal const string IntermediaryStatus = "bupa_intermediarystatus";
        internal const string Applicant = "bupa_applicant";
        internal const string AcceptanceFrequency = "bupa_whatpaymentfrequencyisbeingaccepted";
        internal const string AcceptancePremiumNett = "bupa_confirmthenetpremiumbeingaccepted";
        internal const string AcceptanceIPT = "bupa_confirmtheiptbeingaccepted";
        internal const string AcceptanceVAT = "bupa_confirmthevatbeingaccepted";
        internal const string AcceptancePremiumPayable = "bupa_confirmthegrosspremiumbeingaccepted";
        internal const string CoverFunderID = "bupa_coverfunderid";
        internal const string OrderSource = "bupa_source";
        internal const string AgentQuoteReference = "bupa_agent_quotation_reference";
        internal const string CoverFunder = "bupa_coverfunder";
        internal const string OrderIdAttribute = "salesorderid";
        internal const string StateCode = "statecode";
        internal const string StatusCode = "statuscode";
        internal const string Name = "name";
        internal const string QuoteCloseLogicalName = "quoteclose";
        internal const string QuoteIdAttribute = "quoteid";
        internal const string WonQuoteSubjectField = "subject";
        internal const string WonQuoteSubjectFieldValue = "Customer has accepted the quote.";
        internal const int WinQuoteRequestValue = 4;
        internal const int CancelledOrderStatusValue = 2;
        internal const int CancelledOrderStatusValueRejected = 100000001;
        internal const int CancelledOrderStatusValueSuperseded = 421320000;
        internal const int FailedValidationStatus = 421320001;
        internal const string OrderBillToLine1 = "billto_line1";
        internal const string OrderBillToLine2 = "billto_line2";
        internal const string OrderBillToLine3 = "billto_line3";
        internal const string OrderBillToCity = "billto_city";
        internal const string OrderBillToCounty = "billto_stateorprovince";
        internal const string OrderBillToPostcode = "billto_postalcode";
        internal const string OrderBillToFirstName = "billto_name";
        internal const string OrderBillToLastName = "bupa_billtolastname";
        internal const string OrderBillToTitle = "bupa_billtotitle";
        internal const string OrderBillToRelationshipToMainMember = "bupa_billto_relationshiptomainmember";
        internal const string OrderBillPayer = "bupa_billpayer";
        internal const string OrderBillingAddress = "bupa_billingaddress";
        internal const string OrderAuthorizationToBillLegal = "bupa_authorisationtobilllegal";
        internal const string OrderAuthorizationToBillVerbal = "bupa_authorisationtobill";
        internal const string OrderResubmitReference = "bupa_resubmitreference";

        internal const int Qr_DeclinationReason = 100000001;


        internal const string GetPermissionConfigurationFetchXml = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                      <entity name='bupa_interactionpermissionconfiguration'>
                                                                        <attribute name='bupa_interactionpermissionconfigurationid' />
                                                                        <attribute name='bupa_name' />
                                                                        <attribute name='createdon' />
                                                                        <order attribute='bupa_name' descending='false' />
                                                                        <filter type='and'>
                                                                          <condition attribute='bupa_permissiontext' operator='eq' value='{0}' />
                                                                          <condition attribute='bupa_target' operator='eq' value='100000000' />
                                                                          <condition attribute='bupa_subtarget' operator='eq' value='100000000' />
                                                                        </filter>
                                                                      </entity>
                                                                    </fetch>";

        internal static string[] RemoveAcceptResponseProperty = new string[] {"CoverStartDate", "CoverEndDate", "RelationshipToCoverLifeMainMember", "Declaration18OrOver",
            "MarketingPreferences", "Address", "Account", "PromotionalCodes", "DateOfBirth", "BirthSex", "Relationship", "Smoker", "Occupation", "ProfessionalSportsperson", "RegGP6Months", "UKResident",
            "RequiredUnderwriting", "CoverID", "ContinuationID", "email", "phone", "TaxExempt", "FamilyStatus", "CoverContinuationLife", "ProductConfig", "GUID", "PafXgsTriage", "CoverFunder" };

        internal static string[] QuoteColumnSet = new string[] { QuoteCustomerId, StateCode, QuotePaymentFrequency, QuoteCreatedOn, QuoteMonthlyPremiumIncIptField, ApplicantAddressLine1, ApplicantAddressLine2, ApplicantCity, ApplicantCounty, ApplicantPostCode, QuoteContinuationType, QuoteCoreProduct, ApplicantForename, ApplicantMiddleInitials, ApplicantSurname, ApplicantPhone, ApplicantEmail, ApplicantBupaMemberId,  ApplicantRelationshipToMainMember,ApplicantDeclaration18Over, ApplicantTitle, OrderResubmitReference, QuoteIndicativeFlag};

        internal static string[] PaymentDetailColumnSet = new string[] { PaymentType, PaymentMethod, AccountName, AccountNumber, SortCode, BankName, PaymentDetailsOrderLookupAttribute, AccountType, Amount, LastFourDigit };
 }



    /// <summary>
    /// Contains common methods
    /// </summary>
    public static class ProjectCommonFunctions
    {
        #region Query
        internal static EntityCollection QueryByFetchXml(IOrganizationService service, string xmlString)
        {
            return service.RetrieveMultiple(new FetchExpression(xmlString));
        }
        #endregion

        /// <summary>
        ///  resolves PermissionConfiguration entity's lookup by accepting type as parameter 
        /// </summary>
        /// <param name="service">Organization Service</param>
        /// <param name="type"></param>
        /// <returns>Entity Object</returns>
        internal static Entity GetPermissionConfiguration(IOrganizationService service, string permissionText)
        {
            Entity entPermissionConfiguration = null;
            string strFetchXml = string.Format(Constants.GetPermissionConfigurationFetchXml, permissionText);
            EntityCollection ecentProductOptionConfiguration = QueryByFetchXml(service, strFetchXml);
            if (ecentProductOptionConfiguration != null && ecentProductOptionConfiguration.Entities.Count > 0)
                entPermissionConfiguration = ecentProductOptionConfiguration.Entities.FirstOrDefault();
            return entPermissionConfiguration;
        }


        /// <summary>
        /// Resolve Entity lookup field by accepting entityName, Value and attribute name.
        /// </summary>
        /// <param name="Service">Organization Service</param>
        /// <param name="entityName"></param>
        /// <param name="value"></param>
        /// <param name="name"></param>
        /// <returns>Entity Object</returns>
        internal static Entity RetrieveQuote(IOrganizationService Service, string entityName, string value, string name, string[] columns, string source)
        {
            Entity enRecord = null;
            QueryExpression query = new QueryExpression();
            query.ColumnSet = new ColumnSet(columns);
            query.EntityName = entityName;
            query.Criteria = new FilterExpression()
            {
                Conditions ={new ConditionExpression()
                {
                    AttributeName = name,
                    Operator = ConditionOperator.Equal,
                    Values = { value }
                }},
            };

            //Get Agent details
            LinkEntity agentLinkEntity = query.AddLink(Constants.ContactLogicalName, Constants.QuoteAgentId, Constants.ContactId, JoinOperator.LeftOuter);
            agentLinkEntity.EntityAlias = Constants.ContactLogicalName;
            agentLinkEntity.Columns = new ColumnSet(Constants.ContactId, Constants.ContactFirstName, Constants.ContactLastName, Constants.ContactEmailAddress, Constants.ContactTelephone, Constants.ContactAgentReference, Constants.ContactDepartment);

            //Quote Details
            var query_quote = query.AddLink(Constants.QuoteEntityName, Constants.OrderResubmitReference, Constants.QuoteGuidField, JoinOperator.LeftOuter);
            query_quote.EntityAlias = Constants.QuoteGuidField;
            var resubmitsalesorder = query_quote.AddLink(Constants.SalesOrderLogicalName, Constants.QuoteGuidField, Constants.QuoteGuidField, JoinOperator.LeftOuter);
            resubmitsalesorder.EntityAlias = Constants.SalesOrderLogicalName;
            resubmitsalesorder.Columns.AddColumns(Constants.StateCode, Constants.StatusCode, Constants.OrderIdAttribute, Constants.Name);

            //Get Order - Payment details
            var resubmitsalesorder_bupa_paymentdetail = resubmitsalesorder.AddLink(Constants.PaymentDetailsLogicalName, Constants.OrderIdAttribute, Constants.PaymentDetailsOrderLookupAttribute, JoinOperator.LeftOuter);
            resubmitsalesorder_bupa_paymentdetail.EntityAlias = Constants.PaymentDetailsLogicalName;
            resubmitsalesorder_bupa_paymentdetail.Columns.AddColumns(Constants.PaymentDetailColumnSet);           

            EntityCollection ecRecords = Service.RetrieveMultiple(query);
            if (ecRecords != null && ecRecords.Entities.Count > 0)
            {
                if (source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
                {
                    enRecord = ecRecords.Entities.Where(rec => rec.GetAttributeValue<bool>(Constants.QuoteIndicativeFlag) == false).FirstOrDefault();
                    if (enRecord == null)
                    {
                        throw new InvalidPluginExecutionException(string.Format(Constants.CannotAcceptIndicativeQuoteMesssage, Constants.HandledException));
                    }
                }
                else
                {
                    enRecord = ecRecords.Entities[0];
                }
            }
                     
            return enRecord;
        }
       

        /// <summary>
        /// Trigger Save Interaction Permission History Action
        /// </summary>
        /// <param name="Service">Organization Service</param>
        /// <param name="contactId"></param>
        /// <param name="configId"></param>
        /// <param name="value"></param>
        internal static void TriggerSaveAction(IOrganizationService service, Guid contactId, Guid configId, string value)
        {
            string preference = (value == Constants.YesText) ? Constants.TrueText : Constants.FalseText;

            OrganizationRequest saveInteractionPermissionHistory = new OrganizationRequest(Constants.SaveInteractionAction);
            //Input parameters required by the action
            saveInteractionPermissionHistory[Constants.ContactIdParameter] = contactId.ToString();
            saveInteractionPermissionHistory[Constants.InteractionPermissionConfigParameter] = string.Format(Constants.InteractionPermissionConfigParameterValue, configId, preference); ;
            saveInteractionPermissionHistory[Constants.SourceSystem] = Constants.AggregatorsSourceSystem;
            saveInteractionPermissionHistory[Constants.SourceSystemDetail] = Constants.AggregatorsSourceSystem;

            OrganizationResponse response = service.Execute(saveInteractionPermissionHistory);
        }


        /// <summary>
        /// GetOptionSetValue
        /// </summary>
        /// <param name="value"></param>
        /// <param name="T"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static OptionSetValue GetOptionSetValue(string value, Type T, string fieldName)
        {
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    OptionSetValue option = new OptionSetValue();
                    var relationshipCode = System.Enum.Parse(T, value.Replace(Constants.Space, string.Empty).Replace(Constants.Hyphen, string.Empty).Replace(Constants.Amp, string.Empty).Replace(Constants.Slash, string.Empty).Replace(Constants.QuestionMark, string.Empty).ToUpper());
                    option.Value = (int)relationshipCode;//picklist
                    return option;
                }
                return null;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.ValidOptionsetMessage, Constants.HandledException, value, fieldName));
            }
        }

        /// <summary>
        /// GetOptionSetValueInString
        /// </summary>
        /// <param name="value"></param>
        /// <param name="T"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        public static string GetOptionSetValueInString(string value, Type T, string fieldName)
        {
            try
            {
                if (!string.IsNullOrEmpty(value))
                {
                    var relationshipCode = System.Enum.Parse(T, value.Replace(Constants.Space, string.Empty).Replace(Constants.Hyphen, string.Empty).Replace(Constants.Amp, string.Empty).Replace(Constants.Slash, string.Empty).Replace(Constants.QuestionMark, string.Empty).ToUpper());
                    
                    return relationshipCode.ToString();
                }
                return string.Empty;
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.ValidOptionsetMessage, Constants.HandledException, value, fieldName));
            }
        }

        /// <summary>
        /// Retrieves Intermediary based on intermediary ref, commission id and 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="intermediaryRef"></param>
        /// <param name="quote"></param>
        /// <returns></returns>
        internal static Entity GetIntermediary(IOrganizationService service, string intermediaryRef, Quote quote, Entity quoteEntity)
        {
            Entity intermediary = null;

            QueryExpression query = new QueryExpression()
            {
                ColumnSet = new ColumnSet(Constants.AccountId),
                EntityName = Constants.AccountLogicalName,
                Criteria = new FilterExpression()
                {
                    Conditions =
                    {
                       new ConditionExpression(){
                           AttributeName = Constants.IntermediaryReferenceField,
                           Operator=ConditionOperator.Equal,
                           Values={ intermediaryRef }
                       }
                    }
                }
            };
            query.AddLink(Constants.CrmSwiftBrokerEntityName, Constants.AccountId, Constants.SwiftBrokerId, JoinOperator.LeftOuter);
            query.LinkEntities[0].EntityAlias = Constants.CrmSwiftBrokerEntityName;
            query.LinkEntities[0].Columns = new ColumnSet(Constants.CustomEntity_PrimaryFieldName, Constants.BrokerProductType);
            query.LinkEntities[0].LinkCriteria = new FilterExpression()
            {
                Conditions =
                    {
                       new ConditionExpression()
                       {
                           AttributeName=Constants.CustomEntity_PrimaryFieldName,
                           Operator=ConditionOperator.Equal,
                           Values = { quote.bupa_commissionid_text }
                       }
                    }
            };

            //ProductType condition
            string continuationType = quoteEntity.FormattedValues[Constants.QuoteContinuationType].ToString().Equals(Constants.ContinuationTypeNA) ? Constants.ContinuationTypeNew : quoteEntity.FormattedValues[Constants.QuoteContinuationType].ToString();
            var quoteProductType = GetOptionSetValue(quoteEntity.GetAttributeValue<EntityReference>(Constants.QuoteCoreProduct).Name + continuationType, typeof(Enums.ProductType), Constants.BrokerProductType);

            query.LinkEntities[0].LinkCriteria.AddCondition(new ConditionExpression {
                AttributeName = Constants.BrokerProductType,
                Operator = ConditionOperator.Equal,
                Values = { quoteProductType.Value }
            });


            EntityCollection ecentProductOptionConfiguration = service.RetrieveMultiple(query);
            if (ecentProductOptionConfiguration != null && ecentProductOptionConfiguration.Entities.Count > 0)
                intermediary = ecentProductOptionConfiguration.Entities.FirstOrDefault();
            return intermediary;
        } 
        
        /// <summary>
        /// Retrieves Quote Response
        /// </summary>
        /// <param name="quote">Quote</param>
        /// <param name="service">OrganizationService</param>
        /// <returns>Quote Response Collection</returns>
        internal static EntityCollection GetQuoteResponse(Entity order, IOrganizationService service)
        {
            EntityCollection conditions = new EntityCollection();

            QueryExpression query = new QueryExpression()
            {
                ColumnSet = new ColumnSet(true),
                EntityName = Constants.QuoteResponseEntityName,
                Criteria = new FilterExpression()
                {
                    FilterOperator = LogicalOperator.Or,
                    Conditions ={
                            new ConditionExpression()
                            {
                                AttributeName=Constants.OrderField,
                                Operator=ConditionOperator.Equal,
                                Values={order.Id},
                            }
                        }
                }
            };
            

            conditions = service.RetrieveMultiple(query);
            return conditions;
        }

        /// <summary>
        /// Deserialize json with Quote
        /// </summary>
        /// <param name="jsonString"></param>
        /// <returns></returns>
        internal static Quote DeserializeJson(string jsonString)
        {
            
            QuoteRequest TargetObject = JsonConvert.DeserializeObject<QuoteRequest>(jsonString);
            Quote quote = TargetObject.Quote;
            return quote;
        }

        /// <summary>
        /// Set Last four digit of account number
        /// This info is captured to show on Engage form
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        internal static string SetLastFourDigitOfAccountNumber(string accountNumber)
        {
            if(string.IsNullOrEmpty(accountNumber)) return string.Empty;            
            string fourDigits = accountNumber.Substring(accountNumber.Length - 4);
            return fourDigits;
        }

        /// <summary>
        /// Retrieve all quote live by quote id
        /// </summary>
        /// <param name="pluginService"></param>
        /// <param name="quote"></param>
        /// <returns></returns>
        internal static EntityCollection GetQuoteLives(IPluginService pluginService, Entity quote)
        {
            EntityCollection livesCollection = new EntityCollection();

            QueryExpression query = new QueryExpression(Constants.LifeEntityName);
            query.ColumnSet.AddColumns(Constants.LifePostCode, Constants.LifeId, Constants.LifeBupaLifeId, Constants.LifeFirstName, Constants.LifeLastName, Constants.LifeMiddleInitial, Constants.LifeTitle, Constants.LifeTitleCode, Constants.LifeRelationshipCode, Constants.LifeBirthSex, Constants.LifeAgentLifeId );
            query.Criteria.AddCondition(Constants.Life_QuoteId, ConditionOperator.Equal, quote.Id);

            var lives = pluginService.Service.RetrieveMultiple(query);

            if(lives.Entities.Count > 0)
            {
                livesCollection = lives;
            }
            else
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.LifeNotFoundMessage, Constants.HandledException, quote.Id));
            }
            return livesCollection;
        }

        /// <summary>
        /// Set two options field
        /// </summary>
        /// <param name="Value"></param>
        /// <param name="fieldName"></param>
        /// <returns></returns>
        internal static bool TwoOption(string Value, string fieldName)
        {
            //  string lifetype = Value;
            Value = Value.Trim();
            switch (Value.ToLower())
            {
                case Constants.YesText:
                    return true;
                case Constants.NoText:
                    return false;
                default:
                    throw new InvalidPluginExecutionException(string.Format(Constants.BooleanValueErrorMessage, Constants.HandledException, fieldName));
            }
        }

        /// <summary>
        /// Format postcode value
        /// </summary>
        /// <param name="postCode"></param>
        /// <returns></returns>
        internal static string FormatPostcode(string postCode)
        {
            string postcodeString = string.Empty;

            if (!string.IsNullOrEmpty(postCode))
            {
                postcodeString = postCode.ToLower().Replace(Constants.Space, string.Empty);
                return postcodeString;
            }
            return postcodeString;
        }

        /// <summary>
        /// Field level null checks. Throw error if null
        /// </summary>
        /// <param name="pathName"></param>
        /// <param name="fieldName"></param>
        /// <param name="fieldValue"></param>
        public static void FieldLevelNullCheck(string pathName, string fieldName, dynamic requestObj)
        {
            bool nullCheck = false;
            var parents = pathName.Split(Constants.SlashChar);
            var request = requestObj;

            if(IsNullOrEmpty(request))
            {
                nullCheck = true;
            }
            //Handle Quotes/Quote field                       
            else if (fieldName.Equals(Constants.QuoteObject))
            {
                nullCheck = IsNullOrEmpty(request[fieldName]);
            }
            //Handle fields under Quote. Eg: Quotes/Quote/DateTimeGenerated
            else if (!fieldName.Equals(Constants.QuoteObject))
            {
                var quoteRequest = request.GetType().Name.Equals(Constants.JArray) ? request : request[Constants.QuoteObject];

                //If field is of array type
                if (request.GetType().Name.Equals(Constants.JArray))
                {
                    foreach (var arr in request)
                    {
                        nullCheck = parents.Count() == 2 ? IsNullOrEmpty(arr[fieldName]) :
                                    parents.Count() == 3 ? IsNullOrEmpty(arr[parents[2]][fieldName]) :
                                    false;

                        if (nullCheck)
                            break;
                    }
                }
                else
                {
                    nullCheck = parents.Count() == 1 ? IsNullOrEmpty(quoteRequest[fieldName]) :
                                parents.Count() == 2 ? IsNullOrEmpty(quoteRequest[parents[1]][fieldName]) :
                                parents.Count() == 3 ? IsNullOrEmpty(quoteRequest[parents[1]][parents[2]][fieldName]) :
                                false;
                }
            }

            if (nullCheck)
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.MinimumDataStandardErrorMessage, Constants.HandledException, pathName, fieldName));
            }
        }

        /// <summary>
        /// Check if value is null or empty
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        public static bool IsNullOrEmpty(object obj)
        {
            if (obj == null)
                return true;

            var type = obj.GetType().Name;

            if (type.Equals(Constants.JValue))
            {
                return string.IsNullOrEmpty(obj.ToString()) || obj.ToString().Equals(Constants.EmptyBraces) || obj.ToString().Equals(Constants.NullString);
            }
            else if (type.Equals(Constants.JObject))
            {
                var jObj = (JObject)obj;
                return jObj == null || jObj.Properties().Count() == 0;
            }
            else if (type.Equals(Constants.JArray))
            {
                return ((JArray)obj).Count == 0;
            }
            else if (type.Equals(Constants.String))
            {
                return string.IsNullOrEmpty(obj.ToString()) || obj.ToString().Equals(Constants.EmptyBraces) || obj.ToString().Equals(Constants.NullString);
            }
            return false;
        }

        /// <summary>
        /// Return option set value from Aliased value in entity collection
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="fieldName"></param>
        /// <returns>Returns option value object or default value as -1 in case of null</returns>
        public static OptionSetValue GetOptionSetFromAliasedValue(Entity entity, string fieldName)
        {
            return entity.Contains(fieldName)? ((OptionSetValue)entity.GetAttributeValue<AliasedValue>(fieldName).Value): new OptionSetValue(-1);                
        }


        /// <summary>
        /// Retrieves Intermediary based on intermediary ref, commission id and 
        /// </summary>
        /// <param name="service"></param>
        /// <param name="intermediaryRef"></param>
        /// <param name="quote"></param>
        /// <returns></returns>
        internal static EntityCollection RetrieveTasksForOrder(IOrganizationService service,  Guid orderId)
        {            
            QueryExpression query = new QueryExpression()
            {
                ColumnSet = new ColumnSet(true),
                EntityName = Constants.TaskLogicalName,
                Criteria = new FilterExpression()
                {
                    Conditions =
                    {
                       new ConditionExpression(){
                           AttributeName = Constants.RegardingField,
                           Operator=ConditionOperator.Equal,
                           Values={ orderId }
                       },
                       new ConditionExpression(){
                           AttributeName = Constants.ValidationStatusField,
                           Operator=ConditionOperator.NotEqual,
                           Values={ Constants.FailedValidationStatus }
                       }
                    }
                }
            };
            query.AddLink(Constants.NotesEntityLogicalName, Constants.ActivityIdField, Constants.ObjectIdNoteField, JoinOperator.LeftOuter);
            query.LinkEntities[0].EntityAlias = Constants.NotesEntityLogicalName;
            query.LinkEntities[0].Columns = new ColumnSet(true);
                       
            EntityCollection tasks = service.RetrieveMultiple(query);
            
            return tasks;
        }

        /// <summary>
        /// Throw GenericExceptionMessage message instead of actual exception
        /// </summary>
        /// <param name="tracing"></param>
        /// <param name="logService"></param>
        /// <param name="pluginName"></param>
        /// <param name="groupName"></param>
        /// <param name="details"></param>
        /// <param name="extraInfo"></param>
        internal static void ThrowGenericException(ITracingService tracing, ILogger logService, string pluginName, string groupName, string details, string extraInfo)
        {
            Guid logId = Guid.Empty;

            if (logService != null)
            {
                 logId = logService.WriteLog(pluginName, details, groupName, LogLevel.Error, extraInfo);
                tracing.Trace(details);
            }
            string genericErrorMessage = string.Format(Constants.GenericExceptionMessage, logId.ToString());
            throw new InvalidPluginExecutionException(genericErrorMessage);
        }
    }
}
