﻿using Bupa.Crm.Plugins.Sales.AcceptQuote.Model;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace Bupa.Crm.Plugins.Sales.AcceptQuote
{
    /// <summary>
    /// Handles logic for Accept Quote.
    /// </summary>
    public class AcceptQuoteHelper
    {
        #region Member Variables
        private IPluginService _pluginService;
        private EntityCollection lifeCollection;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="organisationService"></param>
        /// <param name="target"></param>
        /// <param name="tracingService"></param>
        public AcceptQuoteHelper(IPluginService pluginService)
        {
            _pluginService = pluginService;
        }
        #endregion

        /// <summary>
        /// Creates Payment Detail
        /// </summary>
        /// <param name="quote">Quote</param>
        /// <param name="salesOrder">Sales order entity</param>
        public Guid CreatePaymentDetail(Quote quote, Entity salesOrder, Entity quoteEntity)
        {            
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            Entity payment = new Entity(Constants.PaymentDetailsLogicalName);
            payment[Constants.PaymentType] = ProjectCommonFunctions.GetOptionSetValue(quote.CoverFunder.PaymentType, typeof(Enums.Payment_Type), Constants.PaymentType);
            payment[Constants.PaymentMethod] = quote.CoverFunder.PaymentType;
            payment[Constants.AccountName] = quote.bupa_resubmitreferenceid != Guid.Empty && !string.IsNullOrEmpty(quote.CoverFunder.AccountHolderName) ? quote.CoverFunder.AccountHolderName : string.Format(Constants.BankAccountNameString, quote.CoverFunder.BankDetails.TitleCode, quote.CoverFunder.BankDetails.Forename, quote.CoverFunder.BankDetails.Surname);
            payment[Constants.AccountNumber] = quote.CoverFunder.BankDetails.AccountNumber;
            payment[Constants.SortCode] = quote.CoverFunder.BankDetails.SortCode;
            payment[Constants.BankName] = quote.CoverFunder.BankDetails.BankName;
            payment[Constants.PaymentDetailsOrderLookupAttribute] = salesOrder.ToEntityReference();
            payment[Constants.AccountType] = ProjectCommonFunctions.GetOptionSetValue(quote.CoverFunder.AccountType, typeof(Enums.Account_Type), Constants.AccountType);
            payment[Constants.Amount] = quoteEntity.GetAttributeValue<Money>(Constants.QuoteMonthlyPremiumIncIptField);
            payment[Constants.LastFourDigit] = ProjectCommonFunctions.SetLastFourDigitOfAccountNumber(quote.CoverFunder.BankDetails.AccountNumber);

            Guid id = _pluginService.Service.Create(payment);
            return id;
        }

        /// <summary>
        /// Update Coverfunder details on Order
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="applicantId"></param>
        /// <param name="salesOrder"></param>
        /// <param name="source"></param>
        public void UpdateOrder(Quote quote, Guid applicantId, Entity salesOrder, string source, Entity quoteEntity)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            salesOrder[Constants.AgentQuoteReference] = quote.bupa_agentquotereference;
            salesOrder[Constants.IntermediaryStatus] = new OptionSetValue(108550004);
            salesOrder[Constants.Applicant] = new EntityReference(Constants.ContactLogicalName, applicantId);
            salesOrder[nameof(quote.bupa_intermediaryshareddata)] = ProjectCommonFunctions.TwoOption(quote.bupa_intermediaryshareddata, nameof(quote.bupa_intermediaryshareddata));
            salesOrder[Constants.OrderPaymentFrequency] = quoteEntity.GetAttributeValue<OptionSetValue>(Constants.QuotePaymentFrequency);
            salesOrder[Constants.PaymentTypeOrderField] = ProjectCommonFunctions.GetOptionSetValue(quote.CoverFunder.PaymentType, typeof(Enums.Payment_Type), Constants.PaymentType);

            salesOrder[Constants.OrderSource] = source;

            if (quote.bupa_resubmitreferenceid != Guid.Empty)
            {
                salesOrder[Constants.OrderResubmitReference] = new EntityReference(Constants.SalesOrderLogicalName, quote.bupa_resubmitreferenceid);
            }

            #region Billing Information

            var billPayer = ProjectCommonFunctions.GetOptionSetValueInString(quote.CoverFunder.BillPayerId, typeof(Enums.BillPayer), nameof(Enums.BillPayer));

            salesOrder[Constants.OrderBillPayer] = billPayer.Equals(nameof(Enums.BillPayer.CONTRACTHOLDER)) ? new OptionSetValue((int)Enums.BillPayer.MAINMEMBER)
                                                   : billPayer.Equals(nameof(Enums.BillPayer.LIFE)) ? new OptionSetValue((int)Enums.BillPayer.PARTNER)
                                                   : ProjectCommonFunctions.GetOptionSetValue(quote.CoverFunder.BillPayerId, typeof(Enums.BillPayer), nameof(quote.CoverFunder.BillPayerId));


            salesOrder[Constants.OrderBillingAddress] = billPayer.Equals(nameof(Enums.BillPayer.CONTRACTHOLDER)) || billPayer.Equals(nameof(Enums.BillPayer.MAINMEMBER)) ? new OptionSetValue((int)Enums.BillingAddress.MAINMEMBER)
                                                         : (billPayer.Equals(nameof(Enums.BillPayer.LIFE)) || billPayer.Equals(nameof(Enums.BillPayer.PARTNER))) ? new OptionSetValue((int)Enums.BillingAddress.PARTNER)
                                                         : billPayer.Equals(nameof(Enums.BillPayer.APPLICANT)) ? new OptionSetValue((int)Enums.BillingAddress.APPLICANT)
                                                         : billPayer.Equals(nameof(Enums.BillPayer.OTHER)) ? new OptionSetValue((int)Enums.BillingAddress.OTHER)
                                                         : null;


            salesOrder[Constants.OrderBillToRelationshipToMainMember] = billPayer.Equals(nameof(Enums.BillPayer.PARTNER)) || billPayer.Equals(nameof(Enums.BillPayer.LIFE))
                                                                        ? new OptionSetValue((int)Enums.RelationshipToMainMember.PARTNER)
                                                                        : !string.IsNullOrEmpty(quote.CoverFunder.PayerRelationshipOther) && billPayer.Equals(nameof(Enums.BillPayer.OTHER)) || billPayer.Equals(nameof(Enums.BillPayer.APPLICANT)) ? ProjectCommonFunctions.GetOptionSetValue(quote.CoverFunder.PayerRelationshipOther, typeof(Enums.RelationshipToMainMember), nameof(quote.CoverFunder.PayerRelationshipOther))
                                                                        : null;

            var relationshipToMainMember = salesOrder[Constants.OrderBillToRelationshipToMainMember] != null ? ((OptionSetValue)salesOrder[Constants.OrderBillToRelationshipToMainMember]).Value : (int)Enums.RelationshipToMainMember.MAINMEMBER;

            salesOrder[Constants.OrderAuthorizationToBillVerbal] = relationshipToMainMember.Equals((int)Enums.RelationshipToMainMember.PARENT) || relationshipToMainMember.Equals((int)Enums.RelationshipToMainMember.PARTNER) ? true : false;

            salesOrder[Constants.OrderAuthorizationToBillLegal] = relationshipToMainMember.Equals((int)Enums.RelationshipToMainMember.POWEROFATTORNEY) || relationshipToMainMember.Equals((int)Enums.RelationshipToMainMember.LEGALGUARDIAN) ? true : false;

            
            //Billing Address
            salesOrder[Constants.OrderBillToLine1] = quote.CoverFunder.BankingAddress.address1_line1;
            salesOrder[Constants.OrderBillToLine2] = quote.CoverFunder.BankingAddress.address1_line2;
            salesOrder[Constants.OrderBillToCity] = quote.CoverFunder.BankingAddress.address1_city;
            salesOrder[Constants.OrderBillToCounty] = quote.CoverFunder.BankingAddress.address1_county;
            salesOrder[Constants.OrderBillToPostcode] = quote.CoverFunder.BankingAddress.address1_postalcode;
            
            salesOrder[Constants.OrderBillToTitle] = quote.CoverFunder.BankDetails != null && !string.IsNullOrEmpty(quote.CoverFunder.BankDetails.TitleCode) ? ProjectCommonFunctions.GetOptionSetValue(quote.CoverFunder.BankDetails.TitleCode, typeof(Enums.TitleCode), nameof(quote.CoverFunder.BankDetails.TitleCode)) : null;
            salesOrder[Constants.OrderBillToFirstName] = quote.CoverFunder.BankDetails != null ? quote.CoverFunder.BankDetails.Forename : string.Empty;
            salesOrder[Constants.OrderBillToLastName] = quote.CoverFunder.BankDetails != null ? quote.CoverFunder.BankDetails.Surname : string.Empty;

            #endregion

            _pluginService.Service.Update(salesOrder);
        }

        /// <summary>
        /// Converts Quote To Order
        /// </summary>
        /// <param name="quoteEntity"></param>
        /// <returns>Sales order entity</returns>
        public Entity ConvertQuoteToOrder(Entity quoteEntity)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            Entity salesOrder = new Entity(Constants.SalesOrderLogicalName);
            ConvertQuoteToSalesOrderRequest convertQuoteRequest =
                new ConvertQuoteToSalesOrderRequest()
                {
                    QuoteId = quoteEntity.Id,
                    ColumnSet = new ColumnSet(Constants.OrderIdAttribute)
                };

            ConvertQuoteToSalesOrderResponse convertQuoteResponse = (ConvertQuoteToSalesOrderResponse)_pluginService.Service.Execute(convertQuoteRequest);
            salesOrder = (Entity)convertQuoteResponse.Entity;

            return salesOrder;
        }

        /// <summary>
        /// Creates Applicant entity
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteEntity"></param>
        /// <returns>Guid of Applicant</returns>
        public Guid CreateApplicant(Quote quote, Entity quoteEntity, string source)
        {
            Entity ApplicantEntity = new Entity(quote.Applicant.EntityName);

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.salutation), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_title) ?
               quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_title)) : quote.Applicant.bupa_applicant_title));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.firstname), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_forename) ?
                quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_forename)) : quote.Applicant.bupa_applicant_forename));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.middlename), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_middleinitials) ?
                quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_middleinitials)) : quote.Applicant.bupa_applicant_middleinitials));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.lastname), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_surname) ?
                quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_surname)) : quote.Applicant.bupa_applicant_surname));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.telephone1), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_phone) ?
                quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_phone)) : quote.Applicant.bupa_applicant_phone));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.emailaddress1), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_email) ?
                quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_email)) : quote.Applicant.bupa_applicant_email));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.bupa_membership_no), string.IsNullOrEmpty(quote.Applicant.bupa_applicant_bupamemberid) ?
                quoteEntity.GetAttributeValue<string>(nameof(quote.Applicant.bupa_applicant_bupamemberid)) : quote.Applicant.bupa_applicant_bupamemberid));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.Address.address1_line1), string.IsNullOrEmpty(quote.Applicant.Address.address1_line1) ?
                quoteEntity.GetAttributeValue<string>(Constants.ApplicantAddressLine1) : quote.Applicant.Address.address1_line1));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.Address.address1_line2), string.IsNullOrEmpty(quote.Applicant.Address.address1_line2) ?
                quoteEntity.GetAttributeValue<string>(Constants.ApplicantAddressLine2) : quote.Applicant.Address.address1_line2));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.Address.address1_city), string.IsNullOrEmpty(quote.Applicant.Address.address1_city) ?
                quoteEntity.GetAttributeValue<string>(Constants.ApplicantCity) : quote.Applicant.Address.address1_city));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.Address.address1_county), string.IsNullOrEmpty(quote.Applicant.Address.address1_county) ?
                quoteEntity.GetAttributeValue<string>(Constants.ApplicantCounty) : quote.Applicant.Address.address1_county));

            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.Applicant.Address.address1_postalcode), string.IsNullOrEmpty(quote.Applicant.Address.address1_postalcode) ?
                quoteEntity.GetAttributeValue<string>(Constants.ApplicantPostCode) : quote.Applicant.Address.address1_postalcode));

            //Picklist
            ApplicantEntity.Attributes.Add(new KeyValuePair<string, object>(nameof(quote.bupa_relationshiptocoverlifemainmember), string.IsNullOrEmpty(quote.bupa_relationshiptocoverlifemainmember) ?
                quoteEntity.GetAttributeValue<OptionSetValue>(nameof(quote.Applicant.bupa_relationshiptocoverlifemainmember)) :
                ProjectCommonFunctions.GetOptionSetValue(quote.Applicant.bupa_relationshiptocoverlifemainmember, typeof(Enums.Relationship_To_Cover_Life_Main_Member), nameof(quote.bupa_relationshiptocoverlifemainmember))));

            Guid applicantId = _pluginService.Service.Create(ApplicantEntity);

            #region Marketing Preference
            if (!source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
            {
                string permissionText = quote.Applicant.MarketingPreferences.bupa_permissiontext;
                Entity permissionConfig = ProjectCommonFunctions.GetPermissionConfiguration(_pluginService.Service, permissionText);
                if (permissionConfig != null && !string.IsNullOrEmpty(quote.Applicant.MarketingPreferences.Response))
                    ProjectCommonFunctions.TriggerSaveAction(_pluginService.Service, applicantId, permissionConfig.Id, quote.Applicant.MarketingPreferences.Response.ToLower());
            }
            #endregion

            return applicantId;
        }

        /// <summary>
        /// Validates Quote
        /// </summary>
        /// <param name="quoteEntity"></param>
        public void ValidateQuoteStatus(Entity quoteEntity)
        {
            if (quoteEntity.Attributes.Contains(Constants.StateCode) &&
                quoteEntity.GetAttributeValue<OptionSetValue>(Constants.StateCode).Value == 2)
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.WonQuoteMessage, Constants.HandledException));
            }

            else if (quoteEntity.Attributes.Contains(Constants.StateCode) &&
               (quoteEntity.GetAttributeValue<OptionSetValue>(Constants.StateCode).Value == 3))
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.ClosedQuoteMessage, Constants.HandledException));
            }
        }

        /// <summary>
        /// Won Quote
        /// </summary>
        /// <param name="quoteEntity"></param>
        public void WonQuote(Entity quoteEntity)
        {
            Entity quoteClose = new Entity(Constants.QuoteCloseLogicalName);
            quoteClose.Attributes.Add(Constants.QuoteIdAttribute, new EntityReference(quoteEntity.LogicalName, quoteEntity.Id));
            quoteClose.Attributes.Add(Constants.WonQuoteSubjectField, Constants.WonQuoteSubjectFieldValue);

            WinQuoteRequest winQuoteRequest = new WinQuoteRequest()
            {
                QuoteClose = quoteClose,
                Status = new OptionSetValue(Constants.WinQuoteRequestValue)
            };
            WinQuoteResponse Winresp = (WinQuoteResponse)_pluginService.Service.Execute(winQuoteRequest);
        }

        /// <summary>
        /// Validates Intermediary
        /// </summary>
        /// <param name="intermediaryAccount"></param>
        /// <param name="quoteEntity"></param>
        public void ValidateIntermediary(Quote quote, Entity intermediaryAccount, Entity quoteEntity)
        {
            if (quoteEntity.Attributes.Contains(Constants.QuoteCustomerId))
            {
                EntityReference customer = quoteEntity.GetAttributeValue<EntityReference>(Constants.QuoteCustomerId);

                bool validCommissionId = !intermediaryAccount.Attributes.Contains(Constants.LEIntemediaryCommissionId) ? false : true;

                if (!customer.Id.Equals(intermediaryAccount.Id) || !validCommissionId)
                {
                    throw new InvalidPluginExecutionException(Constants.AC001_InvalidIntemediaryMessage);
                }
            }
        }

        /// <summary>
        /// Validation for Debit card only
        /// </summary>
        /// <param name="service"></param>
        /// <param name="paymentId"></param>
        internal void ValidatePaymentDetails(IOrganizationService service, Guid paymentId)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            var paymentEntity = service.Retrieve(Constants.PaymentDetailsLogicalName, paymentId, new ColumnSet(Constants.InvalidAccountNumber, Constants.InvalidSortCode, Constants.BankName, Constants.BankErrorResponse));

            if (paymentEntity != null)
            {
                Entity paymentEnt = new Entity(Constants.PaymentDetailsLogicalName);
                paymentEnt.Id = paymentEntity.Id;

                //var bankErrorResponse = paymentEntity.GetAttributeValue<string>(Constants.BankErrorResponse);
                var bankName = paymentEntity.GetAttributeValue<string>(Constants.BankName);
                var invalidSortCode = paymentEntity.GetAttributeValue<string>(Constants.InvalidSortCode) != null ? paymentEntity.GetAttributeValue<string>(Constants.InvalidSortCode).ToLower() : string.Empty;
                var invalidAccNumber = paymentEntity.GetAttributeValue<string>(Constants.InvalidAccountNumber) != null ? paymentEntity.GetAttributeValue<string>(Constants.InvalidAccountNumber).ToLower() : string.Empty;

                bool isValid = bankName != null && invalidSortCode.Equals(Constants.FalseText) && invalidAccNumber.Equals(Constants.FalseText) ? true : false;

                //Set Status of payment details
                if (isValid)
                {
                    paymentEnt.Attributes[Constants.PaymentDetailStatusCode] = new OptionSetValue((int)Enums.PaymentDetailStatusReason.VALIDATED);
                }
                else
                {
                    paymentEnt.Attributes[Constants.PaymentDetailStatusCode] = new OptionSetValue((int)Enums.PaymentDetailStatusReason.VALIDATIONFAILED);
                }

                service.Update(paymentEnt);
            }

        }

        /// <summary>
        /// Build AcceptQuote Response
        /// </summary>
        /// <param name="Quote"></param>
        /// <param name="service"></param>
        /// <param name="quoteResponseCollection"></param>
        /// <returns></returns>
        public QuoteResponse BuildAcceptQuoteResponse(Quote Quote, IOrganizationService service, EntityCollection quoteResponseCollection, List<string> uploadedDocs, string source, string distributionChannel)
        {
            QuoteResponse quoteResponse = new QuoteResponse
            {
                quote = Quote,
                SalesChannel = source,
                DistributionChannel = distributionChannel
            };

            //Add Cover condition to quote response          
            AddCoverConditionsToResponse(quoteResponseCollection, quoteResponse,  uploadedDocs);

            return quoteResponse;
        }

        /// <summary>
        /// Add Cover Conditions to Quote response
        /// </summary>
        /// <param name="conditions">Cover Conditions</param>
        /// <param name="quoteResponse">QuoteResponse object</param>
        private void AddCoverConditionsToResponse(EntityCollection conditions, QuoteResponse quoteResponse, List<string> uploadedDocs)
        {
            quoteResponse.quote.CoverCondition = new List<CoverCondition>();

            foreach (Entity cond in conditions.Entities)
            {
                //Ignore Quote Response with Discount Type and Reponse code with QR056
                if ((cond.FormattedValues.Contains(Constants.ResponseTypeField) && cond.FormattedValues[Constants.ResponseTypeField].ToString() == Constants.Discount)
                    || cond.Attributes[Constants.ResponseCodeField].ToString() == Constants.DeclinedResponseCode)
                {
                    continue;
                }
                CoverCondition coverCondition = new CoverCondition()
                {
                    bupa_responsecode = cond.Attributes.Contains(Constants.ResponseCodeField) ? cond.Attributes[Constants.ResponseCodeField].ToString() : string.Empty,
                    bupa_responsetype = cond.FormattedValues.Contains(Constants.ResponseTypeField) ? cond.FormattedValues[Constants.ResponseTypeField].ToString() : string.Empty,
                    bupa_responsemessage = cond.Attributes.Contains(Constants.ResponseMessageField) ? cond.Attributes[Constants.ResponseMessageField].ToString() : string.Empty,
                    bupa_title = cond.Attributes.Contains(Constants.QuoteResponseTitle) ? cond.Attributes[Constants.QuoteResponseTitle].ToString() : string.Empty,
                    bupa_shortmessage = cond.Attributes.Contains(Constants.QuoteResponseShortMessage) ? cond.Attributes[Constants.QuoteResponseShortMessage].ToString() : string.Empty
                };

                //If related to quote life
                if (cond.Attributes.Contains(Constants.QuoteLifeField) && cond.Attributes[Constants.QuoteLifeField] != null)
                {
                    //get related life
                    EntityReference lifeRef = (EntityReference)cond.Attributes[Constants.QuoteLifeField];
                    QuoteLife life = quoteResponse.quote.QuoteLife.Where(q => q.GUID == lifeRef.Id).FirstOrDefault();

                    if (life != null)
                    {
                        //Add condition to life
                        if (life.CoverCondition == null)
                            life.CoverCondition = new List<CoverCondition>();

                        if(uploadedDocs.Contains(coverCondition.bupa_responsecode + Constants.Concat + life.bupa_bupalifeid))
                        {
                            coverCondition.bupa_responsemessage = Constants.UploadedDocMessage;
                        }

                        life.CoverCondition.Add(coverCondition);
                    }
                }
                //If related to quote
                else if (cond.Attributes.Contains(Constants.OrderField) && cond.Attributes[Constants.OrderField] != null)
                {
                    if (uploadedDocs.Contains(coverCondition.bupa_responsecode))
                    {
                        coverCondition.bupa_responsemessage = Constants.UploadedDocMessage;
                    }
                    quoteResponse.quote.CoverCondition.Add(coverCondition);
                }
            }

            if (conditions.Entities.Where(e => e.FormattedValues.Contains(Constants.ResponseType) && e.FormattedValues[Constants.ResponseType] == Constants.DeclinationReason).Count() > 0)
            {
                quoteResponse.quote.CoverCondition.Add(new CoverCondition()
                {
                    bupa_responsecode = Constants.DeclinedResponseCode,
                    bupa_responsemessage = Constants.DeclinedQuoteMessage,
                    bupa_responsetype = Constants.DeclinationReason,
                    bupa_shortmessage = Constants.QuoteResponseShortMessage,
                    bupa_title = Constants.QuoteResponseTitle
                });
            }
        }

        /// <summary>
        /// GenerateAcceptQuoteResponse
        /// </summary>
        /// <param name="Quote">QuoteRequest</param>
        internal string GenerateAcceptQuoteResponse(Quote quote, Entity order, List<string> uploadedDocs, string source, string distributionChannel)
        {
            //Get quote response
            EntityCollection quoteResponseCollection = ProjectCommonFunctions.GetQuoteResponse(order, _pluginService.Service);
            UpdateResubmittedQuotestatus(quote, quoteResponseCollection, order);
            QuoteResponse quoteResponse = BuildAcceptQuoteResponse(quote, _pluginService.Service, quoteResponseCollection, uploadedDocs, source, distributionChannel);
            List<string> removeAcceptResponseProps = Constants.RemoveAcceptResponseProperty.ToList();

            //Remove Title and ShortMessage from response when souce is not CIP
            if (!source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
                removeAcceptResponseProps.AddRange(new string[] { Constants.JSONTitleProperty, Constants.JSONShortMessageProperty, Constants.JSONSalesChannelProperty, Constants.JSONDistributionChannelProperty });
            string json = JsonConvert.SerializeObject(quoteResponse, Formatting.None,
            new JsonSerializerSettings { ContractResolver = new DynamicContractResolver(removeAcceptResponseProps.ToArray<string>()) });

            return json;
        }

        /// <summary>
        /// Validate minimum data standards and handle null checks
        /// </summary>
        internal Quote ValidateMinimumDataStandard(string quoteString)
        {
            dynamic request = JsonConvert.DeserializeObject<dynamic>(quoteString);
            
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesObject, Constants.QuoteObject, request);

            //Quotes/Quote-DateTimeGenerated is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.DateTimeGeneratedObject, request);

            //Quotes/Quote-AgentCustomerReference is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.AgentCustomerReferenceObject, request);

            //Quotes/Quote-BupaQuotationRef is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.BupaQuotationRefObject, request);

            //Quotes/Quote-CommissionID is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.CommissionIDObject, request);

            //Quotes/Quote-IntermediarySharedData is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.IntermediarySharedDataObject, request);

            //Quotes/Quote-Agent is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.AgentObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.AgentPathObject, Constants.AgentReferenceObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.AgentPathObject, Constants.AgentForenameObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.AgentPathObject, Constants.AgentSurnameObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.AgentPathObject, Constants.AgentTelephoneNoObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.AgentPathObject, Constants.AgentEmailAddressObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.AgentPathObject, Constants.AgentCompanyNameandDepartmentObject, request);

            //Quotes/Quote-Applicant is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.ApplicantObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.ApplicantPathObject, Constants.AddressObject, request);
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.ApplicantAddressPathObject, Constants.PostcodeObject, request);

            //Quotes/Quote-QuoteLife is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.QuoteLifeObject, request);

            //Check if QuoteLife Address is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuoteLifePathObject, Constants.AddressObject, request[Constants.QuoteObject][Constants.QuoteLifeObject]);

            //Check if QuoteLife Postcode is null or empty
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuoteLifeAddressPathObject, Constants.PostcodeObject, request[Constants.QuoteObject][Constants.QuoteLifeObject]);

            //Quotes/Quote-CoverFunder is null
            ProjectCommonFunctions.FieldLevelNullCheck(Constants.QuotesPathObject, Constants.CoverFunderObject, request);

            //PayerRelationshipOther is empty if BillPayerId is Other/Applicant
            string billPayerValue = !ProjectCommonFunctions.IsNullOrEmpty(request[Constants.QuoteObject][Constants.CoverFunderObject][Constants.BillPayerIdObject]) ? Convert.ToString(request[Constants.QuoteObject][Constants.CoverFunderObject][Constants.BillPayerIdObject]) : string.Empty;

            var billPayer = ProjectCommonFunctions.GetOptionSetValueInString(billPayerValue, typeof(Enums.BillPayer), Constants.BillPayerIdObject);

            if ((billPayer.Equals(nameof(Enums.BillPayer.OTHER)) || billPayer.Equals(nameof(Enums.BillPayer.APPLICANT)))
                && string.IsNullOrEmpty(Convert.ToString(request[Constants.QuoteObject][Constants.CoverFunderObject][Constants.PayerRelationshipOtherObject])))
            {
                ProjectCommonFunctions.FieldLevelNullCheck(Constants.CoverFunderPathObject, Constants.PayerRelationshipOtherObject, request);
            }            

            Quote quote = ProjectCommonFunctions.DeserializeJson(quoteString);
            QuoteRequest TargetObject = new QuoteRequest() { Quote = quote };

            return quote;
        }

        /// <summary>
        /// Validate quote data before creating order
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="intermediaryRef"></param>
        /// <returns></returns>
        internal Entity ValidateQuote(Quote quote, string intermediaryRef, string source, string distributionChannel)
        {
            //Validate DistributionChannel as 'Broker' if source is 'CIP'
            ValidateDistributionChannel(source, distributionChannel);

            //Retrieve Quote
            Entity quoteEntity = ProjectCommonFunctions.RetrieveQuote(_pluginService.Service, quote.EntityName, quote.name, nameof(quote.name), Constants.QuoteColumnSet, source);

            if (quoteEntity == null)
            {
                throw new InvalidPluginExecutionException(Constants.AC003_QuoteNotFoundMessage);
            }

            quote.GUID = quoteEntity.Id;

            //Retrieve Intermediary
            Entity intermediaryAccount = ProjectCommonFunctions.GetIntermediary(_pluginService.Service, intermediaryRef, quote, quoteEntity);

            if (intermediaryAccount == null)
            {
                throw new InvalidPluginExecutionException(string.Format(Constants.IntemediaryNotFoundMessage, Constants.HandledException, intermediaryRef, quote.bupa_commissionid_text));
            }

            //Validate if intermediary reference and customer on quote is same
            ValidateIntermediary(quote, intermediaryAccount, quoteEntity);

            //Check if quote is already won or closed
            ValidateQuoteStatus(quoteEntity);

            //Check if Quote is older than 14 days
            ValidateIfQuoteIsOlderThan14Days(quoteEntity);

            //Verify if applicant post code is same as quote applicant
            ValidateIfApplicantPostcodeSameAsQuote(quote, quoteEntity);

            //Get Resubmit Reference
            GetResubmittedOrder(quoteEntity, quote);

            //Validate Postcodes of Lives
            ValidateLifeDetails(quote, quoteEntity, source);

            //Validate XGS business payment for bank account
            ValidateCoverFunderAccount(quote, quoteEntity);

            //Check if Bank details are complete
            IsBankDetailsComplete(quote);

            //Check if Billing Addresss is complete
            IsBillingAddressComplete(quote);

            return quoteEntity;
        }

        /// <summary>
        /// Create order ready for Enrolment
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteEntity"></param>
        /// <param name="source"></param>
        internal Entity ProcessQuote(Quote quote, Entity quoteEntity, string source, ref List<string> uploadedDocs)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            //accept quote
            WonQuote(quoteEntity);

            //create aplicant                
            Guid applicantId = CreateApplicant(quote, quoteEntity, source);

            //Update Agent information
            UpdateAgent(quote, quoteEntity, source);

            //Update Life Details
            UpdateLifeDetails(quote, lifeCollection, source);

            //create order
            Entity salesOrder = ConvertQuoteToOrder(quoteEntity);

            //Update created order
            UpdateOrder(quote, applicantId, salesOrder, source, quoteEntity);

            //Direct Debit
            if (ProjectCommonFunctions.GetOptionSetValueInString(quote.CoverFunder.PaymentType, typeof(Enums.Payment_Type), nameof(Enums.Payment_Type)).Equals(nameof(Enums.Payment_Type.DDM)))
            {
                #region Resubmit reference

                if (quote.CoverFunder.BankDetails == null) quote.CoverFunder.BankDetails = new BankDetails();

                if (quote.bupa_resubmitreferenceid != Guid.Empty && !string.IsNullOrEmpty(quote.UseExistingPaymentDetails) && quote.UseExistingPaymentDetails.ToLower().Equals(Constants.YesText))
                {
                    quote.CoverFunder.PaymentType = Enum.GetName(typeof(Enums.Payment_Type), ProjectCommonFunctions.GetOptionSetFromAliasedValue(quoteEntity, Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.PaymentType).Value);
                    quote.CoverFunder.BankDetails.AccountNumber = quoteEntity.Contains(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.AccountNumber) ? quoteEntity.GetAttributeValue<AliasedValue>(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.AccountNumber).Value.ToString() : string.Empty;
                    quote.CoverFunder.BankDetails.SortCode = quoteEntity.Contains(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.SortCode) ? quoteEntity.GetAttributeValue<AliasedValue>(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.SortCode).Value.ToString() : string.Empty;
                    quote.CoverFunder.BankDetails.BankName = quoteEntity.Contains(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.BankName) ? quoteEntity.GetAttributeValue<AliasedValue>(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.BankName).Value.ToString() : string.Empty;
                    quote.CoverFunder.AccountType = Enum.GetName(typeof(Enums.Account_Type), ProjectCommonFunctions.GetOptionSetFromAliasedValue(quoteEntity, Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.AccountType).Value);
                    quote.CoverFunder.AccountHolderName = quoteEntity.Contains(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.AccountName) ? quoteEntity.GetAttributeValue<AliasedValue>(Constants.PaymentDetailsLogicalName + Constants.Concat + Constants.AccountName).Value.ToString() : string.Empty;
                }

                #endregion End Resubmit reference

                //Create payment details
                Guid paymentId = CreatePaymentDetail(quote, salesOrder, quoteEntity);

                //Validate payment details
                ValidatePaymentDetails(_pluginService.Service, paymentId);
            }

            ExecuteInrule(salesOrder.ToEntityReference());

            //Copy Documents
            uploadedDocs = CopyDocumentFromOriginalOrder(quote, quoteEntity, salesOrder);

            ExecutePopulateOrderStatusAction(salesOrder.ToEntityReference());

            ExecuteSetOrderOwnershipAction(salesOrder.ToEntityReference());

            return salesOrder;
        }

        /// <summary>
        /// Copy Document From Original Order
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteEntity"></param>
        /// <param name="salesOrder"></param>
        private List<string> CopyDocumentFromOriginalOrder(Quote quote, Entity quoteEntity, Entity salesOrder)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            List<string> uploadedDocs = new List<string>();
            _pluginService.TracingService.Trace(quote.bupa_resubmitreferenceid.ToString());

            if (quote.bupa_resubmitreferenceid != Guid.Empty)
            {
                //get new order evidence upload task
                EntityCollection newTasks = ProjectCommonFunctions.RetrieveTasksForOrder(_pluginService.Service, salesOrder.Id);
               
                Guid oldOrderId = quoteEntity.Contains(Constants.SalesOrderLogicalName + Constants.Concat + Constants.OrderIdAttribute) ?
                    (Guid)quoteEntity.GetAttributeValue<AliasedValue>(Constants.SalesOrderLogicalName + Constants.Concat + Constants.OrderIdAttribute).Value
                    : Guid.Empty;
                
                //get new order evidence upload task
                EntityCollection oldTasks = ProjectCommonFunctions.RetrieveTasksForOrder(_pluginService.Service, oldOrderId);

                foreach (var newTask in newTasks.Entities)
                {
                    //get new task ER code and life id
                    string erCode = newTask.GetAttributeValue<string>(Constants.SubjectNoteField);
                    string lifeId = newTask.GetAttributeValue<string>(Constants.BupaLifeIdTaskField);

                    //get old task with same ER code and bupa life id
                   Entity oldTask;
                    if(lifeId !=null)
                     oldTask = oldTasks.Entities.Where(t => t.GetAttributeValue<string>(Constants.SubjectNoteField) == erCode &&
                                                t.GetAttributeValue<string>(Constants.BupaLifeIdTaskField) == lifeId).FirstOrDefault();
                    else
                        oldTask = oldTasks.Entities.Where(t => t.GetAttributeValue<string>(Constants.SubjectNoteField) == erCode).FirstOrDefault();

                    if (oldTask != null && oldTask.Attributes.Contains(Constants.NotesEntityLogicalName + Constants.Concat + Constants.TitleNoteField) )
                    {
                        
                        AttachDocument(newTask.ToEntityReference(), oldTask);
                        string str = lifeId != null ? erCode + Constants.Concat + lifeId : erCode;
                        uploadedDocs.Add(str);
                    }
                }

            }

            return uploadedDocs;
        }

        /// <summary>
        /// Create note with attachment on Task
        /// </summary>
        /// <param name="evidenceRequest"></param>
        /// <param name="regardingEntity"></param>
        internal void AttachDocument( EntityReference regardingEntity,Entity oldTask)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));           
               
            Entity annotation = new Entity(Constants.NotesEntityLogicalName);
                
            annotation.Attributes[Constants.TitleNoteField] = ((AliasedValue)oldTask.Attributes[Constants.NotesEntityLogicalName + Constants.Concat + Constants.TitleNoteField]).Value.ToString();
            annotation.Attributes[Constants.DocumentBodyNoteField] = ((AliasedValue)oldTask.Attributes[Constants.NotesEntityLogicalName + Constants.Concat + Constants.DocumentBodyNoteField]).Value.ToString();
            annotation.Attributes[Constants.MimeTypeNoteField] = ((AliasedValue)oldTask.Attributes[Constants.NotesEntityLogicalName + Constants.Concat + Constants.MimeTypeNoteField]).Value.ToString();
            annotation.Attributes[Constants.FileNameNoteField] = ((AliasedValue)oldTask.Attributes[Constants.NotesEntityLogicalName + Constants.Concat + Constants.FileNameNoteField]).Value.ToString();
            annotation.Attributes[Constants.NoteTextNoteField] = ((AliasedValue)oldTask.Attributes[Constants.NotesEntityLogicalName + Constants.Concat + Constants.NoteTextNoteField]).Value.ToString();
            annotation.Attributes[Constants.IsDocumentNoteField] = true;

            Guid noteId = _pluginService.Service.Create(annotation);
            
        }

        /// <summary>
        /// Quote expires if createdon date is older than 14 days
        /// </summary>
        /// <param name="quoteEntity"></param>
        internal void ValidateIfQuoteIsOlderThan14Days(Entity quoteEntity)
        {
            var quoteCreatedDate = quoteEntity.GetAttributeValue<DateTime>(Constants.QuoteCreatedOn).Date.ToUniversalTime();
            var currentDate = DateTime.UtcNow.Date;
            if (quoteCreatedDate <= currentDate.AddDays(-14))
            {
                throw new InvalidPluginExecutionException(Constants.AC002_QuoteExpireMessage);
            }
        }

        /// <summary>
        /// Get order reference if resubmitted
        /// </summary>
        /// <param name="quoteEntity"></param>
        internal void GetResubmittedOrder(Entity quoteEntity, Quote quote)
        {
            if (quoteEntity.Contains(string.Concat( Constants.SalesOrderLogicalName , Constants.Concat ,Constants.OrderIdAttribute)))
            {
                quote.bupa_resubmitreferenceid = Guid.Parse(quoteEntity.GetAttributeValue<AliasedValue>(string.Concat(Constants.SalesOrderLogicalName , Constants.Concat , Constants.OrderIdAttribute)).Value.ToString());
                quote.bupa_resubmitreference = quoteEntity.GetAttributeValue<AliasedValue>(string.Concat(Constants.SalesOrderLogicalName , Constants.Concat , Constants.Name)).Value.ToString();
            }
        }

        /// <summary>
        /// Validate Life BupaLifeId and Postcode
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteEntity"></param>
        internal void ValidateLifeDetails(Quote quote, Entity quoteEntity, string source)
        {
            lifeCollection = lifeCollection == null ? ProjectCommonFunctions.GetQuoteLives(_pluginService, quoteEntity) : lifeCollection;

            foreach (var life in quote.QuoteLife)
            {
                if (source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
                {
                    if (string.IsNullOrEmpty(life.bupa_agent_life_id))
                    {
                        throw new InvalidPluginExecutionException(string.Format(Constants.AgentLifeIdNullMessage, Constants.HandledException));
                    }

                    var lifeMatchedWithLifeId = lifeCollection.Entities.Where(x => !string.IsNullOrEmpty(x.GetAttributeValue<string>(Constants.LifeAgentLifeId)) && x.GetAttributeValue<string>(Constants.LifeAgentLifeId).Equals(life.bupa_agent_life_id)).FirstOrDefault();

                    if (lifeMatchedWithLifeId != null)
                    {
                        life.GUID = lifeMatchedWithLifeId.Id;
                        var postcode = lifeMatchedWithLifeId.GetAttributeValue<string>(Constants.LifePostCode);

                        if (!ProjectCommonFunctions.FormatPostcode(postcode).Equals(ProjectCommonFunctions.FormatPostcode(life.Address.address1_postalcode)))
                        {
                            throw new InvalidPluginExecutionException(Constants.AC004_PostCodeMatchMessage);
                        }
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException(string.Format(Constants.AgentLifeIdNotFoundMessage,Constants.HandledException, life.bupa_agent_life_id));
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(life.bupa_bupalifeid))
                    {
                        throw new InvalidPluginExecutionException(Constants.AC009_BupaLifeIdNullMessage);
                    }

                    var lifeMatchedWithLifeId = lifeCollection.Entities.Where(x => !string.IsNullOrEmpty(x.GetAttributeValue<string>(Constants.LifeBupaLifeId)) && x.GetAttributeValue<string>(Constants.LifeBupaLifeId).Equals(life.bupa_bupalifeid)).FirstOrDefault();

                    if (lifeMatchedWithLifeId != null)
                    {
                        life.GUID = lifeMatchedWithLifeId.Id;
                        var postcode = lifeMatchedWithLifeId.GetAttributeValue<string>(Constants.LifePostCode);

                        if (!ProjectCommonFunctions.FormatPostcode(postcode).Equals(ProjectCommonFunctions.FormatPostcode(life.Address.address1_postalcode)))
                        {
                            throw new InvalidPluginExecutionException(Constants.AC004_PostCodeMatchMessage);
                        }
                    }
                    else
                    {
                        throw new InvalidPluginExecutionException(string.Format(Constants.AC008_BupaLifeIdNotFoundMessage, life.bupa_bupalifeid));
                    }
                }
            }
        }

        /// <summary>
        /// If Account type = Company and BBY-XGS product throw Declinition Reason- AC010
        /// </summary>
        /// <param name="quoteEntity"></param>
        /// <param name="quote"></param>
        internal void ValidateCoverFunderAccount(Quote quote, Entity quoteEntity)
        {
            var continuationType = quoteEntity.GetAttributeValue<OptionSetValue>(Constants.QuoteContinuationType).Value;
            var productName = quoteEntity.GetAttributeValue<EntityReference>(Constants.QuoteCoreProduct) != null ? quoteEntity.GetAttributeValue<EntityReference>(Constants.QuoteCoreProduct).Name : string.Empty;
            var accountType = ProjectCommonFunctions.GetOptionSetValueInString(quote.CoverFunder.AccountType, typeof(Enums.Account_Type), nameof(Enums.Account_Type));

            if (productName.Equals(Constants.BbyQuoteType) && continuationType.Equals(Constants.ContinuationTypeXgs) && accountType.Equals(nameof(Enums.Account_Type.COMPANY)))
            {
                throw new InvalidPluginExecutionException(Constants.AC010_XgsBusinessPayment);
            }
        }

        /// <summary>
        /// Verify if bank details are complete
        /// </summary>
        /// <param name="quote"></param>
        internal void IsBankDetailsComplete(Quote quote)
        {
            //Validation for Resubmit Accept Quote
            if (quote.bupa_resubmitreferenceid != Guid.Empty && !string.IsNullOrEmpty(quote.UseExistingPaymentDetails) && quote.UseExistingPaymentDetails.ToLower().Equals(Constants.YesText))
                return;

            if (ProjectCommonFunctions.GetOptionSetValueInString(quote.CoverFunder.PaymentType, typeof(Enums.Payment_Type), nameof(Enums.Payment_Type)).Equals(nameof(Enums.Payment_Type.DDM)))
            {
                bool isBankDetailsComplete = quote.CoverFunder.BankDetails == null ||
                                                string.IsNullOrEmpty(quote.CoverFunder.BankDetails.AccountNumber) ||
                                                string.IsNullOrEmpty(quote.CoverFunder.BankDetails.SortCode) ||
                                                string.IsNullOrEmpty(quote.CoverFunder.BankDetails.TitleCode) ||
                                                string.IsNullOrEmpty(quote.CoverFunder.BankDetails.Forename) ||
                                                string.IsNullOrEmpty(quote.CoverFunder.BankDetails.Surname) ? false : true;

                if (!isBankDetailsComplete)
                {
                    throw new InvalidPluginExecutionException(Constants.AC005_BankDetailInvalidMessage);
                }
            }
        }

        /// <summary>
        /// Verify if Billing Address is complete
        /// </summary>
        /// <param name="quote"></param>
        internal void IsBillingAddressComplete(Quote quote)
        {
            if (quote.CoverFunder != null && ProjectCommonFunctions.GetOptionSetValueInString(quote.CoverFunder.PaymentType, typeof(Enums.Payment_Type), nameof(Enums.Payment_Type)).Equals(nameof(Enums.Payment_Type.DDM)))
            {
                bool isBillingAddressComplete = quote.CoverFunder.BankingAddress == null ||
                                        string.IsNullOrEmpty(quote.CoverFunder.BankingAddress.address1_line1) ||
                                        string.IsNullOrEmpty(quote.CoverFunder.BankingAddress.address1_city) ||
                                        string.IsNullOrEmpty(quote.CoverFunder.BankingAddress.address1_postalcode) ? false : true;

                if (!isBillingAddressComplete)
                {
                    throw new InvalidPluginExecutionException(Constants.AC006_BillingAddressInvalidMessage);
                }
            }
        }

        /// <summary>
        /// Verify if Quote Applicant postcode is same as Accept - Applicant postcode
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteEntity"></param>
        internal void ValidateIfApplicantPostcodeSameAsQuote(Quote quote, Entity quoteEntity)
        {            
            if (!ProjectCommonFunctions.FormatPostcode(quote.Applicant.Address.address1_postalcode).Equals(ProjectCommonFunctions.FormatPostcode(quoteEntity.GetAttributeValue<string>(Constants.ApplicantPostCode))))
            {
                throw new InvalidPluginExecutionException(Constants.AC004_PostCodeMatchMessage);
            }
            
        }

        /// <summary>
        /// Update Agent details if changed
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteEntity"></param>
        internal void UpdateAgent(Quote quote, Entity quoteEntity, string source)
        {
            // Do not update Agent if source is CIP
            if (source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
                return;

            bool isDataUpdated = false;
            AttributeCollection attributes = new AttributeCollection();

            if (quoteEntity.Contains(Constants.LEContactAgentReference) && !quote.Agent.bupa_agentreference.Equals(((AliasedValue)quoteEntity.Attributes[Constants.LEContactAgentReference]).Value.ToString()))
            {
                isDataUpdated = true;
                attributes.Add(Constants.ContactAgentReference, quote.Agent.bupa_agentreference);
            }
            if (quoteEntity.Contains(Constants.LEContactFirstName) && !quote.Agent.firstname.Equals(((AliasedValue)quoteEntity.Attributes[Constants.LEContactFirstName]).Value.ToString()))
            {
                isDataUpdated = true;
                attributes.Add(Constants.ContactFirstName, quote.Agent.firstname);
            }
            if (quoteEntity.Contains(Constants.LEContactLastName) && !quote.Agent.lastname.Equals(((AliasedValue)quoteEntity.Attributes[Constants.LEContactLastName]).Value.ToString()))
            {
                isDataUpdated = true;
                attributes.Add(Constants.ContactLastName, quote.Agent.lastname);
            }
            if (quoteEntity.Contains(Constants.LEContactTelephone) && !quote.Agent.telephone1.Equals(((AliasedValue)quoteEntity.Attributes[Constants.LEContactTelephone]).Value.ToString()))
            {
                isDataUpdated = true;
                attributes.Add(Constants.ContactTelephone, quote.Agent.telephone1);
            }
            if (quoteEntity.Contains(Constants.LEContactEmailAddress) && !quote.Agent.emailaddress1.Equals(((AliasedValue)quoteEntity.Attributes[Constants.LEContactEmailAddress]).Value.ToString()))
            {
                isDataUpdated = true;
                attributes.Add(Constants.ContactEmailAddress, quote.Agent.emailaddress1);
            }
            if (quoteEntity.Contains(Constants.LEContactDepartment) && !quote.Agent.department.Equals(((AliasedValue)quoteEntity.Attributes[Constants.LEContactDepartment]).Value.ToString()))
            {
                isDataUpdated = true;
                attributes.Add(Constants.ContactDepartment, quote.Agent.department);
            }


            if (isDataUpdated)
            {
                Entity agentEntity = new Entity(Constants.ContactLogicalName);
                agentEntity.Id = new Guid(((AliasedValue)quoteEntity.Attributes[Constants.LEContactId]).Value.ToString());
                agentEntity.Attributes = attributes;

                _pluginService.Service.Update(agentEntity);
            }
        }

        /// <summary>
        /// Update life details - Firstname, Lastname, Title and MiddleInitials if changed
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="lifeCollection"></param>
        internal void UpdateLifeDetails(Quote quote, EntityCollection lifeCollection, string source)
        {
            foreach (var life in quote.QuoteLife)
            {
                bool lifeUpdated = false;
                string firstName = string.Empty;
                string lastName = string.Empty;

                var lifeEntity = source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()) 
                    ? lifeCollection.Entities.Where(x => x.GetAttributeValue<string>(Constants.LifeAgentLifeId).Equals(life.bupa_agent_life_id)).FirstOrDefault() 
                    : lifeCollection.Entities.Where(x => x.GetAttributeValue<string>(Constants.LifeBupaLifeId).Equals(life.bupa_bupalifeid)).FirstOrDefault();
                
                AttributeCollection attributes = new AttributeCollection();

                if (source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
                {
                    if (!string.IsNullOrEmpty(life.bupa_titleoptions) && (!lifeEntity.FormattedValues.Contains(Constants.LifeTitleCode) || (lifeEntity.FormattedValues.Contains(Constants.LifeTitleCode) && !life.bupa_titleoptions.Equals(lifeEntity.FormattedValues[Constants.LifeTitleCode]))))
                    {
                        lifeUpdated = true;
                        attributes.Add(Constants.LifeTitleCode, ProjectCommonFunctions.GetOptionSetValue(life.bupa_titleoptions, typeof(Enums.TitleCode), nameof(life.bupa_titleoptions)));
                        attributes.Add(Constants.LifeTitle, life.bupa_titleoptions);
                    }

                    if (!string.IsNullOrEmpty(life.bupa_life_gender) && (!lifeEntity.FormattedValues.Contains(Constants.LifeBirthSex) || (lifeEntity.FormattedValues.Contains(Constants.LifeBirthSex) && !life.bupa_life_gender.Equals(lifeEntity.FormattedValues[Constants.LifeBirthSex]))))
                    {
                        lifeUpdated = true;
                        attributes.Add(Constants.LifeBirthSex, ProjectCommonFunctions.GetOptionSetValue(life.bupa_life_gender, typeof(Enums.BirthSex), nameof(life.bupa_life_gender)));
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(life.bupa_titleoptions) && !life.bupa_titleoptions.Equals(lifeEntity.FormattedValues[Constants.LifeTitleCode]))
                    {
                        lifeUpdated = true;
                        attributes.Add(Constants.LifeTitleCode, ProjectCommonFunctions.GetOptionSetValue(life.bupa_titleoptions, typeof(Enums.TitleCode), nameof(life.bupa_titleoptions)));
                        attributes.Add(Constants.LifeTitle, life.bupa_titleoptions);
                    }
                }
                if (!string.IsNullOrEmpty(life.bupa_firstname) && !life.bupa_firstname.Equals(lifeEntity.GetAttributeValue<string>(Constants.LifeFirstName)))
                {
                    lifeUpdated = true;
                    firstName = life.bupa_firstname;
                    attributes.Add(Constants.LifeFirstName, life.bupa_firstname);
                }
                if (!string.IsNullOrEmpty(life.bupa_middleinitial) && !life.bupa_middleinitial.Equals(lifeEntity.GetAttributeValue<string>(Constants.LifeMiddleInitial)))
                {
                    lifeUpdated = true;
                    attributes.Add(Constants.LifeMiddleInitial, life.bupa_middleinitial);
                }
                if (!string.IsNullOrEmpty(life.bupa_lastname) && !life.bupa_lastname.Equals(lifeEntity.GetAttributeValue<string>(Constants.LifeLastName)))
                {
                    lifeUpdated = true;
                    lastName = life.bupa_lastname;
                    attributes.Add(Constants.LifeLastName, life.bupa_lastname);
                }

                if (lifeUpdated)
                {
                    Entity updateLifeEntity = new Entity(Constants.LifeEntityName);
                    updateLifeEntity.Id = lifeEntity.Id;                    

                    var fullName = !string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName) ? string.Format(Constants.FullNameString, firstName, lastName) 
                                   : !string.IsNullOrEmpty(firstName) && string.IsNullOrEmpty(lastName) ? string.Format(Constants.FullNameString, firstName, life.bupa_lastname)
                                   : string.IsNullOrEmpty(firstName) && !string.IsNullOrEmpty(lastName) ? string.Format(Constants.FullNameString, life.bupa_firstname, lastName)
                                   : string.Empty;

                    if (fullName != string.Empty)
                        attributes.Add(Constants.CustomEntity_PrimaryFieldName, fullName);
                    
                    updateLifeEntity.Attributes = attributes;

                    _pluginService.Service.Update(updateLifeEntity);
                }
            }
        }

        internal void ValidateDistributionChannel(string source, string distributionChannel)
        {
            if (source.ToUpper().Equals(Constants.CIPSourceSystem.ToUpper()))
            {
                if (string.IsNullOrEmpty(distributionChannel))
                {
                    throw new InvalidPluginExecutionException(string.Format(Constants.NullDistributionChannel, Constants.HandledException));
                }
                else if (!distributionChannel.Equals(Constants.BrokerChannel))
                {
                    throw new InvalidPluginExecutionException(string.Format(Constants.InvalidDistributionChannel, Constants.HandledException, distributionChannel));
                }
            }
        }

        /// <summary>
        /// Execute Inrule
        /// </summary>
        /// <param name="order"></param>
        internal void ExecuteInrule(EntityReference order)
        {
            //Calling the Action - bupa_ValidateOrder
            OrganizationRequest req = new OrganizationRequest(Constants.ValidateOrderAction);
            req[Constants.Target] = order;
            OrganizationResponse response = _pluginService.Service.Execute(req);
        }

        /// <summary>
        /// Execute PopulateOrderStatusAction
        /// </summary>
        /// <param name="order">Order Reference</param>
        internal void ExecutePopulateOrderStatusAction(EntityReference order)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            //Calling the Action - Sales: Populate Order Status
            OrganizationRequest req = new OrganizationRequest(Constants.PopulateOrderStatusAction);
            req[Constants.Target] = order;
            OrganizationResponse response = _pluginService.Service.Execute(req);
        }

        /// <summary>
        /// Execute PopulateOrderStatusAction
        /// </summary>
        /// <param name="order">Order Reference</param>
        internal void ExecuteSetOrderOwnershipAction(EntityReference order)
        {
            _pluginService.TracingService.Trace(string.Format(Constants.EnteringMethod, MethodBase.GetCurrentMethod().Name));

            //Calling the Action - Sales: Set Order Ownership
            OrganizationRequest req = new OrganizationRequest(Constants.SetOrderOwnershipAction);
            req[Constants.Target] = order;
            OrganizationResponse response = _pluginService.Service.Execute(req);
        }

        /// <summary>
        /// Check Resubmitted Order and Update Status Accordingly
        /// </summary>
        /// <param name="quote"></param>
        /// <param name="quoteResponseCollection"></param>
        /// <param name="order"></param>
        internal void UpdateResubmittedQuotestatus(Quote quoteEntity, EntityCollection quoteResponseCollection, Entity order)
        {
            bool declined = false;
            if (quoteEntity.bupa_resubmitreferenceid != Guid.Empty)
            {
                foreach (Entity quoteResponse in quoteResponseCollection.Entities)
                {
                    if (quoteResponse.GetAttributeValue<OptionSetValue>(Constants.ResponseType).Value == Constants.Qr_DeclinationReason)//Delined
                    {
                        declined = true;
                    }
                    }
                if (declined)
                {
                    var state = new SetStateRequest();
                    state.State = new OptionSetValue(Constants.CancelledOrderStatusValue);
                    state.Status = new OptionSetValue(Constants.CancelledOrderStatusValueRejected);
                    state.EntityMoniker = order.ToEntityReference();
                    _pluginService.Service.Execute(state);
                }
                else
                {
                    var state = new SetStateRequest();
                    state.State = new OptionSetValue(Constants.CancelledOrderStatusValue);
                    state.Status = new OptionSetValue(Constants.CancelledOrderStatusValueSuperseded);
                    state.EntityMoniker = order.GetAttributeValue<EntityReference>(Constants.OrderResubmitReference);
                    _pluginService.Service.Execute(state);
                }
                }
            }
        
    }


    public class DynamicContractResolver : DefaultContractResolver
    {
        private readonly string[] props;

        public DynamicContractResolver(params string[] prop)
        {
            this.props = prop;
        }

        protected override IList<JsonProperty> CreateProperties(Type type, MemberSerialization memberSerialization)
        {
            IList<JsonProperty> retval = base.CreateProperties(type, memberSerialization);

            // retorna todas as propriedades que não estão na lista para ignorar
            retval = retval.Where(p => !this.props.Contains(p.PropertyName)).ToList();

            return retval;
        }
    }
}
