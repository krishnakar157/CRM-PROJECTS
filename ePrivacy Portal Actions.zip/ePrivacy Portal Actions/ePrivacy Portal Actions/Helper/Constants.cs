﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Helper
{
    /// <summary>
    /// Constants shared across all classes
    /// </summary>
    internal class Constants
    {
        internal const string ServiceProvider = "serviceProvider";
        internal const string QueryExpressionText = "queryexpression";
        internal const string FetchExpressionText = "fetchexpression";

        internal const string GetInteractionPermissionActionName = "bupa_GetInteractionPermissions";
        internal const string SaveInteractionPermissionActionName = "bupa_SaveInteractionPermissions";

        internal const string Bupa_ActionText = "bupa_action";
        internal const string Bupa_ParametersText = "bupa_parameters";

        internal const string ResponseText = "response";

        internal const string ConditionText = "condition";
        internal const string AttributeText = "attribute";
        internal const string OperatorText = "operator";
        internal const string ValueText = "value";

        internal class TraceMessages
        {
            //*** Common Plugin Trace and Error Messages           
            internal const string ServiceProviderNullMessage = "{0} : Service provider not set.";
            internal const string StartTracingMessage = "Starting {0}...";
            internal const string StopTracingMessage = "Completed {0}.";
            internal const string InvalidPluginTarget = "{0} : Plugin does not contain the required target. Target required text is {1}.";
            internal const string PluginEntityWrongMessage = "{0} : Plugin does not support entities of type {1}.";
            internal const string PluginExecutionContextInvalidMessage = "{0} : Plugin execution context is not valid, so not using it.";
            internal const string PluginIncorrectPipelineStageMessage = "{0} : The plugin is running in the incorrect pipeline stage. Expected {1} but running in {2}. Please contact your System Administrator.";
            internal const string PluginIncorrectMessageNameMessage = "{0} : Plugin is running under the incorrect message type. Expected message type of {1}, not {2}. Please contact your System Administrator.";
            internal const string PluginMissingImagesMessage = "{0} : Plugin is missing Image(s). Expected {1}. Please contact your System Administrator.";
            internal const string PluginExecutionContextDepthMessage = "{0} : Plugin depth is greater than expected.";
            internal const string OrganisationServiceFaultExceptionMessage = "{0}: A Service fault occurred in the plug-in. Error: {1}";
            internal const string InvalidPluginExceptionMessage = "{0} : An exception occurred in the plugin. Error: {1}";
            internal const string GeneralExceptionMessage = "{0} : An exception occurred in the plugin. Error: {1} - InnerException: {2}";
            internal const string FieldMissingFromPostImage = "\"{0}\" was not populated in post-Image";
            internal const string PostImageNotRegistered = "PostImage or/and PreImage not registered";
            internal const string InvalidSystemSettings = "Plugin was expecting 1 system settings record but retrieved {0}. Filters used: Group: {1}, SubGroup:{2}, Key: {3}. Please correct system settings";
            internal const string NoConfigGuidFoundInConfig = "Unable to retrieve the default configuration GUID from Interaction permission Configuration entity. Filter used: Channel:{0}, target:{1}, subtarget:{2}";
            internal const string NoConfigGuidFoundInSystemSettings = "Unable to retrieve the default configuration GUID from system settings.";
            internal const string InvalidInteractionPermissionConfigCount = "Unexpected count error. Expected 1 record but found {0} records in CRM.";
            internal const string SettingDefaultValues = "Setting default values. LogErrorEnabled : {0}, LogTraceEnabled : {1}, LogWarningEnabled : {2}, LogErrorEnabled : {3}..";

            internal const string EnteredMethodMessage = "Inside Method: {0}.";
            internal const string MethodExecutionCompleted = "{0} execution completed.";
            internal const string ExitingMethodMessage = "Exited from {0}. {1} caught. Error: {2}.";

            internal const string InvalidPluginExecutionException = "InvalidPluginExecutionException";
            internal const string FaultException = "FaultException";
            internal const string Exception = "Exception";

            internal const string BeforeCallingAction = "{0}: Before calling action.";
            internal const string ActionCalled = "{0}: Action called.";
        }

        internal class ActionParameters
        {
            internal const string BGIDParameter = "BGID";
            internal const string UpdatedByParameter = "UpdatedBy";
            internal const string InteractionPermissionsParameter = "interactionPermissions";
        }

        internal class EPrivacyPortal
        {
            internal const string EntityName = "bupa_eprivacyportalaction";
            internal const string ChannelFieldNameText = "bupa_channel";
            internal const string ConfigurationIdFieldNameText = "bupa_configurationid";
            internal const string HistoryIdFieldNameText = "bupa_historyid";
            internal const string NeedsUpdateFieldNameText = "bupa_needsupdate";
            internal const string OrderFieldNameText = "bupa_order";
            internal const string PermissionTextFieldNameText = "bupa_permissiontext";
            internal const string PreferenceFieldNameText = "bupa_preference";
            internal const string SubtargetFieldNameText = "bupa_subtarget";
            internal const string TargetFieldNameText = "bupa_target";
        }

        internal static class ContextConstant
        {
            /// <summary>
            /// The target
            /// </summary>
            internal const string TargetText = "Target";

            /// <summary>
            /// The post image
            /// </summary>
            internal const string PostImageText = "PostImage";
            /// <summary>
            /// The pre image
            /// </summary>
            internal const string PreImageText = "PreImage";

            /// <summary>
            /// The entity moniker
            /// </summary>
            internal const string EntityMonikerText = "EntityMoniker";

            /// <summary>
            /// The related entities
            /// </summary>
            internal const string RelatedEntitiesText = "RelatedEntities";

            /// <summary>
            /// The relationship
            /// </summary>
            internal const string RelationshipText = "Relationship";

            /// <summary>
            /// The column set passed as an Input Parameter in Retrieve message
            /// </summary>
            internal const string ColumnSetText = "ColumnSet";

            /// <summary>
            /// The query passed as an Input Parameter in RetrieveMultiple message
            /// </summary>
            internal const string QueryText = "Query";

            /// <summary>
            /// The business entity passed as an Output Parameter in Retrieve message
            /// </summary>
            internal const string BusinessEntityText = "BusinessEntity";

            /// <summary>
            /// The business entity collection passed as an Output Parameter in RetrieveMultiple message
            /// </summary>
            internal const string BusinessEntityCollectionText = "BusinessEntityCollection";

            /// <summary>
            /// The incident resolution - passed as an Input Parameter in Close Incident message
            /// </summary>
            internal const string IncidentResolution = "IncidentResolution";

            /// <summary>
            /// The state - passed as an Input Parameter in Close Incident message
            /// </summary>
            internal const string State = "State";

            /// <summary>
            /// The status - passed as an Input Parameter in Close message
            /// </summary>
            internal const string Status = "Status";

            /// <summary>
            /// UpdateContent - entity passed during Merge
            /// </summary>
            internal const string UpdateContentText = "UpdateContent";

            /// <summary>
            /// SubordinateId - GUID passed during Merge
            /// </summary>
            internal const string SuborindateIdText = "SubordinateId";

        }

        internal static class PluginMessage
        {
            /// <summary>
            /// The Assign message.
            /// </summary>
            internal const string Assign = "Assign";

            /// <summary>
            /// The Create message.
            /// </summary>
            internal const string Create = "Create";

            /// <summary>
            /// The Close message.
            /// </summary>
            internal const string Close = "Close";

            /// <summary>
            /// The Delete message.
            /// </summary>
            internal const string Delete = "Delete";

            /// <summary>
            /// The GrantAccess message.
            /// </summary>
            internal const string GrantAccess = "GrantAccess";

            /// <summary>
            /// The ModifyAccess message.
            /// </summary>
            internal const string ModifyAccess = "ModifyAccess";

            /// <summary>
            /// The Retrieve message.
            /// </summary>
            internal const string Retrieve = "Retrieve";

            /// <summary>
            /// The RetrieveMultiple message.
            /// </summary>
            internal const string RetrieveMultiple = "RetrieveMultiple";

            /// <summary>
            /// The RetrievePrincipalAccess message.
            /// </summary>
            internal const string RetrievePrincipalAccess = "RetrievePrincipalAccess";

            /// <summary>
            /// The RetrieveSharedPrincipalsAndAccess message.
            /// </summary>
            internal const string RetrieveSharedPrincipalsAndAccess = "RetrieveSharedPrincipalsAndAccess";

            /// <summary>
            /// The RevokeAccess message.
            /// </summary>
            internal const string RevokeAccess = "RevokeAccess";

            /// <summary>
            /// The SetState message.
            /// </summary>
            internal const string SetState = "SetState";

            /// <summary>
            /// The SetStateDynamicEntity message.
            /// </summary>
            internal const string SetStateDynamicEntity = "SetStateDynamicEntity";

            /// <summary>
            /// The Update message.
            /// </summary>
            internal const string Update = "Update";

            /// <summary>
            /// The Merge message.
            /// </summary>
            internal const string Merge = "Merge";
        }

        /// <summary>
        /// Indicates whether the plug-in is to run before or 
        /// after the main operation and inside or outside
        /// the transaction
        /// </summary>
        internal enum EventPipelineStage
        {
            /// <summary>
            /// The plug-in will fire before the main operation outside the transaction
            /// </summary>
            PreValidation = 10,

            /// <summary>
            /// The plug-in will fire before the main operation inside the transaction
            /// </summary>
            PreExecution = 20,

            /// <summary>
            /// The plug-in will fire after the main operation inside the transaction
            /// </summary>
            PostExecution = 40,
        }

        /// <summary>
        /// Indicates whether the plug-in is to run Synchronously or Asynchronously
        /// </summary>
        internal enum EventExecutionMode
        {
            /// <summary>
            /// The plug-in will fire Synchronously
            /// </summary>
            Synchronous = 0,

            /// <summary>
            ///  The plug-in will fire Asynchronously
            /// </summary>
            Asynchronous = 1,
        }

    }
}
