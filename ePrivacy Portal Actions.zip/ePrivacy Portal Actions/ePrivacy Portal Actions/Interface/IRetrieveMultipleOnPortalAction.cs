﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Interface
{
    interface IRetrieveMultipleOnPortalAction : IDisposable
    {
        void PerformPortalAction();
    }
}
