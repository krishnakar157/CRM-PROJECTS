﻿using Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Helper;
using Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Interface;
using Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Models;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.BusinessLogic
{
    class PortalActionBusinessLogic : IRetrieveMultipleOnPortalAction
    {
        #region Class Level Constants
        public ITracingService TracingService;
        public IOrganizationService OrganizationService;
        public IPluginExecutionContext PluginExecutionContext;
        #endregion

        #region Constructor
        public PortalActionBusinessLogic(IOrganizationService organizationService, ITracingService tracingService, IPluginExecutionContext pluginExecutionContext)
        {
            TracingService = tracingService;
            OrganizationService = organizationService;
            PluginExecutionContext = pluginExecutionContext;
        }
        #endregion

        #region Public Methods       
        public void PerformPortalAction()
        {
            #region Function Level Variables
            string functionName = MethodBase.GetCurrentMethod().Name;
            string responseFetch = string.Empty;
            string actionName = string.Empty;
            string parameters = string.Empty;
            #endregion

            try
            {
                TracingService.Trace($"{string.Format(Constants.TraceMessages.EnteredMethodMessage, functionName)}");

                responseFetch = GetMeFetchExpression(PluginExecutionContext, OrganizationService);

                TracingService.Trace($"{functionName}: responseFetch {responseFetch}");

                if (!string.IsNullOrEmpty(responseFetch))
                {
                    TracingService.Trace($"{functionName}: Parsing Fetch");

                    XDocument parsedQuery = XDocument.Parse(responseFetch);

                    Dictionary<string, string> requestParameters = parsedQuery
                     .Descendants(Constants.ConditionText)
                     .Where(e => e.Attribute(Constants.AttributeText) != null && e.Attribute(Constants.OperatorText) != null &&
                                 e.Attribute(Constants.ValueText) != null &&
                                 String.Equals(e.Attribute(Constants.OperatorText).Value, "eq", StringComparison.InvariantCultureIgnoreCase))
                     .ToDictionary(e => e.Attribute(Constants.AttributeText).Value, e => e.Attribute(Constants.ValueText).Value);

                    TracingService.Trace($"{functionName}: requestParameters Count {requestParameters.Count}");

                    if (requestParameters != null && requestParameters.Count > 0 && requestParameters.ContainsKey(Constants.Bupa_ActionText) &&
                    requestParameters.ContainsKey(Constants.Bupa_ParametersText) && !string.IsNullOrEmpty(requestParameters[Constants.Bupa_ActionText]) && !string.IsNullOrEmpty(requestParameters[Constants.Bupa_ParametersText]))
                    {
                        TracingService.Trace($"{functionName}: Action and Parameters found!");

                        actionName = requestParameters[Constants.Bupa_ActionText].ToString();
                        TracingService.Trace($"{functionName}: actionName: {actionName}");

                        parameters = requestParameters[Constants.Bupa_ParametersText];
                        TracingService.Trace($"{functionName}: parameters: {parameters}");

                        switch (actionName)
                        {
                            case Constants.GetInteractionPermissionActionName:
                                GetInteractionPermissionForPortal(actionName, parameters);
                                break;
                            case Constants.SaveInteractionPermissionActionName:
                                SaveInteractionPermissionForPortal(actionName, parameters);
                                break;
                        }
                    }
                }

                TracingService.Trace($"{string.Format(Constants.TraceMessages.MethodExecutionCompleted, functionName)}");
            }
            catch (InvalidPluginExecutionException ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.FaultException, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
            catch (Exception ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.Exception, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
        }

        /// <summary>
        /// Function to get the query expression from Input Parameter of Retrieve Multiple
        /// </summary>
        /// <param name="context"></param>
        /// <param name="organizationService"></param>
        /// <returns></returns>
        public QueryExpression GetMeQueryExpression(IPluginExecutionContext context, IOrganizationService organizationService)
        {
            QueryExpression query;
            //If query is being passed from a fetchxml, query will be in Fetch Expression, Convert it to Query Expression
            if (context.InputParameters[Constants.ContextConstant.QueryText].GetType().Name.ToLower() == Constants.FetchExpressionText)
            {
                var fetchXml = ((FetchExpression)(context.InputParameters[Constants.ContextConstant.QueryText])).Query;
                var conversionRequest = new FetchXmlToQueryExpressionRequest
                {
                    FetchXml = fetchXml.ToString()
                };
                var conversionResponse = (FetchXmlToQueryExpressionResponse)organizationService.Execute(conversionRequest);
                query = conversionResponse.Query;
            }
            else
            {
                query = (QueryExpression)context.InputParameters[Constants.ContextConstant.QueryText];
            }

            return query;
        }

        /// <summary>
        /// Function to get the fetch xml expression from Input Parameter of Retrieve Multiple
        /// </summary>
        /// <param name="context"></param>
        /// <param name="organizationService"></param>
        /// <returns></returns>
        public string GetMeFetchExpression(IPluginExecutionContext context, IOrganizationService organizationService)
        {
            string fetchxml = string.Empty;
            //If query is being passed from dailog, query will be in Fetch Expression, Convert it to Query Expression
            if (context.InputParameters[Constants.ContextConstant.QueryText].GetType().Name.ToLower() == Constants.QueryExpressionText)
            {
                var conversionRequest = new QueryExpressionToFetchXmlRequest
                {
                    Query = (QueryExpression)context.InputParameters[Constants.ContextConstant.QueryText]
                };
                var conversionResponse = (QueryExpressionToFetchXmlResponse)organizationService.Execute(conversionRequest);
                fetchxml = conversionResponse.FetchXml;
            }
            else
            {
                fetchxml = ((FetchExpression)context.InputParameters[Constants.ContextConstant.QueryText]).Query;
            }

            return fetchxml;
        }
        public void Dispose()
        {
            //   throw new NotImplementedException();
        }
        #endregion

        #region Private Methods

        /// <summary>
        /// Function to call the Get Interaction Permission Action
        /// </summary>
        /// <param name="actionName">Name of the action passed from Portal</param>
        /// <param name="parameters">Parameters passed form Portal</param>
        private void GetInteractionPermissionForPortal(string actionName, string parameters)
        {
            #region Function Level Variables
            string functionName = MethodBase.GetCurrentMethod().Name;
            string getInteractionPermissionResponse = string.Empty;

            List<GetInteractionPermissions> interactionPermissionsList = null;
            #endregion

            try
            {
                TracingService.Trace($"{string.Format(Constants.TraceMessages.EnteredMethodMessage, functionName)}");

                OrganizationRequest interactionPermissionRequest = new OrganizationRequest(actionName)
                {
                    Parameters = {
                        {
                            Constants.ActionParameters.BGIDParameter, parameters
                        }
                    }
                };

                TracingService.Trace(string.Format(Constants.TraceMessages.BeforeCallingAction, functionName));
                OrganizationResponse interactionPermissionResponse = OrganizationService.Execute(interactionPermissionRequest);
                TracingService.Trace(string.Format(Constants.TraceMessages.ActionCalled, functionName));


                getInteractionPermissionResponse = interactionPermissionResponse.Results[Constants.ResponseText].ToString();
                TracingService.Trace($"{functionName}: getInteractionPermissionResponse {getInteractionPermissionResponse}");

                DataContractJsonSerializer serializer = new DataContractJsonSerializer(typeof(List<GetInteractionPermissions>));
                using (MemoryStream stream = new MemoryStream(Encoding.UTF8.GetBytes(getInteractionPermissionResponse)))
                {
                    interactionPermissionsList = (List<GetInteractionPermissions>)serializer.ReadObject(stream);
                }

                if (interactionPermissionsList != null)
                {
                    TracingService.Trace($"{functionName}: interactionPermissionsList contains data");

                    EntityCollection outputParameter = (EntityCollection)PluginExecutionContext.OutputParameters[Constants.ContextConstant.BusinessEntityCollectionText];
                    outputParameter.Entities.Clear();
                    foreach (GetInteractionPermissions interationPermissionData in interactionPermissionsList)
                    {
                        Entity entity = new Entity(Constants.EPrivacyPortal.EntityName, Guid.NewGuid());

                        #region Add data in entity attributes
                        entity[Constants.EPrivacyPortal.ChannelFieldNameText] = interationPermissionData.channel;
                        entity[Constants.EPrivacyPortal.ConfigurationIdFieldNameText] = interationPermissionData.configurationId;
                        entity[Constants.EPrivacyPortal.HistoryIdFieldNameText] = interationPermissionData.historyId;
                        entity[Constants.EPrivacyPortal.NeedsUpdateFieldNameText] = interationPermissionData.needsUpdate;
                        entity[Constants.EPrivacyPortal.OrderFieldNameText] = interationPermissionData.order;
                        entity[Constants.EPrivacyPortal.PermissionTextFieldNameText] = interationPermissionData.permissionText;
                        entity[Constants.EPrivacyPortal.PreferenceFieldNameText] = interationPermissionData.preference;
                        entity[Constants.EPrivacyPortal.SubtargetFieldNameText] = interationPermissionData.subTarget;
                        entity[Constants.EPrivacyPortal.TargetFieldNameText] = interationPermissionData.target;
                        #endregion

                        outputParameter.Entities.Add(entity);
                    }

                    if (outputParameter.Entities.Count > 0)
                    {
                        TracingService.Trace($"{functionName}: Set Output Parameter");
                        PluginExecutionContext.OutputParameters[Constants.ContextConstant.BusinessEntityCollectionText] = outputParameter;
                    }
                }
                TracingService.Trace($"{string.Format(Constants.TraceMessages.MethodExecutionCompleted, functionName)}");
            }
            catch (InvalidPluginExecutionException ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.FaultException, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
            catch (Exception ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.Exception, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
        }

        /// <summary>
        /// Function to call the Save Interaction Permission Action
        /// </summary>
        /// <param name="actionName">Name of the action passed from Portal</param>
        /// <param name="parameters">Parameters passed form Portal</param>
        private void SaveInteractionPermissionForPortal(string actionName, string parameters)
        {
            #region Function Level Variables
            string functionName = MethodBase.GetCurrentMethod().Name;

            SaveInteractionPermissions saveInteractionParamater = null;
            #endregion
            try
            {
                TracingService.Trace($"{string.Format(Constants.TraceMessages.EnteredMethodMessage, functionName)}");

                TracingService.Trace($"{functionName}: Before SaveInteractionPermissions Deserializing Object.");
                saveInteractionParamater = JsonConvert.DeserializeObject<SaveInteractionPermissions>(parameters);
                TracingService.Trace($"{functionName}:  SaveInteractionPermissions Deserialized.");

                if (saveInteractionParamater != null)
                {
                    TracingService.Trace($"{functionName}:  saveInteractionParamater is not null.");

                    OrganizationRequest saveinteractionPermissionRequest = new OrganizationRequest(parameters)
                    {
                        Parameters = {
                            { Constants.ActionParameters.BGIDParameter, saveInteractionParamater.BGID },
                            { Constants.ActionParameters.UpdatedByParameter, saveInteractionParamater.UpdatedBy },
                            { Constants.ActionParameters.InteractionPermissionsParameter, saveInteractionParamater.interactionPermissions },
                        }
                    };

                    TracingService.Trace(string.Format(Constants.TraceMessages.BeforeCallingAction, functionName));
                    OrganizationResponse saveinteractionPermissionResponse = OrganizationService.Execute(saveinteractionPermissionRequest);
                    TracingService.Trace(string.Format(Constants.TraceMessages.ActionCalled, functionName));
                }
                TracingService.Trace($"{string.Format(Constants.TraceMessages.MethodExecutionCompleted, functionName)}");
            }
            catch (InvalidPluginExecutionException ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.FaultException, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
            catch (Exception ex)
            {
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.Exception, (ex.InnerException != null && !string.IsNullOrEmpty(ex.InnerException.Message) ? ex.InnerException.Message : ex.Message));
            }
        }
        private void ThrowExceptionInCRM(string functionName, string exceptionType, string errorMessage)
        {
            TracingService.Trace($"{string.Format(Constants.TraceMessages.ExitingMethodMessage, functionName, exceptionType, errorMessage)}");
            throw new InvalidPluginExecutionException(errorMessage);
        }

        #endregion
    }
}
