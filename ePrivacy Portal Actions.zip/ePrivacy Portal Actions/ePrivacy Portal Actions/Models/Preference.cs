﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Models
{
    [DataContract]
    internal class Preference
    {
        [DataMember]
        public string configurationId { get; set; }

        [DataMember]
        public string preference { get; set; }
    }
}
