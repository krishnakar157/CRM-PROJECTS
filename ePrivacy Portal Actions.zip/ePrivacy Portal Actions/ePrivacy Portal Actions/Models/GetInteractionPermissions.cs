﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Models
{
    [DataContract]
    internal class GetInteractionPermissions
    {
        [DataMember]
        public string historyId { get; set; }
        [DataMember]
        public string channel { get; set; }
        [DataMember]
        public string target { get; set; }
        [DataMember]
        public string subTarget { get; set; }
        [DataMember]
        public string permissionText { get; set; }
        [DataMember]
        public string configurationId { get; set; }
        [DataMember]
        public string preference { get; set; }
        [DataMember]
        public string order { get; set; }
        [DataMember]
        public string needsUpdate { get; set; }
    }
}
