﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Models
{
    [DataContract]
    internal class SaveInteractionPermissions
    {
        [DataMember]
        public string BGID { get; set; }

        [DataMember]
        public string UpdatedBy { get; set; }

        [DataMember]
        public string interactionPermissions { get; set; }
    }
}
