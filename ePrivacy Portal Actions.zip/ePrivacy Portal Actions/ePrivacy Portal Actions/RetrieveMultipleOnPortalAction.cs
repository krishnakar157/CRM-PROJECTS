﻿using Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.BusinessLogic;
using Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Helper;
using Bupa.Crm.Plugins.Shared.ePrivacyPortalActions.Interface;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Bupa.Crm.Plugins.Shared.ePrivacyPortalActions
{
    /// <summary>
    /// Primary Entity: E-Privacy Portal Action (bupa_eprivacyportalaction)
    /// Message: RetrieveMultiple    
    /// Pipeline Stage of Execution: Post-Operation
    /// Execution Mode: Synchronous  
    /// 
    /// Description:
    /// This plugin will be called on Retrieve Multiple of the E-Privacy Portal Action entity, and will be called from Portal. 
    /// The purpose of this plugin in to interpret the conditions passed in the fetchxml and called from portal, and read the conditions (action, and parameters), and accordingly call the action by passing the parameters to it.    
    /// </summary>
    public class RetrieveMultipleOnPortalAction : IPlugin
    {
        #region Member Variables
        public string LogPrefix { get { return this.GetType().UnderlyingSystemType.Name; } }
        public ITracingService TracingService;
        public IPluginExecutionContext PluginExecutionContext;
        public IOrganizationService OrganizationService;
        public IOrganizationServiceFactory OrganizationServiceFactory;
        #endregion

        #region Public Methods
        public void Execute(IServiceProvider serviceProvider)
        {
            // Validate that there is a service provider, otherwise no point.
            if (serviceProvider == null)
            {
                throw new ArgumentNullException(Constants.ServiceProvider, string.Format(CultureInfo.InvariantCulture, Constants.TraceMessages.ServiceProviderNullMessage, LogPrefix));
            }
            try
            {
                // Set the context variables
                SetContextVariables(serviceProvider);

                // Start tracing
                TracingService.Trace(string.Format(CultureInfo.InvariantCulture, Constants.TraceMessages.StartTracingMessage, LogPrefix));

                // Check the plugin execution context is valid (i.e. the entity)             
                ValidatePluginExecutionContext();

                // Get the organisation service to use (for creating/updating, etc).
                SetOrganisationServiceProxy();

                using (IRetrieveMultipleOnPortalAction portalActions = new PortalActionBusinessLogic(OrganizationService, TracingService, PluginExecutionContext))
                {
                    portalActions.PerformPortalAction();
                }
                TracingService.Trace(string.Format(CultureInfo.InvariantCulture, Constants.TraceMessages.StopTracingMessage, LogPrefix));
            }
            #region Catch FaultException<OrganizationServiceFault>
            catch (FaultException<OrganizationServiceFault> ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            #endregion

            #region Catch all other exceptions
            catch (InvalidPluginExecutionException ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            catch (Exception ex)
            {
                throw new InvalidPluginExecutionException(ex.Message);
            }
            #endregion
        }
        #endregion

        #region Internal - Base Plugin Helper Methods

        /// <summary>
        /// Sets the plugin context variables
        /// </summary>
        /// <param name="serviceProvider">IServiceProvider</param>
        internal void SetContextVariables(IServiceProvider serviceProvider)
        {
            TracingService = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            PluginExecutionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            OrganizationServiceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
        }

        /// <summary>
        /// Sets the organization service proxy
        /// </summary>
        internal void SetOrganisationServiceProxy()
        {
            OrganizationService = OrganizationServiceFactory.CreateOrganizationService(PluginExecutionContext.UserId);
        }

        /// <summary>
        /// Validate the PlugInExecutionContext
        /// We do this to ensure that the execution details are as expected, as we should
        /// be certain of this so we are aware how and when this runs
        /// </summary>
        public void ValidatePluginExecutionContext()
        {
            string functionName = MethodBase.GetCurrentMethod().Name;
            string _traceMsg = string.Empty;

            TracingService.Trace($"{string.Format(Constants.TraceMessages.EnteredMethodMessage, functionName)}");

            #region Check Plugin Message
            // Check this is the expected Message Name the context is running under.
            if (!PluginExecutionContext.MessageName.Equals(Constants.PluginMessage.RetrieveMultiple, StringComparison.InvariantCultureIgnoreCase))
            {
                _traceMsg = string.Format(Constants.TraceMessages.PluginIncorrectMessageNameMessage, LogPrefix, Constants.PluginMessage.RetrieveMultiple, PluginExecutionContext.MessageName);
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, _traceMsg);
            }
            #endregion

            #region Check EventPipelineStage
            // Check this is the expected Pipeline stage the context is running under.
            if (!PluginExecutionContext.Stage.Equals((int)Constants.EventPipelineStage.PostExecution))
            {
                string validExecutionStage = $"{((int)Constants.EventPipelineStage.PostExecution).ToString()}";
                _traceMsg = string.Format(Constants.TraceMessages.PluginIncorrectPipelineStageMessage, LogPrefix, validExecutionStage, PluginExecutionContext.Stage);
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, _traceMsg);
            }
            #endregion

            #region Check Plugin Input Parameter
            if (!PluginExecutionContext.InputParameters.Contains(Constants.ContextConstant.QueryText))
            {
                _traceMsg = string.Format(Constants.TraceMessages.InvalidPluginTarget, LogPrefix, Constants.ContextConstant.QueryText);
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, _traceMsg);
            }

            if (!PluginExecutionContext.InputParameters.Contains(Constants.ContextConstant.QueryText))
            {
                _traceMsg = string.Format(Constants.TraceMessages.InvalidPluginTarget, LogPrefix, Constants.ContextConstant.QueryText);
                ThrowExceptionInCRM(functionName, Constants.TraceMessages.InvalidPluginExecutionException, _traceMsg);
            }
            #endregion

            TracingService.Trace($"{string.Format(Constants.TraceMessages.MethodExecutionCompleted, functionName)}");
        }
        #endregion

        #region Private Methods

        private void ThrowExceptionInCRM(string functionName, string exceptionType, string errorMessage)
        {
            TracingService.Trace($"{string.Format(Constants.TraceMessages.ExitingMethodMessage, functionName, exceptionType, errorMessage)}");
            throw new InvalidPluginExecutionException(errorMessage);
        }

        #endregion
    }
}
