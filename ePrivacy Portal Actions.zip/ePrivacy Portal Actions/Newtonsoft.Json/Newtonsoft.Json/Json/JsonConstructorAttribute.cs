﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Newtonsoft.Json
{
  /// <summary>
  /// Instructs the <see cref="JsonSerializer"/> to use the specified constructor when deserializing that object.
  /// </summary>
  [AttributeUsage(AttributeTargets.Constructor)]
    [ExcludeFromCodeCoverage]
    public sealed class JsonConstructorAttribute : Attribute
  {
  }
}