function queryContact() {

var fetchXml = "<?xml version="1.0"?>

-<fetch version="1.0" output-format="xml-platform" mapping="logical" distinct="true">


-<entity name="contact">

<attribute name="fullname"/>

<attribute name="telephone1"/>

<attribute name="contactid"/>

<order attribute="fullname" descending="false"/>


-<filter type="and">

<condition attribute="lastname" operator="not-null"/>

</filter>


-<link-entity name="bupa_interactionpermissionhistory" link-type="inner" alias="ab" from="bupa_customer" to="contactid">


-<filter type="and">

<condition attribute="bupa_channel" operator="not-null"/>


-<condition attribute="bupa_subtarget" operator="in">

<value>100000000</value>

<value>100000001</value>

</condition>

<condition attribute="bupa_answered" operator="not-null"/>

</filter>

</link-entity>

</entity>

</fetch>";

 

var encodedFetchXml = encodeURI(fetchXml);
var queryPath = "/api/data/v8.0/accounts?fetchXml=" + encodedFetchXml;

var requestPath = Xrm.Page.context.getClientUrl() + queryPath;
var req = new XMLHttpRequest();

req.open("GET", requestPath, true);

req.setRequestHeader("Accept", "application/json");

req.setRequestHeader("Content-Type", "application/json; charset=utf-8");

req.onreadystatechange = function ()

{

    if (this.readyState === 4)

    {

        this.onreadystatechange = null;

        if (this.status === 200)

        {

            var returned = JSON.parse(this.responseText);

            var results = returned.value;

 

            for (var i = 0; i < results.length; i++)

            {

                var accountName = results[i]["name"];

                var primaryContactId = results[i]["_primarycontactid_value"];

                var telephone = results[i]["telephone1"];

                var accountId = results[i]["accountid"];

                //TODO: Implement logic for handling results as desired

            }

        }

        else

        {

            alert(this.statusText);

        }

    }

};

req.send();