﻿using System;
using System.Collections.Generic;
using ACM.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ACM.BLTest
{
    [TestClass]
    public class CustomerRepositoryTest
    {
        [TestMethod]
        public void RetrieveValid()
        {
            //Arrange
            var customerRepository = new CustomerRepository();
            var expected = new Customer(1)
            {

                EmailAddress = "krishnk@bupa.com",
                FirstName = "Krishna",
                LastName = "Kaarola",
                AddressList = new List<Address>()
                {
                    new Address()
                    {
                        AddressType = 1,
                        StreetLine1 = "plot no.72, maruthi nagar, khairthabad",
                        StreetLine2 = "Near master talent school",
                        City = "Hyderabad",
                        State = "TS",
                        Country = "India",
                        PostalCode = "500004"
                    },
                    new Address()
                    {
                        AddressType = 2,
                        StreetLine1 = "Unit 701 - 702, Tower 2, ++, Jogeshwari - Vikhroli Link Rd,",
                        StreetLine2 = "Seepz, Andheri East,",
                        City = "Mumbai",
                        State = "MH",
                        Country = "India",
                        PostalCode = "400096"
                    }
                }
            };
            //Act
            var actual = customerRepository.Retrieve(1);

            //Assert
            Assert.AreEqual(expected.CustomerId, actual.CustomerId);
            Assert.AreEqual(expected.EmailAddress, actual.EmailAddress);
            Assert.AreEqual(expected.FirstName, actual.FirstName);
            Assert.AreEqual(expected.LastName, actual.LastName);

            for (int i = 0; i < 1; i++ )
            {
                Assert.AreEqual(expected.AddressList[i].AddressType, actual.AddressList[i].AddressType);
                Assert.AreEqual(expected.AddressList[i].StreetLine1, actual.AddressList[i].StreetLine1);
                Assert.AreEqual(expected.AddressList[i].City, actual.AddressList[i].City);
                Assert.AreEqual(expected.AddressList[i].State, actual.AddressList[i].State);
                Assert.AreEqual(expected.AddressList[i].Country, actual.AddressList[i].Country);
                Assert.AreEqual(expected.AddressList[i].PostalCode, actual.AddressList[i].PostalCode);
            }
        }
    }
}
