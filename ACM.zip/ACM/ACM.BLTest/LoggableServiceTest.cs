﻿using System;
using System.Collections.Generic;
using ACM.BL;
using ACME.common;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ACM.BLTest
{
    [TestClass]
    public class LoggableServiceTest
    {
        [TestMethod]
        public void WriteToFileTest()
        {
            //Arrange
            var changedItems = new List<ILoggable>();

            var customer = new Customer(1)
            {
                EmailAddress = "krishnk@bupa.com",
                FirstName = "Krishna",
                LastName = "Kaarola",
                AddressList = null
            };
            changedItems.Add(customer);

            var product = new Product(2)
            {
                ProductName = "Dell",
                ProductDescription = "Assorted size 15.6 inch black, core i7, 8GB ram, 2GB Gr etc...",
                CurrentPrice = 40126.96M
            };
            changedItems.Add(product);

            //Act
            LoggingServices.WriteToFile(changedItems);

            //Assert
            //Nothing to write here
        }
    }
}
