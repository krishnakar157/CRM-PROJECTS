﻿using System;
using ACM.BL;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ACM.BLTest
{
    [TestClass]
    public class AddressRepositoryTest
    {
        [TestMethod]
        public void RetrieveAddressDisplay()
        {
            //Arrange
            var addressRepository = new AddressRepository();
            var expected = new Address(4)
            {

                PostalCode = "500004",
                StreetLine1 = "plot no.72, maruthi nagar, khairthabad",
                City = "Hyderabad",
                State = "TS"
        };
            //Act
            var actual = addressRepository.Retrieve(4);

            //Assert
            Assert.AreEqual(expected.PostalCode, actual.PostalCode);
            Assert.AreEqual(expected.StreetLine1, actual.StreetLine1);
            Assert.AreEqual(expected.City, actual.City);
            Assert.AreEqual(expected.State, actual.State);
        }
    }
}
