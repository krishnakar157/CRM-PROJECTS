﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.BL
{
    public class AddressRepository
    {
        public Address Retrieve(int addressId)
        {
            Address address = new Address(addressId);

            if (addressId == 4)
            {
                address.AddressType = 1;
                address.StreetLine1 = "plot no.72, maruthi nagar, khairthabad";
                address.StreetLine2 = "Near master talent school";
                address.City = "Hyderabad";
                address.State = "TS";
                address.Country = "India";
                address.PostalCode = "500004";
            }
            return address;
        }

        public IEnumerable<Address> RetrieveByCustomerId(int customerId)
        {
            var addressList = new List<Address>();
            Address address = new Address(4)
            {
                AddressType = 1,
                StreetLine1 = "plot no.72, maruthi nagar, khairthabad",
                StreetLine2 = "Near master talent school",
                City = "Hyderabad",
                State = "TS",
                Country = "India",
                PostalCode = "500004"
            };
            addressList.Add(address);

            address = new Address(5)
            {
                AddressType = 2,
                StreetLine1 = "Unit 701 - 702, Tower 2, ++, Jogeshwari - Vikhroli Link Rd,",
                StreetLine2 = "Seepz, Andheri East,",
                City = "Mumbai",
                State = "MH",
                Country = "India",
                PostalCode = "400096"
            };
            addressList.Add(address);

            return addressList;
        }
        /// <summary>
        /// Retrieve all customers
        /// </summary>
        /// <returns></returns>
        public List<Address> Retrieve()
        {

            return new List<Address>();
        }
        /// <summary>
        /// Saves the current customer
        /// </summary>
        /// <returns></returns>
        public bool Save(Address address)
        {


            return true;
        }
    }
}
