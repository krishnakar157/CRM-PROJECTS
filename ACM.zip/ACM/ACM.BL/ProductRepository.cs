﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.BL
{
    public class ProductRepository
    {
        /// <summary>
        /// Retrieve one Product
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Product Retrieve(int productId)
        {
            Product product = new Product(productId);
            if(productId == 2)
            {
                product.ProductName =  "Dell";
                product.ProductDescription = "Assorted size 15.6 inch black, core i7, 8GB ram, 2GB Gr etc...";
                product.CurrentPrice = 40126.96M;
            }
            Object myobject = new Object();
            Console.WriteLine($"Object: {myobject.ToString()}");
            Console.WriteLine($"Product: {product.ToString()}");
            return product;
        }
        /// <summary>
        /// Retrieve all Products
        /// </summary>
        /// <returns></returns>
        //public List<Product> Retrieve()
        //{

        //    return new List<Product>();
        //}
        /// <summary>
        /// Saves the current product
        /// </summary>
        /// <returns></returns>
        public bool Save(Product product)
        {
            var success = true;

            if(product.HasChanges)
            {
                if(product.IsValid)
                {
                    if(product.IsNew)
                    {
                        //code to call an insert stored procedure
                    }
                    else
                    {
                        //code to call an update stored procedure
                    }
                }
                else
                {
                    success = false;
                }
            }
            return success;
        }
    }
}
