﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.BL
{
    public class Orderitem
    {
        public Orderitem()
        {

        }
        public Orderitem(int orderItemId)
        {
            OrderItemId = orderItemId;
        }

        public int OrderItemId { get; set; }
        public int ProductId { get; set; }
        public decimal? PurchasePrice { get; set; }
        public int Quantity { get; set; }
        /// <summary>
        /// Retrieve one OrderItems
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Orderitem Retrieve(int orderId)
        {


            return new Orderitem();
        }
        /// <summary>
        /// Retrieve all orderItems
        /// </summary>
        /// <returns></returns>
        //public List<Orderitem> Retrieve()
        //{

        //    return new List<Orderitem>();
        //}
        /// <summary>
        /// Saves the current orderItem
        /// </summary>
        /// <returns></returns>
        public bool Save()
        {


            return true;
        }
        /// <summary>
        /// Validates the OrderItem Data
        /// </summary>
        /// <returns></returns>
        public bool Validate()
        {
            var isValid = true;

            if (Quantity <= 0) isValid = false;
            if (ProductId <= 0) isValid = false;
            if (PurchasePrice == null) isValid = false;

            return isValid;
        }
    }
}
