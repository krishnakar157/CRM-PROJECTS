﻿using ACME.common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.BL
{
    public class Order : EntityBase, ILoggable
    {
        public Order()
        {

        }
        public Order(int orderId)
        {
            OrderId = orderId;
        }
        public int CustomerId { get; set; }
        public DateTimeOffset? OrderDate { get; set; }
        public int OrderId { get; set; }
        public List<Orderitem> Orderitems { get; set; }
        public int ShippingAddressId { get; set; }
        public string Log() =>
            $"{OrderId}:  Date: {this.OrderDate.Value.Date} Status: {EntityState.ToString()}";

        public override string ToString() => $"{OrderDate.Value.Date} ({OrderId})";

        /// <summary>
        /// Retrieve one Order
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Order Retrieve(int orderId)
        {


            return new Order();
        }
        /// <summary>
        /// Retrieve all orders
        /// </summary>
        /// <returns></returns>
        //public List<Order> Retrieve()
        //{

        //    return new List<Order>();
        //}
        /// <summary>
        /// Saves the current order
        /// </summary>
        /// <returns></returns>
        public bool Save()
        {


            return true;
        }
        /// <summary>
        /// Validates the Order Data
        /// </summary>
        /// <returns></returns>
        public override bool Validate()
        {
            var isValid = true;

            if (OrderDate == null) isValid = false;

            return isValid;
        }

        
    }
}
