﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ACM.BL
{
    public class OrderRepository 
    {
        /// <summary>
        /// Retrieve one Order
        /// </summary>
        /// <param name="productId"></param>
        /// <returns></returns>
        public Order Retrieve(int orderId)
        {
            Order order = new Order(orderId);
            if(orderId == 3)
            {
                order.OrderDate = new DateTimeOffset(DateTime.Now.Year, 4, 14, 10, 00, 00,
                                                     new TimeSpan(7, 0, 0));
            }
            return order;
        }
        /// <summary>
        /// Retrieve all orders
        /// </summary>
        /// <returns></returns>
        //public List<Order> Retrieve()
        //{

        //    return new List<Order>();
        //}
        /// <summary>
        /// Saves the current order
        /// </summary>
        /// <returns></returns>
        public bool Save(Order order)
        {
            var success = true;

            if (order.HasChanges)
            {
                if (order.IsValid)
                {
                    if (order.IsNew)
                    {
                        //code to call an insert stored procedure
                    }
                    else
                    {
                        //code to call an update stored procedure
                    }
                }
                else
                {
                    success = false;
                }
            }
            return success;
        }
    }
}
